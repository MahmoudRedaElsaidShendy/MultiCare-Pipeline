'use strict';
/* How the team uses it */
App.views.guide = {
  async load() {
    return `<div class="pagehead"><div><h1>How the team uses it</h1><p>The ${esc(App.meta.appName)} is the working mirror of the new-product SOPs (version 3, ${App.meta.steps.length} steps) and the only communication channel between departments for the pipeline — no e-mail is needed. Every department works its own steps; the platform calculates readiness, deadlines and hand-offs.</p></div></div>
    <div class="guide">
      <div class="panel pad"><h3>Every day</h3><ol>
        <li>Sign in with your <b>department</b>, username and password. You land on <b>Notifications</b>: hand-offs, System-Uploads, updates, notes and reminders addressed to your department.</li>
        <li><span class="hl-unread">Unread</span> notifications stay highlighted in yellow until you tick <b>Read</b> on each one. Opening a notification does not mark it as read; untick <b>Read</b> to make it unread again.</li>
        <li>Department users see Notifications, Project flow and My department. The <b>Dashboard</b> is for the Plant Manager, CEO / Business Development and the administrator.</li>
        <li>Open <b>My department</b> to see, for each product, what is overdue, in progress, ready to start and coming next. Click a step number anywhere to open the step panel.</li>
      </ol></div>
      <div class="panel pad"><h3>System-Upload — instead of e-mail</h3><ol>
        <li>Wherever the SOP says <b>System-Upload</b>, deliver the output inside the step: <b>Upload file</b> and/or write a <b>short message</b> in the output's System-Upload box. The receiving departments shown in the box are notified immediately.</li>
        <li>An output <b>cannot be checked</b> until it has its System-Upload (a file or a message). In steps where each department checks its own part, each checking department adds its own file or message first.</li>
        <li>Outputs marked <span class="tag amber">file upload required</span> (set by the administrator in Settings → Upload rules) need an uploaded file — a message alone is not enough.</li>
        <li><b>SOP-controlled documents</b> are part of their output and are always mandatory: the output cannot be checked with a message alone — upload the document (each upload becomes the next version).</li>
        <li>What a step delivers appears automatically in the <b>Input</b> of the next steps, where it can be opened and downloaded — the receiving department confirms the input after checking it.</li>
      </ol></div>
      <div class="panel pad"><h3>Working a step</h3><ol>
        <li>A step becomes <span class="pill st-ready">Ready to start</span> when all steps it depends on are completed or marked not applicable. Its deadline = ready date + the SOP timeframe of each output.</li>
        <li>Press <b>Start step</b>. The time between “ready” and “started” is recorded and shown in the department analytics.</li>
        <li>Tick each <b>input</b> when you have received and checked it.</li>
        <li>Deliver each <b>output</b> by System-Upload, then tick it. Ticking an output with a hand-off notifies the receiving departments.</li>
        <li>Steps with several accountable departments (2, 4, 7, 10, 30): each output is checked by its own department — in step 7 the purchasing request must be checked by both R&amp;D and QC. Then any of them can complete the step.</li>
        <li>Planning steps 20 (pilot) and 33 (commercial) have 13 separate outputs in 5 groups. Each output is filled (message / upload) by the department named in it — e.g. “QC System-Upload the reviewed and signed calculation…” by QC — and then checked by the <b>Plant Manager or QA</b> as final accountability (they can also fill any output).</li>
        <li>Press <b>Complete step</b> when all inputs and outputs are ticked and the required SOP-controlled documents are uploaded. The next steps become ready and their departments are notified.</li>
      </ol></div>
      <div class="panel pad"><h3>Sequential, parallel and loops</h3><ul>
        <li><b>→</b> sequential: a step waits for the previous one.</li>
        <li><b>‖</b> parallel: steps in the same bracket run at the same time (e.g. steps 5 and 6, steps 9 and 10).</li>
        <li><b>↻</b> iterative loop: steps 12 and 13 repeat until the formula of choice is reached. Use <b>Log loop iteration</b> for every trial cycle; tick the final outputs at the end.</li>
        <li><b>Long-running outputs</b>: step 13 output 5 (3-month trial stability), step 24 output 2 (6-month stability data, 7 months) and step 28 output 3 (third-party BE study, 4 months). Once every other output of the step is delivered, the next steps become ready (steps 13 and 24); step 30 always waits until step 28 is completed with the BE study. The step card keeps an amber flag (“Needs trial stability data” / “Needs 6-month stability data” / “Needs BE study data”) until the long-running output is delivered and the step is completed.</li>
        <li>Steps 27 / 28 depend on the authority answer in step 25 — mark the one not required as <b>not applicable</b> with the reason.</li>
      </ul></div>
      <div class="panel pad"><h3>Product documents</h3><ul>
        <li>The top of <b>Project flow</b> lists all SOP-controlled documents of the product in SOP step order (step 1 first), with step, output, version, department, user and date.</li>
        <li><span class="tag green">uploaded</span> documents can be opened, downloaded and their versions listed; <span class="tag grey">not uploaded yet</span> documents are greyed out with an <b>Upload</b> / <b>Open step</b> button.</li>
        <li>Search by name, file, user, step number or version (e.g. “v2”); filter by status or section; click a column title to sort; untick <b>Latest version only</b> to see every version.</li>
      </ul></div>
      <div class="panel pad"><h3>Announcements</h3><ul>
        <li>The administrator, Business Development and the Plant Manager have an <b>Announcement</b> tab: write a message, attach files if needed, choose one, several or all departments and (optionally) the product, and send.</li>
        <li>It appears at once in the Notifications of those departments (filter <b>Announcements</b>), with the attachments ready to open.</li>
      </ul></div>
      <div class="panel pad"><h3>Deadlines and colours</h3><ul>
        <li><b>WD</b> = working days, Sunday–Thursday, excluding the official holidays entered by the administrator. Calendar-day, week and month timeframes that end on a weekend or holiday move to the next working day.</li>
        <li>Each output has its own timeframe, so a step can show several due dates (“out 1,2 · 14 Dec 2026”, “out 5 · 9 Feb 2027”). Overdue days are counted per output.</li>
        <li><span class="pill st-overdue">Overdue</span> appears the day after an output deadline passes; the accountable departments, the Plant Manager and Business Development are notified.</li>
        <li>A step that is ready but not started within 2 working days triggers a <b>start delay</b> alert to the accountable departments, the Plant Manager and Business Development.</li>
        <li>Expected license date (step ${App.meta.license_step}) and expected 1st 3 commercial batches (step ${App.meta.commercial_step}) are forecasts that move with real progress.</li>
      </ul></div>
      <div class="panel pad"><h3>Notes, reminders and risk findings</h3><ul>
        <li><b>Notes</b> are for discussion (issues, decisions, delay reasons) and are delivered to the departments you tick; deliverables go in the output's System-Upload box.</li>
        <li><b>Send reminder</b> notifies the accountable departments of a step — any department can send one.</li>
        <li>Raise a <b>risk finding</b> (Critical / Major / Minor) on the step. Every finding is sent to the action owner, the Plant Manager and Business Development (business owner); open findings are mirrored on the dashboard and in their My department view until closed.</li>
      </ul></div>
      <div class="panel pad"><h3>Roles</h3><ul>
        <li><b>Department user</b>: editor on the steps of the department, viewer on the rest (the administrator can change this per step).</li>
        <li><b>Executive</b> (Business Development / Plant Manager): creates products, changes a deadline, re-opens a step and writes the monthly department evaluation (positive points, negative points, final conclusion).</li>
        <li><b>Administrator</b>: Settings — users, passwords and access, departments, holidays, SOP content, upload rules, document list, database export and deletion of uploads.</li>
      </ul></div>
      <div class="panel pad"><h3>If a screen stays on “Loading…”</h3><ul>
        <li>The system stops waiting after 30 seconds and shows the reason with a <b>Try again</b> button.</li>
        <li>A browser keeps at most 6 connections open to one server. Use the system in one or two tabs: tabs in the background pause their live connection (the indicator at the top right shows <b>Paused</b>) and catch up when you return to them.</li>
        <li>If the indicator shows <b>Auto-refresh</b> instead of <b>Live</b>, antivirus web scanning or a proxy on this PC is holding the live connection; the screen then refreshes every 20 seconds. For instant updates, IT can exclude the system address from web scanning and from the proxy (“Don’t use the proxy server for local addresses”).</li>
        <li>Connection test from any PC: open <b>http://SERVER-IP:3000/api/ping</b> — it answers at once with <span class="mono">"ok": true</span>.</li>
        <li>Problems seen in browsers are recorded in <span class="mono">data/server.log</span> on the server.</li>
      </ul></div>
      <div class="panel pad wide"><h3>Changing the SOP</h3><p>Settings → SOP control edits names, accountable / responsible departments, inputs, tasks, outputs, timeframes, receiving departments and notes. Each save is a new version with an effective date (today or later), for all products or for one product only. A step uses the version in force on the day it became ready, so running and finished steps are never changed retrospectively.</p></div>
    </div>`;
  },
};
