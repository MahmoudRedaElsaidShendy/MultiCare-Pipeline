'use strict';
/* My department — the steps my department owns, per product and across all products */
App.views.mydept = {
  dept: null, pid: null,
  async load() {
    const dept = App.isExec() && this.dept ? this.dept : App.me.dept;
    const d = await api('GET', `/api/mydept?dept=${encodeURIComponent(dept)}`);
    this.d = d;
    const prods = d.products;
    if (!prods.length) return `<div class="pagehead"><div><h1>${esc(d.dept_name)}</h1></div></div><div class="panel empty">No active product projects yet.</div>`;
    if (!prods.find((p) => p.product.id === this.pid)) this.pid = (prods.find((p) => p.overdue.length || p.in_progress.length || p.ready.length) || prods[0]).product.id;
    const cur = prods.find((p) => p.product.id === this.pid);
    const cols = [['overdue', 'Overdue'], ['in_progress', 'In progress'], ['ready', 'Ready to start'], ['coming', 'Coming next'], ['risks', 'Risk findings']];
    const li = (s, k) => `<li data-open-step="${s.no}" data-pid="${cur.product.id}"><b class="mono">${s.no}</b> ${esc(s.name)}
      ${k === 'overdue' || k === 'in_progress' ? `<div class="duelist small">${dueLines(s.dues)}</div>` : ''}${s.released && s.deferLabels.length ? `<div class="deferflag">⧗ ${esc(s.deferLabels.join(' · '))}</div>` : ''}
      <div class="m">${k === 'overdue' ? `${s.overdueDays} d late` : k === 'in_progress' ? `outputs ${s.outputsDone}/${s.outputsTotal}` : k === 'ready' ? `ready ${fmtDate(s.readyDate)} · ${s.waitWD} WD not started` : `≈ ready ${fmtDate(s.fReady)}`}${s.acc ? ` · ${esc(s.acc)}` : ''}</div>
      ${s.myOutputs && s.myOutputs.length && s.accountable && !s.accountable.includes(dept) ? `<div class="m">your output${s.myOutputs.length > 1 ? 's' : ''}: ${s.myOutputs.map((o) => `#${o.idx}${o.state ? ' ✓' : ''}`).join(', ')}</div>` : ''}</li>`;
    const riskLi = (r) => `<li ${r.step_no ? `data-open-step="${r.step_no}" data-pid="${cur.product.id}"` : ''}><span class="tag sev-${r.severity}">${r.severity}</span> ${esc(r.title)}<div class="m">${r.step_no ? `step ${r.step_no} · ` : ''}${r.action ? esc(r.action) : ''}</div></li>`;

    const tot = (k) => prods.reduce((a, p) => a + p[k].length, 0);
    return `
    <div class="pagehead">
      <div><h1>${esc(d.dept_name)}</h1><p>Steps where your department is accountable, responsible or delivers an output.</p></div>
      <span class="spacer"></span>
      ${App.isExec() ? `<label class="field"><span>Department</span><select id="mdd">${App.meta.departments.filter((x) => x.code !== 'ADM').map((x) => `<option value="${x.code}" ${x.code === dept ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>` : ''}
      <a class="btn" href="/api/export/csv/mydept?dept=${encodeURIComponent(dept)}">Export CSV</a>
    </div>

    <section class="section" style="margin-top:6px">
      <header><h2>This product</h2><select id="mdp">${prods.map((p) => `<option value="${p.product.id}" ${p.product.id === this.pid ? 'selected' : ''}>${esc(p.product.name)}</option>`).join('')}</select>
        <p>${cur.done}/${cur.total} of your steps closed · <a href="#/flow/${cur.product.id}">open the workflow</a></p></header>
      <div class="mdk">${cols.map(([k, l]) => `<div class="mdcol c-${k}"><div class="hd"><span>${l}</span><b>${cur[k].length}</b></div>
        <ul>${cur[k].length ? cur[k].map((x) => (k === 'risks' ? riskLi(x) : li(x, k))).join('') : '<li style="background:none;cursor:default" class="muted">None</li>'}</ul></div>`).join('')}</div>
    </section>

    <section class="section">
      <header><h2>All products</h2><p>${tot('overdue')} overdue · ${tot('in_progress')} in progress · ${tot('ready')} ready to start · ${tot('coming')} coming next · ${tot('risks')} open risk findings. Click a step number to open it.</p></header>
      <div class="tablewrap"><table class="grid"><thead><tr><th>Product</th><th>Overdue</th><th>In progress</th><th>Ready to start</th><th>Coming next</th><th class="num">Risk findings</th><th class="num">Closed</th></tr></thead>
      <tbody>${prods.map((p) => `<tr>
        <td><a href="#/flow/${p.product.id}"><b>${esc(p.product.name)}</b></a></td>
        ${['overdue', 'in_progress', 'ready', 'coming'].map((k) => `<td><div class="stepchips">${p[k].map((s) => `<button class="sc ${k === 'overdue' ? 'st-overdue' : `st-${s.state}`}" data-open-step="${s.no}" data-pid="${p.product.id}" title="${esc(s.name)} — ${k === 'overdue' ? `${s.overdueDays} d late` : k === 'ready' ? `${s.waitWD} WD waiting` : `due ${fmtDate(s.due || s.fDue)}`}">${s.no}</button>`).join('') || '<span class="faint">—</span>'}</div></td>`).join('')}
        <td class="num">${p.risks.length ? `<span class="tag red">${p.risks.length}</span>` : '0'}</td>
        <td class="num">${p.done}/${p.total}</td></tr>`).join('')}</tbody></table></div>
    </section>`;
  },
  bind(el) {
    const v = this;
    if ($('#mdd', el)) $('#mdd', el).onchange = (e) => { v.dept = e.target.value; Main.render(true); };
    if ($('#mdp', el)) $('#mdp', el).onchange = (e) => { v.pid = Number(e.target.value); Main.render(true); };
  },
};
