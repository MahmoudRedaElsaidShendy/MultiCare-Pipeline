'use strict';
/* Shell: login, app bar, router, live updates */
const Main = {
  async start() {
    window.addEventListener('hashchange', () => Main.route());
    try { App.me = await api('GET', '/api/me', undefined, { noAuthRedirect: true }); } catch { App.me = null; }
    if (!App.me) return Main.showLogin();
    await Main.boot();
  },

  async showLogin() {
    Live.stop(); Drawer.close(true);
    let info = { company: '', departments: [] };
    try { info = await api('GET', '/api/public/info'); } catch { /* */ }
    $('#root').innerHTML = `
    <div class="login">
      <section class="art">
        <div class="brand"><div class="mark">MC</div><div>${esc(info.appName || 'Pipeline Tracker')}</div></div>
        <div>
          <div class="eyebrow">Multicare Pipeline Platform</div>
          <h1>One system for management, tracking, coordination, communication — and one database.</h1>
          <div class="mini" aria-hidden="true">
            <div class="c d">1</div><div class="ar">→</div><div class="c d">2</div><div class="ar">→</div><div class="c d">3</div><div class="ar">→</div><div class="c p">4</div><div class="ar">→</div>
            <div class="stack"><div class="c">5</div><div class="c">6</div></div><div class="ar">→</div>
            <div class="c">7</div><div class="ar">…</div><div class="c">35</div>
          </div>
          <p>Every pipeline product in one controlled place — accountability for each SOP step, deadlines held to plan, every hand-off and document exchanged inside the platform, and an audit-ready record from product sanction to the first commercial batches.</p>
        </div>
        <p class="small">Runs on the ${esc(info.company || 'company')} server. Data never leaves the local network.</p>
      </section>
      <section class="loginside">
      <img class="logo" src="/multicare-logo.png" alt="${esc(info.company || 'Multicare')} for Pharmaceutical Industries">
      <form id="lf" autocomplete="on">
        <div><h2>Sign in</h2><p class="muted" style="margin:4px 0 0">Choose your department, then your username and password.</p></div>
        <label class="field"><span>Department</span>
          <select id="ldept" required><option value="">Select department…</option>${info.departments.map((d) => `<option value="${esc(d.code)}">${esc(d.name)}</option>`).join('')}</select></label>
        <label class="field"><span>Username</span><input type="text" id="luser" autocomplete="username" required></label>
        <label class="field"><span>Password</span><input type="password" id="lpw" autocomplete="current-password" required></label>
        <div class="err" id="lerr"></div>
        <button class="btn primary" type="submit" style="justify-content:center;padding:10px">Sign in</button>
      </form>
      </section>
    </div>`;
    try { const last = localStorage.getItem('sop.dept'); if (last) $('#ldept').value = last; } catch { /* */ }
    $('#lf').onsubmit = async (e) => {
      e.preventDefault();
      $('#lerr').textContent = '';
      try {
        const r = await api('POST', '/api/login', { dept: $('#ldept').value, username: $('#luser').value.trim(), password: $('#lpw').value }, { noAuthRedirect: true });
        try { localStorage.setItem('sop.dept', $('#ldept').value); } catch { /* */ }
        App.me = r.user;
        location.hash = '#/notifications';
        await Main.boot();
      } catch (err) { $('#lerr').textContent = err.message; }
    };
  },

  async boot() {
    App.meta = await api('GET', '/api/meta');
    Main.shell();
    Live.start();
    if (App.me.must_change) Main.changePassword(true);
    if (!location.hash || location.hash === '#/' || location.hash === '#') location.hash = '#/notifications';
    else Main.route();
  },

  shell() {
    const tabs = [
      ['notifications', 'Notifications'], ...(App.canDash() ? [['dashboard', 'Dashboard']] : []), ['flow', 'Project flow'], ['mydept', 'My department'],
      ...(App.canAnnounce() ? [['announce', 'Announcement']] : []),
      ...(App.isExec() ? [['control', 'Settings']] : []), ['guide', 'How to use'],
    ];
    $('#root').innerHTML = `
    <header class="appbar">
      <div class="brand" title="${esc(App.meta.appName)}"><div class="mark">MC</div><div>${esc(App.meta.company)}<small>Pipeline Tracker and Management System</small></div></div>
      <nav class="tabs" id="tabs">${tabs.map(([k, l]) => `<a href="#/${k}" data-tab="${k}">${l}${k === 'notifications' ? ' <span class="badge hidden" id="nbadge"></span>' : ''}</a>`).join('')}</nav>
      <div class="right">
        <span class="live" id="live" title="Live connection"><i></i><span>Connecting…</span></span>
        <button class="userchip" id="uchip"><div><b>${esc(App.me.full_name || App.me.username)}</b><span>${esc(App.me.dept_name)} · ${App.me.role === 'admin' ? 'Administrator' : App.me.role === 'executive' ? 'Executive' : 'Department user'}</span></div></button>
      </div>
    </header>
    <main id="main"></main>`;
    Main.badge(App.me.unread);
    $('#uchip').onclick = (e) => {
      e.stopPropagation();
      const old = $('.menu'); if (old) return old.remove();
      const m = document.createElement('div'); m.className = 'menu';
      m.innerHTML = '<button data-m="pw">Change password</button><button data-m="out">Sign out</button>';
      document.body.appendChild(m);
      m.onclick = async (ev) => {
        const k = ev.target.dataset.m; m.remove();
        if (k === 'pw') Main.changePassword(false);
        if (k === 'out') { await api('POST', '/api/logout', {}); App.me = null; Main.showLogin(); }
      };
      setTimeout(() => document.addEventListener('click', () => m.remove(), { once: true }));
    };
  },

  badge(n) {
    App.me.unread = n;
    const b = $('#nbadge'); if (!b) return;
    b.textContent = n > 99 ? '99+' : n; b.classList.toggle('hidden', !n);
    const t = App.meta ? App.meta.appName : 'Multicare Pipeline Tracker and Management System';
    document.title = n ? `(${n}) ${t}` : t;
  },

  changePassword(forced) {
    modal({
      title: forced ? 'Set your own password' : 'Change password', width: 440,
      body: `${forced ? '<p class="banner warn" style="margin:0">For security, replace the temporary password before you continue.</p>' : ''}
        <label class="field"><span>Current password</span><input type="password" id="pw0"></label>
        <label class="field"><span>New password (min. 6 characters)</span><input type="password" id="pw1"></label>
        <label class="field"><span>Repeat new password</span><input type="password" id="pw2"></label>`,
      actions: [...(forced ? [] : [{ label: 'Cancel' }]), {
        label: 'Save password', primary: true, onClick: async (w) => {
          if ($('#pw1', w).value !== $('#pw2', w).value) { toast('The two new passwords do not match', 'err'); return false; }
          await api('POST', '/api/me/password', { current: $('#pw0', w).value, password: $('#pw1', w).value });
          App.me.must_change = false; toast('Password saved');
        },
      }],
    });
  },

  route() {
    if (!App.me || !$('#main')) return;
    const h = location.hash.replace(/^#\/?/, '');
    const [pathPart, qs] = h.split('?');
    const parts = pathPart.split('/');
    const allowed = (k) => App.views[k] && (k !== 'dashboard' || App.canDash()) && (k !== 'announce' || App.canAnnounce());
    const view = allowed(parts[0]) ? parts[0] : (App.canDash() ? 'dashboard' : 'notifications');
    if (parts[0] && view !== parts[0]) history.replaceState(null, '', `#/${view}`);
    const params = Object.fromEntries(new URLSearchParams(qs || ''));
    params.args = parts.slice(1);
    const changed = App.view !== view || JSON.stringify(App.params.args) !== JSON.stringify(params.args);
    App.view = view; App.params = params;
    $$('#tabs a').forEach((a) => a.classList.toggle('active', a.dataset.tab === view));
    if (changed) { $('#main').innerHTML = '<div class="empty">Loading…</div>'; window.scrollTo(0, 0); }
    Main.render(!changed);
    if (params.step && params.pid) Drawer.open(Number(params.pid), Number(params.step), true).catch((e) => { reportError(e, 'open step'); Drawer.fail(e.message); });
    else Drawer.close(true);
  },

  async render(soft) {
    const v = App.views[App.view];
    try {
      const html = await v.load(App.params);
      const main = $('#main');
      const y = window.scrollY;
      preserve(main, () => { main.innerHTML = html; v.bind && v.bind(main, App.params); });
      if (soft) window.scrollTo(0, y);
    } catch (e) {
      if (e.message === 'Please sign in') return;
      if (soft && $('#main .empty') === null) return; // a background refresh failed: keep what is on screen
      if (!/did not answer|did not arrive|Cannot reach/.test(e.message)) reportError(e, `view ${App.view}`);
      $('#main').innerHTML = `<div class="empty">${esc(e.message)}<div style="margin-top:12px"><button class="btn primary" data-retry-view>Try again</button></div></div>`;
    }
  },

  refreshSoon: (() => { let t = null; return (alsoMeta) => { clearTimeout(t); t = setTimeout(async () => {
    if (alsoMeta) { try { App.meta = await api('GET', '/api/meta'); } catch { return; } }
    if (Main.busy()) return Main.refreshSoon(false);
    Main.render(true); Drawer.refresh();
  }, 350); }; })(),
  busy() { const a = document.activeElement; return a && a.tagName === 'TEXTAREA' && a.value.length > 0 && a.closest('#main'); },
};

// open a step from anywhere
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-open-step]');
  if (!b) return;
  e.preventDefault();
  $$('.modal').forEach((m) => m.remove());
  const pid = b.dataset.pid || (App.params.args && App.params.args[0]) || Flow.pid;
  if (!pid) return;
  location.hash = `#/flow/${pid}?pid=${pid}&step=${b.dataset.openStep}`;
});

document.addEventListener('click', (e) => { if (e.target.closest('[data-retry-view]')) { $('#main').innerHTML = '<div class="empty">Loading…</div>'; Main.render(false); } });

/*
 * Live updates. A browser allows only 6 open connections to one server; a live connection stays open,
 * so only the tab on screen keeps one (background tabs disconnect after a few seconds and catch up when shown again).
 * If the live connection is held back (antivirus web scanning, proxy), the tab checks for changes every 20 s instead.
 */
const Live = {
  es: null, pollT: null, hideT: null, wdT: null, polling: false, bound: false, ver: null, mver: null,
  set(on, txt, title) { const l = $('#live'); if (l) { l.classList.toggle('on', on); $('span', l).textContent = txt; if (title !== undefined) l.title = title; } },
  showOnline(list) { App.online = list; const n = new Set(list).size; Live.set(true, `${Live.polling ? 'Auto-refresh' : 'Live'} · ${n} online`, `Online now: ${[...new Set(list)].join(', ')}${Live.polling ? ' — checking for changes every 20 s' : ''}`); },
  start() {
    if (!Live.bound) {
      Live.bound = true;
      document.addEventListener('visibilitychange', Live.onVisibility);
      window.addEventListener('pagehide', () => Live.stop());
    }
    Live.stop();
    if (document.visibilityState === 'hidden') { Live.set(false, 'Paused'); return; }
    if (Live.polling) Live.poll(); else Live.connect();
  },
  connect() {
    const es = new EventSource('/api/events');
    Live.es = es; let hello = false; let errors = 0;
    Live.wdT = setTimeout(() => { if (!hello && Live.es === es) Live.fallback(); }, 10000);
    es.onopen = () => Live.set(true, 'Live');
    es.onerror = () => { Live.set(false, 'Reconnecting…'); if (++errors >= 3 && !hello && Live.es === es) Live.fallback(); };
    es.onmessage = (m) => {
      let ev; try { ev = JSON.parse(m.data); } catch { return; }
      if (ev.t === 'hello') { hello = true; errors = 0; clearTimeout(Live.wdT); Live.set(true, 'Live'); Live.catchUp(ev.v, ev.mv); return; }
      Live.handle(ev);
    };
  },
  fallback() {
    if (Live.es) { Live.es.close(); Live.es = null; }
    clearTimeout(Live.wdT);
    Live.polling = true;
    reportError('Live connection blocked — switched to checking for changes every 20 s (antivirus web scanning or a proxy on this PC?)', 'live');
    Live.poll();
  },
  async poll() {
    clearTimeout(Live.pollT); Live.pollT = null;
    if (!App.me || document.visibilityState === 'hidden') return;
    try {
      const r = await api('GET', '/api/live', undefined, { timeout: 15000 });
      Live.showOnline(r.online);
      Live.catchUp(r.v, r.mv);
      if (r.unread !== App.me.unread) Live.unread(r.unread);
    } catch { Live.set(false, 'Reconnecting…'); }
    if (App.me && document.visibilityState !== 'hidden') Live.pollT = setTimeout(Live.poll, 20000);
  },
  // refresh the screen when something changed while this tab was not connected
  catchUp(v, mv) {
    const changed = Live.ver !== null && v !== Live.ver; const metaChanged = Live.mver !== null && mv !== Live.mver;
    Live.ver = v; Live.mver = mv;
    if (changed || metaChanged) Main.refreshSoon(metaChanged);
  },
  unread(n) {
    const was = App.me.unread; Main.badge(n);
    if (n > was) toast('<b>New notification for your department</b>Open Notifications to read it.', '', () => { location.hash = '#/notifications'; });
    if (App.view === 'notifications') Main.refreshSoon(false);
  },
  handle(ev) {
    if (ev.t === 'presence') Live.showOnline(ev.online);
    if (ev.t !== 'presence') Live.ver = (Live.ver || 0) + 1; // keeps step with the server counter between hellos
    if (ev.t === 'all') Live.mver = (Live.mver || 0) + 1;
    if (ev.t === 'product' || ev.t === 'analytics') Main.refreshSoon(false);
    if (ev.t === 'all') Main.refreshSoon(true);
    if (ev.t === 'notif' && ev.depts.includes(App.me.dept)) api('GET', '/api/me').then((me) => Live.unread(me.unread)).catch(() => {});
  },
  onVisibility() {
    if (!App.me) return;
    if (document.visibilityState === 'hidden') {
      clearTimeout(Live.hideT);
      Live.hideT = setTimeout(() => { if (document.visibilityState === 'hidden') { Live.stop(); Live.set(false, 'Paused'); } }, 3000);
    } else {
      clearTimeout(Live.hideT);
      if (!Live.es && !Live.pollT) {
        Live.start();
        api('GET', '/api/me').then((me) => { if (me.unread !== App.me.unread) Live.unread(me.unread); }).catch(() => {});
      }
    }
  },
  stop() {
    clearTimeout(Live.wdT); clearTimeout(Live.pollT); Live.pollT = null;
    if (Live.es) { Live.es.close(); Live.es = null; }
  },
};

Main.start();
