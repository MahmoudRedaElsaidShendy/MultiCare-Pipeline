'use strict';
/* Notifications — what reached my department. A notification stays unread (yellow) until it is checked as read. */
const ICON = { update: '●', handoff: '⇢', upload: '⇪', announce: '📣', note: '✎', reminder: '⏰', overdue: '!', delay: '⧗', risk: '⚠' };
const TYPE_LABEL = { update: 'Updates', handoff: 'Hand-offs', upload: 'System-Uploads', announce: 'Announcements', note: 'Notes', reminder: 'Reminders', overdue: 'Overdue', delay: 'Start delays', risk: 'Risk findings' };
App.views.notifications = {
  filter: { type: '', unread: false, q: '', dept: '' },
  limit: 100,
  async load() {
    const f = this.filter;
    const dept = App.isExec() && f.dept ? f.dept : '';
    const qs = new URLSearchParams({ limit: String(this.limit) });
    if (dept) qs.set('dept', dept); if (f.type) qs.set('type', f.type); if (f.unread) qs.set('unread', '1'); if (f.q) qs.set('q', f.q);
    const r = await api('GET', `/api/notifications?${qs}`);
    this.data = r;
    const mine = !dept || dept === App.me.dept;
    if (mine && App.me.unread !== r.unread) Main.badge(r.unread);
    const rows = r.rows;
    return `
    <div class="pagehead">
      <div><h1>Notifications for ${esc(dept === '*' ? 'all departments' : deptName(dept || App.me.dept))}</h1>
      <p>Hand-offs, System-Uploads, announcements, updates, notes and reminders sent to your department. <span class="hl-unread">Unread</span> notifications stay highlighted until you tick <b>Read</b>.</p></div>
      <span class="spacer"></span>
      ${App.isExec() ? `<label class="field"><span>Department</span><select id="nfdept"><option value="">My department</option><option value="*">All departments</option>${App.meta.departments.map((d) => `<option value="${d.code}">${esc(d.name)}</option>`).join('')}</select></label>` : ''}
      <a class="btn" href="/api/export/csv/notifications">Export CSV</a>
      ${mine ? `<button class="btn" id="nfall" ${r.unread ? '' : 'disabled'}>Mark all as read (${r.unread})</button>` : ''}
    </div>
    <div class="toolbar">
      <div class="seg" id="nftype"><button data-t="" class="${!f.type ? 'on' : ''}">All (${r.all})</button>${Object.keys(TYPE_LABEL).map((t) => `<button data-t="${t}" class="${f.type === t ? 'on' : ''}">${TYPE_LABEL[t]} (${r.counts[t] || 0})</button>`).join('')}</div>
      <label class="check"><input type="checkbox" id="nfunread" ${f.unread ? 'checked' : ''}> Unread only (${r.unread})</label>
      <input type="search" id="nfq" placeholder="Search product, step, person…" value="${esc(f.q)}" style="width:260px">
    </div>
    ${rows.length ? `<div class="nlist">${rows.map((n) => `
      <div class="nitem ${n.is_read ? '' : 'unread'}" data-n="${n.id}" data-pid="${n.product_id || ''}" data-step="${n.step_no || ''}">
        <div class="ic ${n.type}">${ICON[n.type] || '•'}</div>
        <div class="nmain" tabindex="0" role="link" title="${n.product_id ? 'Open the step' : ''}"><div class="nt">${esc(n.title)}</div>${n.body ? `<div class="nb">${linkify(n.body)}</div>` : ''}${n.files && n.files.length ? `<div class="nfiles">${n.files.map((f) => `<a href="/api/announcements/files/${f.id}" target="_blank" rel="noopener">📎 ${esc(f.filename)}</a> <span class="small muted">${fmtSize(f.size)}</span>`).join(' ')}</div>` : ''}
          <div class="nm">${n.from_user ? `From ${esc(n.from_user)}${n.from_dept ? ` (${esc(deptName(n.from_dept))})` : ''}` : ''}${dept === '*' ? ` · to ${esc(deptName(n.dept))}` : ''}${n.product_id ? ` · <span class="steplink">open${n.step_no ? ` step ${n.step_no}` : ''}</span>` : ''}</div></div>
        <div class="nside"><time title="${esc(n.created_at)}">${esc(ago(n.created_at))}</time>
          ${mine ? `<label class="readchk" title="${n.is_read ? 'Untick to mark as unread again' : 'Tick to mark as read'}"><input type="checkbox" data-read="${n.id}" ${n.is_read ? 'checked' : ''}> Read</label>` : ''}</div>
      </div>`).join('')}</div>
      ${r.total > rows.length ? `<div class="row" style="justify-content:center;margin-top:12px"><button class="btn" id="nfmore">Show older (${r.total - rows.length} more)</button></div>` : ''}`
    : `<div class="panel empty">${r.all ? 'No notifications match these filters.' : 'Nothing yet. Hand-offs, System-Uploads, reminders and notes for your department will appear here as soon as they are sent.'}</div>`}`;
  },
  bind(el) {
    const v = this;
    const reset = () => { v.limit = 100; Main.render(true); };
    if ($('#nfdept', el)) { $('#nfdept', el).value = v.filter.dept; $('#nfdept', el).onchange = (e) => { v.filter.dept = e.target.value; reset(); }; }
    $$('#nftype button', el).forEach((b) => { b.onclick = () => { v.filter.type = b.dataset.t; reset(); }; });
    $('#nfunread', el).onchange = (e) => { v.filter.unread = e.target.checked; reset(); };
    let t; $('#nfq', el).oninput = (e) => { clearTimeout(t); t = setTimeout(() => { v.filter.q = e.target.value; reset(); }, 300); };
    if ($('#nfmore', el)) $('#nfmore', el).onclick = () => { v.limit += 100; Main.render(true); };
    if ($('#nfall', el)) $('#nfall', el).onclick = async () => {
      if (!(await confirmBox('Mark all as read', `Mark all <b>${v.data.unread}</b> unread notifications of your department as read? Each one can be marked unread again later.`, 'Mark all as read'))) return;
      const r = await api('POST', '/api/notifications/read', { all: true }); Main.badge(r.unread); Main.render(true);
    };
    $$('[data-read]', el).forEach((c) => {
      c.onclick = (e) => e.stopPropagation();
      c.onchange = async () => {
        try {
          const r = await api('POST', '/api/notifications/read', { ids: [Number(c.dataset.read)], read: c.checked });
          Main.badge(r.unread);
          const it = c.closest('.nitem'); it.classList.toggle('unread', !c.checked);
          Main.render(true); // refresh the unread counters
        } catch (e) { fail(e); c.checked = !c.checked; }
      };
    });
    // opening a notification never marks it as read
    $$('.nitem .nmain', el).forEach((m) => {
      const it = m.closest('.nitem');
      const open = () => {
        const pid = it.dataset.pid; const st = it.dataset.step;
        if (pid && st) location.hash = `#/flow/${pid}?pid=${pid}&step=${st}`;
        else if (pid) location.hash = `#/flow/${pid}`;
      };
      m.onclick = (e) => { if (e.target.closest('a')) return; open(); }; m.onkeydown = (e) => { if (e.key === 'Enter') open(); };
    });
  },
};
