'use strict';
/* Settings — users, access, departments, holidays, SOP control, upload rules, document list, exports */
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
App.views.control = {
  sopNo: 1, draft: null, sopData: null,
  async load(params) {
    if (!App.isExec()) return '<div class="panel empty">Administrator / executive area.</div>';
    const secs = App.isAdmin() ? [['users', 'Users & access'], ['departments', 'Departments'], ['holidays', 'Holidays & working week'], ['sop', 'SOP control'], ['rules', 'Upload rules'], ['doctypes', 'Document list'], ['database', 'Database & export'], ['settings', 'General']] : [['database', 'Database & export'], ['rules', 'Upload rules']];
    let sec = params.args[0] || secs[0][0];
    if (!secs.find((s) => s[0] === sec)) sec = secs[0][0];
    this.sec = sec;
    const body = await this[`s_${sec}`]();
    return `<div class="pagehead"><div><h1>Settings</h1><p>${App.isAdmin() ? 'Accounts, access rights, calendar, SOP content, upload rules and data exports.' : 'Download product and tab data; view the upload rules.'}</p></div></div>
      <div class="ctl"><nav class="ctlnav">${secs.map(([k, l]) => `<a href="#/control/${k}" class="${k === sec ? 'active' : ''}">${l}</a>`).join('')}</nav><div>${body}</div></div>`;
  },
  bind(el) { const f = this[`b_${this.sec}`]; if (f) f.call(this, el); },

  // ---------- users ----------
  async s_users() {
    this.users = await api('GET', '/api/admin/users');
    const roleL = { admin: 'Administrator', executive: 'Executive (BD / Plant Manager)', user: 'Department user' };
    return `<div class="panel pad">
      <h3 style="font-size:15px;margin-bottom:10px">Add a user</h3>
      <div class="formgrid" style="grid-template-columns:repeat(5,minmax(0,1fr)) auto;align-items:end">
        <label class="field"><span>Department</span><select id="nu_d">${App.meta.departments.filter((d) => d.active).map((d) => `<option value="${d.code}">${esc(d.name)}</option>`).join('')}</select></label>
        <label class="field"><span>Username</span><input type="text" id="nu_u" placeholder="e.g. qc.ahmed"></label>
        <label class="field"><span>Full name</span><input type="text" id="nu_n"></label>
        <label class="field"><span>Temporary password</span><input type="text" id="nu_p" placeholder="min. 6 characters"></label>
        <label class="field"><span>Role</span><select id="nu_r"><option value="user">Department user</option><option value="executive">Executive (BD / Plant Manager)</option><option value="admin">Administrator</option></select></label>
        <button class="btn primary" id="nu_go">Add user</button>
      </div>
      <p class="small muted" style="margin:8px 0 0">New users must change the temporary password at first sign-in. By default, a user is <b>editor</b> on every step where the department is accountable, responsible or delivers an output, and <b>viewer</b> elsewhere — adjust per step with “Step access”.</p>
    </div>
    <div class="tablewrap" style="margin-top:14px"><table class="grid"><thead><tr><th>Department</th><th>Username</th><th>Full name</th><th>Role</th><th>Status</th><th>Last sign-in</th><th></th></tr></thead><tbody>
      ${this.users.map((u) => `<tr><td>${esc(deptName(u.dept))}</td><td class="mono">${esc(u.username)}</td><td>${esc(u.full_name)}</td><td>${roleL[u.role]}</td><td>${u.active ? 'Active' : '<span class="tag red">Disabled</span>'}${u.must_change ? ' <span class="tag">temp password</span>' : ''}</td><td class="small mono">${esc(fmtDT(u.last_login))}</td>
      <td class="nowrap"><button class="btn sm" data-eu="${u.id}">Edit</button> <button class="btn sm" data-pu="${u.id}">Step access</button></td></tr>`).join('')}
    </tbody></table></div>`;
  },
  b_users(el) {
    $('#nu_go', el).onclick = async () => {
      try {
        await api('POST', '/api/admin/users', { dept: $('#nu_d').value, username: $('#nu_u').value, full_name: $('#nu_n').value, password: $('#nu_p').value, role: $('#nu_r').value, must_change: true });
        ['nu_u', 'nu_n', 'nu_p'].forEach((i) => { $(`#${i}`).value = ''; }); toast('User added'); Main.render(true);
      } catch (e) { fail(e); }
    };
    $$('[data-eu]', el).forEach((b) => { b.onclick = () => this.editUser(this.users.find((u) => u.id === Number(b.dataset.eu))); });
    $$('[data-pu]', el).forEach((b) => { b.onclick = () => this.perms(this.users.find((u) => u.id === Number(b.dataset.pu))); });
  },
  editUser(u) {
    modal({
      title: `Edit ${u.username}`, width: 560,
      body: `<div class="formgrid">
        <label class="field"><span>Full name</span><input type="text" id="eu_n" value="${esc(u.full_name)}"></label>
        <label class="field"><span>Department</span><select id="eu_d">${App.meta.departments.map((d) => `<option value="${d.code}" ${d.code === u.dept ? 'selected' : ''}>${esc(d.name)}</option>`).join('')}</select></label>
        <label class="field"><span>Role</span><select id="eu_r">${[['user', 'Department user'], ['executive', 'Executive (BD / Plant Manager)'], ['admin', 'Administrator']].map(([k, l]) => `<option value="${k}" ${u.role === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <label class="field"><span>Status</span><select id="eu_a"><option value="1" ${u.active ? 'selected' : ''}>Active</option><option value="0" ${u.active ? '' : 'selected'}>Disabled (cannot sign in)</option></select></label>
        <label class="field full"><span>Reset password (leave empty to keep)</span><input type="text" id="eu_p" placeholder="new temporary password"></label>
      </div><p class="small muted" style="margin:0">Executives can create products, change deadlines, re-open steps and write department evaluations. Users are never deleted, so their history stays traceable — disable them instead.</p>`,
      actions: [{ label: 'Cancel' }, { label: 'Save', primary: true, onClick: async (w) => {
        await api('PUT', `/api/admin/users/${u.id}`, { full_name: $('#eu_n', w).value, dept: $('#eu_d', w).value, role: $('#eu_r', w).value, active: $('#eu_a', w).value === '1', password: $('#eu_p', w).value || undefined, must_change: true });
        toast('User saved'); Main.render(true);
      } }],
    });
  },
  async perms(u) {
    const rows = await api('GET', `/api/admin/perms/${u.id}`);
    const L = { edit: 'Editor', view: 'Viewer', none: 'No access' };
    const m = modal({
      title: `Step access — ${u.full_name || u.username} (${deptName(u.dept)})`, width: 860,
      body: `<div class="row"><span class="small muted grow">“Default” follows the department's role in the SOP. Editors can start/complete the step, confirm inputs and outputs and upload; viewers can read, post notes and send reminders.</span>
        <button class="btn sm" data-all="edit">All editor</button><button class="btn sm" data-all="view">All viewer</button><button class="btn sm" data-all="">All default</button></div>
        <div>${rows.map((r) => `<div class="permrow"><b class="mono">${r.no}</b><span>${esc(r.name)}</span>
          <select data-pr="${r.no}"><option value="">Default (${L[r.def]})</option><option value="edit" ${r.level === 'edit' ? 'selected' : ''}>Editor</option><option value="view" ${r.level === 'view' ? 'selected' : ''}>Viewer</option><option value="none" ${r.level === 'none' ? 'selected' : ''}>No access</option></select></div>`).join('')}</div>`,
      actions: [{ label: 'Cancel' }, { label: 'Save access', primary: true, onClick: async (w) => {
        const levels = {}; $$('[data-pr]', w).forEach((s) => { levels[s.dataset.pr] = s.value || null; });
        await api('PUT', `/api/admin/perms/${u.id}`, { levels }); toast('Access saved — takes effect at the user\'s next page load');
      } }],
    });
    $$('[data-all]', m.el).forEach((b) => { b.onclick = () => $$('[data-pr]', m.el).forEach((s) => { s.value = b.dataset.all; }); });
  },

  // ---------- departments ----------
  async s_departments() {
    return `<div class="panel pad"><div class="row" style="align-items:end">
      <label class="field"><span>Code</span><input type="text" id="nd_c" placeholder="e.g. ENG" style="width:110px"></label>
      <label class="field grow"><span>Department name</span><input type="text" id="nd_n" placeholder="e.g. Engineering"></label>
      <button class="btn primary" id="nd_go">Add department</button></div></div>
      <div class="tablewrap" style="margin-top:14px"><table class="grid"><thead><tr><th>Code</th><th>Name</th><th>Status</th><th></th></tr></thead><tbody>
      ${App.meta.departments.map((d) => `<tr><td class="mono">${esc(d.code)}</td><td>${esc(d.name)}</td><td>${d.active ? 'Active' : '<span class="tag">Hidden from sign-in</span>'}</td>
        <td class="nowrap"><button class="btn sm" data-rn="${d.code}">Rename</button> <button class="btn sm" data-ac="${d.code}" data-v="${d.active ? 0 : 1}">${d.active ? 'Deactivate' : 'Activate'}</button></td></tr>`).join('')}
      </tbody></table></div>
      <p class="small muted">Department codes are used inside the SOP content (accountable / responsible / output owner). Rename freely; codes stay fixed.</p>`;
  },
  b_departments(el) {
    const reload = async () => { App.meta = await api('GET', '/api/meta'); Main.render(true); };
    $('#nd_go', el).onclick = async () => { try { await api('POST', '/api/admin/departments', { code: $('#nd_c').value, name: $('#nd_n').value }); toast('Department added'); reload(); } catch (e) { fail(e); } };
    $$('[data-rn]', el).forEach((b) => { b.onclick = async () => { const n = await ask('Rename department', 'New name', { multiline: false, value: deptName(b.dataset.rn) }); if (n) { await api('PUT', `/api/admin/departments/${b.dataset.rn}`, { name: n }); reload(); } }; });
    $$('[data-ac]', el).forEach((b) => { b.onclick = async () => { await api('PUT', `/api/admin/departments/${b.dataset.ac}`, { active: b.dataset.v === '1' }); reload(); }; });
  },

  // ---------- holidays ----------
  async s_holidays() {
    const hol = await api('GET', '/api/admin/holidays');
    const years = [...new Set(hol.map((h) => h.date.slice(0, 4)))].sort();
    return `<div class="panel pad">
      <h3 style="font-size:15px">Working week</h3>
      <p class="small muted" style="margin:4px 0 8px">Working-day (WD) timeframes skip these weekend days and the official holidays below.</p>
      <div class="row">${DAYS.map((d, i) => `<label class="check"><input type="checkbox" data-wk="${i}" ${App.meta.weekend.includes(i) ? 'checked' : ''}> ${d}</label>`).join('')}<button class="btn sm primary" id="wk_go">Save weekend</button></div>
    </div>
    <div class="panel pad" style="margin-top:14px">
      <h3 style="font-size:15px">Official national holidays</h3>
      <div class="row" style="align-items:end;margin-top:8px">
        <label class="field"><span>Date</span><input type="date" id="h_d"></label>
        <label class="field grow"><span>Holiday name</span><input type="text" id="h_n" placeholder="e.g. Eid al-Fitr"></label>
        <button class="btn primary" id="h_go">Add holiday</button>
      </div>
      <details style="margin-top:10px"><summary class="small" style="cursor:pointer">Paste several holidays at once</summary>
        <textarea id="h_bulk" rows="5" placeholder="2027-01-07 Coptic Christmas&#10;2027-01-25 Revolution Day"></textarea><button class="btn sm" id="h_bgo" style="margin-top:6px">Add all</button></details>
      <p class="banner warn small">The 2026 list was pre-filled with estimated dates (Islamic holidays depend on moon sighting). Review it and add next year's official holidays when they are announced.</p>
    </div>
    ${years.reverse().map((y) => `<section class="section"><header><h2>${y}</h2><p>${hol.filter((h) => h.date.startsWith(y)).length} days</p></header>
      <div class="tablewrap"><table class="grid"><tbody>${hol.filter((h) => h.date.startsWith(y)).map((h) => `<tr><td class="mono" style="width:130px">${h.date}</td><td style="width:110px">${DAYS[new Date(h.date + 'T12:00').getDay()]}</td><td>${esc(h.name)}</td><td style="width:80px"><button class="btn sm danger" data-hd="${h.date}">Remove</button></td></tr>`).join('')}</tbody></table></div></section>`).join('')}`;
  },
  b_holidays(el) {
    const reload = async () => { App.meta = await api('GET', '/api/meta'); Main.render(true); };
    $('#wk_go', el).onclick = async () => { await api('PUT', '/api/admin/settings', { weekend: $$('[data-wk]', el).filter((c) => c.checked).map((c) => Number(c.dataset.wk)) }); toast('Working week saved — all deadlines recalculated'); reload(); };
    $('#h_go', el).onclick = async () => { if (!$('#h_d').value) return toast('Pick a date', 'err'); await api('POST', '/api/admin/holidays', { date: $('#h_d').value, name: $('#h_n').value }); toast('Holiday added — deadlines recalculated'); reload(); };
    $('#h_bgo', el).onclick = async () => {
      const items = $('#h_bulk').value.split('\n').map((l) => l.trim().match(/^(\d{4}-\d{2}-\d{2})\s*[,;\t ]\s*(.*)$/)).filter(Boolean).map((m) => ({ date: m[1], name: m[2] }));
      if (!items.length) return toast('Use one line per holiday: YYYY-MM-DD name', 'err');
      const r = await api('POST', '/api/admin/holidays', { items }); toast(`${r.added} holidays added`); reload();
    };
    $$('[data-hd]', el).forEach((b) => { b.onclick = async () => { await api('DELETE', `/api/admin/holidays/${b.dataset.hd}`); reload(); }; });
  },

  // ---------- SOP control ----------
  async s_sop() {
    const no = this.sopNo;
    if (!this.sopData || this.sopData.no !== no) { this.sopData = await api('GET', `/api/admin/sop/${no}`); this.sopData.no = no; this.draft = JSON.parse(JSON.stringify(this.sopData.current)); }
    const products = await api('GET', '/api/products?all=1');
    const d = this.draft;
    const deptChecks = (key, list) => `<div class="row">${App.meta.departments.filter((x) => x.code !== 'ADM').map((x) => `<label class="check small"><input type="checkbox" data-dc="${key}" value="${x.code}" ${(list || []).includes(x.code) ? 'checked' : ''}>${esc(deptShort(x.code))}</label>`).join('')}</div>`;
    const deptSel = (cls, v) => `<select class="${cls}"><option value="">—</option>${App.meta.departments.filter((x) => x.code !== 'ADM').map((x) => `<option value="${x.code}" ${v === x.code ? 'selected' : ''}>${esc(deptShort(x.code))}</option>`).join('')}</select>`;
    const tf = (s) => { const m = String(s || '').match(/^([\d.]+)\s*(WD|CD|W|M)$/i); return m ? [m[1], m[2].toUpperCase()] : ['', 'WD']; };
    const repHead = (kind, i, n) => `<div class="rh"><b>${i + 1}.</b><span class="grow"></span><button class="btn sm ghost" data-mv="${kind}:${i}:-1" ${i === 0 ? 'disabled' : ''}>↑</button><button class="btn sm ghost" data-mv="${kind}:${i}:1" ${i === n - 1 ? 'disabled' : ''}>↓</button><button class="btn sm ghost danger" data-rm="${kind}:${i}">Remove</button></div>`;
    const tb = (x) => `<label class="field"><span>Text</span><textarea class="f-t" rows="2">${esc(x.t)}</textarea></label><label class="field"><span>Bullets (one per line)</span><textarea class="f-b" rows="${Math.max(2, (x.b || []).length)}">${esc((x.b || []).join('\n'))}</textarea></label>`;
    const notesText = (n) => n.items.map((i) => [i.t, ...(i.b || []).map((b) => `- ${b}`)].join('\n')).join('\n');
    return `<div class="sopeditor">
      <div class="steplist">${App.meta.steps.map((s) => `<button data-sop="${s.no}" class="${s.no === no ? 'on' : ''}"><b>${s.no}</b><span>${esc(s.name)}</span></button>`).join('')}</div>
      <div>
        <div class="panel pad" id="sopf">
          <div class="row"><h3 style="font-size:17px" class="grow">Step ${no}</h3><span class="small muted">Changes create a new version and apply from the effective date on — steps that became ready earlier keep the version they started with.</span></div>
          <div class="formgrid" style="margin-top:12px">
            <label class="field full"><span>Step name</span><input type="text" id="sp_name" data-nokeep value="${esc(d.name)}"></label>
            <label class="field"><span>Phase</span><select id="sp_phase" data-nokeep>${App.meta.phases.map((p) => `<option value="${p.no}" ${p.no === d.phase ? 'selected' : ''}>${p.no} · ${esc(p.name)}</option>`).join('')}</select></label>
            <label class="field"><span>Accountable (as written in the SOP)</span><input type="text" id="sp_acct" data-nokeep value="${esc(d.accText || '')}"></label>
            <div class="field full"><span>Accountable departments</span>${deptChecks('accountable', d.accountable)}</div>
            <div class="field full"><span>Responsible departments (if applicable)</span>${deptChecks('responsible', d.responsible)}</div>
            <label class="field"><span>Depends on steps (comma separated)</span><input type="text" id="sp_deps" data-nokeep value="${esc((d.deps || []).join(', '))}"></label>
            <label class="field"><span>Condition note (optional)</span><input type="text" id="sp_cond" data-nokeep value="${esc(d.conditional || '')}"></label>
            <label class="check"><input type="checkbox" id="sp_loop" data-nokeep ${d.loop ? 'checked' : ''}> Part of an iterative loop</label>
          </div>

          <div class="blk"><h3>Inputs (trigger)</h3><div id="rep_inputs">${(d.inputs || []).map((x, i, a) => `<div class="rep" data-rep="inputs">${repHead('inputs', i, a.length)}${tb(x)}
            <div class="formgrid"><label class="field"><span>Comes from step.output (e.g. 6.1, 8)</span><input type="text" class="f-from" value="${esc((x.from || []).join(', '))}"></label><label class="field"><span>…or from department</span>${deptSel('f-dept', x.dept)}</label></div></div>`).join('')}</div>
            <button class="btn sm" data-add="inputs">+ Add input</button></div>

          <div class="blk"><h3>Key tasks</h3><div>${(d.tasks || []).map((x, i, a) => `<div class="rep" data-rep="tasks">${repHead('tasks', i, a.length)}${tb(x)}</div>`).join('')}</div><button class="btn sm" data-add="tasks">+ Add task</button></div>

          <div class="blk"><h3>Outputs &amp; timeframes</h3><p class="small muted" style="margin:0 0 8px">Each numbered output has its own timeframe counted from the date the step becomes ready. Units: WD = working days, CD = calendar days, W = weeks, M = months (1.5 allowed). Every output is delivered by System-Upload (file and/or short message) before it can be checked.</p>
            <div>${(d.outputs || []).map((x, i, a) => { const [n, u] = tf(x.tf); return `<div class="rep" data-rep="outputs">${repHead('outputs', i, a.length)}${tb(x)}
            <div class="formgrid" style="grid-template-columns:repeat(4,minmax(0,1fr))">
              <label class="field"><span>Timeframe</span><span class="row" style="flex-wrap:nowrap"><input type="number" class="f-tfn" step="0.5" min="0" value="${n}" style="width:80px"><select class="f-tfu">${['WD', 'CD', 'W', 'M'].map((k) => `<option ${u === k ? 'selected' : ''}>${k}</option>`).join('')}</select></span></label>
              <label class="field"><span>Timeframe wording (optional)</span><input type="text" class="f-tfl" value="${esc(x.tfLabel || '')}"></label>
              <label class="field"><span>Delivered by</span>${deptSel('f-dept', x.dept)}</label>
              <label class="field"><span>Hand-off to steps</span><input type="text" class="f-to" value="${esc((x.to || []).join(', '))}"></label>
              <label class="field"><span>Counts from output # (optional)</span><input type="number" class="f-rel" min="1" value="${x.rel || ''}"></label>
              <label class="check"><input type="checkbox" class="f-fin" ${x.fin ? 'checked' : ''}> Final output after loop</label>
              <label class="check"><input type="checkbox" class="f-as" ${x.assumed ? 'checked' : ''}> Timeframe not in SOP (default)</label>
              <div class="field" style="grid-column:span 4"><span>System-Upload goes to (receiving departments, notified of every file / message on this output)</span><div class="row">${App.meta.departments.filter((z) => z.code !== 'ADM').map((z) => `<label class="check small"><input type="checkbox" class="f-rc" value="${z.code}" ${(x.rcpt || []).includes(z.code) ? 'checked' : ''}>${esc(deptShort(z.code))}</label>`).join('')}</div></div>
              <div class="field" style="grid-column:span 2"><span>Must be checked by (multi-accountable steps — leave empty: any editor)</span><div class="row">${App.meta.departments.filter((z) => z.code !== 'ADM').map((z) => `<label class="check small"><input type="checkbox" class="f-so" value="${z.code}" ${(x.signoff || []).includes(z.code) ? 'checked' : ''}>${esc(deptShort(z.code))}</label>`).join('')}</div></div>
              <div class="field" style="grid-column:span 2"><span>Filled by (text / upload — leave empty: any editor of the step)</span><div class="row">${App.meta.departments.filter((z) => z.code !== 'ADM').map((z) => `<label class="check small"><input type="checkbox" class="f-by" value="${z.code}" ${(x.by || []).includes(z.code) ? 'checked' : ''}>${esc(deptShort(z.code))}</label>`).join('')}</div></div>
              <div class="field" style="grid-column:span 2"><span>Checked by — any one of (leave empty: any editor)</span><div class="row">${App.meta.departments.filter((z) => z.code !== 'ADM').map((z) => `<label class="check small"><input type="checkbox" class="f-ck" value="${z.code}" ${(x.checkers || []).includes(z.code) ? 'checked' : ''}>${esc(deptShort(z.code))}</label>`).join('')}</div></div>
              <label class="field" style="grid-column:span 2"><span>Group heading (optional — shown above a group of outputs)</span><input type="text" class="f-grp" value="${esc(x.group || '')}"></label>
              <label class="check"><input type="checkbox" class="f-def" ${x.defer ? 'checked' : ''}> Long-running: next steps may start before it</label>
              <label class="field"><span>Card highlight while pending</span><input type="text" class="f-defl" value="${esc(x.deferLabel || '')}" placeholder="e.g. Needs trial stability data"></label>
              <label class="field" style="grid-column:span 2"><span>Long-running: only these next steps may start early (empty = all next steps)</span><input type="text" class="f-relto" value="${esc(Array.isArray(x.releaseTo) && !x.releaseTo.length ? '0' : (x.releaseTo || []).join(', '))}" placeholder="e.g. 29 — or 0 = no step (card flag only)"></label>
            </div></div>`; }).join('')}</div><button class="btn sm" data-add="outputs">+ Add output</button></div>

          <div class="blk"><h3>SOP notes &amp; guidance</h3><div>${(d.notes || []).map((x, i, a) => `<div class="rep" data-rep="notes">${repHead('notes', i, a.length)}
            <label class="field"><span>Title</span><input type="text" class="f-title" value="${esc(x.title)}"></label>
            <label class="field"><span>Items (one per line; start a line with “- ” for a sub-bullet)</span><textarea class="f-items" rows="${Math.min(14, notesText(x).split('\n').length + 1)}">${esc(notesText(x))}</textarea></label></div>`).join('')}</div><button class="btn sm" data-add="notes">+ Add note block</button></div>

          <div class="blk panel pad" style="background:var(--tint);border:0">
            <div class="formgrid" style="grid-template-columns:1fr 1fr 2fr auto;align-items:end">
              <label class="field"><span>Applies to</span><select id="sp_scope"><option value="">All products</option>${products.map((p) => `<option value="${p.id}">Only: ${esc(p.name)}</option>`).join('')}</select></label>
              <label class="field"><span>Effective from</span><input type="date" id="sp_eff" value="${todayStr()}" min="${todayStr()}"></label>
              <label class="field"><span>Change note</span><input type="text" id="sp_note" placeholder="What changed and why"></label>
              <button class="btn primary" id="sp_save">Save new version</button>
            </div>
          </div>
        </div>
        <section class="section"><header><h2>Version history — step ${no}</h2></header>
          <div class="tablewrap"><table class="grid"><thead><tr><th>Effective from</th><th>Applies to</th><th>Saved by</th><th>Note</th><th></th></tr></thead><tbody>
          ${this.sopData.versions.map((v) => `<tr><td class="mono">${v.effective_from === '2000-01-01' ? 'baseline' : v.effective_from}</td><td>${v.product ? esc(v.product) : 'All products'}</td><td>${esc(v.created_by)} <span class="small muted">${esc(fmtDT(v.created_at))}</span></td><td>${esc(v.note || '')}</td>
            <td class="nowrap"><button class="btn sm" data-load="${v.id}">Load into editor</button>${v.effective_from > todayStr() ? ` <button class="btn sm danger" data-wd="${v.id}">Withdraw</button>` : ''}</td></tr>`).join('')}
          </tbody></table></div></section>
      </div></div>`;
  },
  collect(el) {
    const f = $('#sopf', el);
    const lines = (s) => s.split('\n').map((x) => x.trim()).filter(Boolean);
    const nums = (s) => s.split(/[,;\s]+/).map((x) => x.trim()).filter(Boolean);
    const tb = (r) => { const o = { t: $('.f-t', r).value.trim() }; const b = lines($('.f-b', r).value); if (b.length) o.b = b; return o; };
    const d = this.draft;
    d.name = $('#sp_name', f).value.trim();
    d.phase = Number($('#sp_phase', f).value);
    d.accText = $('#sp_acct', f).value.trim();
    d.accountable = $$('[data-dc="accountable"]', f).filter((c) => c.checked).map((c) => c.value);
    d.responsible = $$('[data-dc="responsible"]', f).filter((c) => c.checked).map((c) => c.value);
    d.deps = nums($('#sp_deps', f).value).map(Number).filter(Boolean);
    d.conditional = $('#sp_cond', f).value.trim() || undefined;
    d.loop = $('#sp_loop', f).checked || undefined;
    d.inputs = $$('[data-rep="inputs"]', f).map((r) => { const o = tb(r); const from = nums($('.f-from', r).value); if (from.length) o.from = from; if ($('.f-dept', r).value) o.dept = $('.f-dept', r).value; return o; });
    d.tasks = $$('[data-rep="tasks"]', f).map(tb);
    d.outputs = $$('[data-rep="outputs"]', f).map((r) => {
      const o = tb(r); const n = $('.f-tfn', r).value;
      if (n !== '') o.tf = `${n} ${$('.f-tfu', r).value}`;
      if ($('.f-tfl', r).value.trim()) o.tfLabel = $('.f-tfl', r).value.trim();
      o.dept = $('.f-dept', r).value || (d.accountable[0] || null);
      o.to = nums($('.f-to', r).value).map(Number).filter(Boolean);
      if ($('.f-rel', r).value) o.rel = Number($('.f-rel', r).value);
      if ($('.f-fin', r).checked) o.fin = true;
      if ($('.f-as', r).checked) o.assumed = true;
      const so = $$('.f-so', r).filter((c) => c.checked).map((c) => c.value); if (so.length) o.signoff = so;
      const rc = $$('.f-rc', r).filter((c) => c.checked).map((c) => c.value); if (rc.length) o.rcpt = rc;
      const by = $$('.f-by', r).filter((c) => c.checked).map((c) => c.value); if (by.length) o.by = by;
      const ck = $$('.f-ck', r).filter((c) => c.checked).map((c) => c.value); if (ck.length) o.checkers = ck;
      if ($('.f-grp', r).value.trim()) o.group = $('.f-grp', r).value.trim();
      if ($('.f-def', r).checked) {
        o.defer = true; o.deferLabel = $('.f-defl', r).value.trim() || 'Long-running output pending';
        const rv = $('.f-relto', r).value.trim(); const rt = nums(rv).map(Number).filter(Boolean);
        if (rv === '0') o.releaseTo = []; else if (rt.length) o.releaseTo = rt;
      }
      return o;
    });
    d.notes = $$('[data-rep="notes"]', f).map((r) => {
      const items = [];
      $('.f-items', r).value.split('\n').forEach((l) => {
        const t = l.trim(); if (!t) return;
        if (/^[-•]\s+/.test(t) && items.length) { const it = items[items.length - 1]; (it.b = it.b || []).push(t.replace(/^[-•]\s+/, '')); } else items.push({ t });
      });
      return { title: $('.f-title', r).value.trim(), items };
    });
    return d;
  },
  b_sop(el) {
    const v = this;
    const rerender = () => { Main.render(true); };
    $$('[data-sop]', el).forEach((b) => { b.onclick = () => { v.sopNo = Number(b.dataset.sop); v.sopData = null; rerender(); }; });
    $$('[data-add]', el).forEach((b) => { b.onclick = () => {
      v.collect(el); const k = b.dataset.add;
      const blank = { inputs: { t: '' }, tasks: { t: '' }, outputs: { t: '', tf: '5 WD', to: [] }, notes: { title: '', items: [] } }[k];
      (v.draft[k] = v.draft[k] || []).push(blank); rerender();
    }; });
    $$('[data-rm]', el).forEach((b) => { b.onclick = () => { v.collect(el); const [k, i] = b.dataset.rm.split(':'); v.draft[k].splice(Number(i), 1); rerender(); }; });
    $$('[data-mv]', el).forEach((b) => { b.onclick = () => { v.collect(el); const [k, i, dir] = b.dataset.mv.split(':'); const a = v.draft[k]; const j = Number(i) + Number(dir); [a[i], a[j]] = [a[j], a[i]]; rerender(); }; });
    $$('[data-load]', el).forEach((b) => { b.onclick = () => { const ver = v.sopData.versions.find((x) => x.id === Number(b.dataset.load)); v.draft = JSON.parse(JSON.stringify(ver.data)); rerender(); toast('Version loaded into the editor (not saved yet)'); }; });
    $$('[data-wd]', el).forEach((b) => { b.onclick = async () => { await api('DELETE', `/api/admin/sop/version/${b.dataset.wd}`); v.sopData = null; toast('Future version withdrawn'); rerender(); }; });
    $('#sp_save', el).onclick = async () => {
      try {
        const data = v.collect(el);
        if (!data.name) return toast('Step name is required', 'err');
        if (!data.outputs.length) return toast('At least one output is required', 'err');
        await api('POST', `/api/admin/sop/${v.sopNo}`, { data, effective_from: $('#sp_eff').value, product_id: $('#sp_scope').value || null, note: $('#sp_note').value });
        v.sopData = null; App.meta = await api('GET', '/api/meta');
        toast(`<b>SOP step ${v.sopNo} saved</b>New version effective ${fmtDate($('#sp_eff').value)}.`); rerender();
      } catch (e) { fail(e); }
    };
  },

  // ---------- document list ----------
  async s_doctypes() {
    return `<div class="panel pad"><p class="small muted" style="margin:0 0 10px">The constant list of SOP-controlled documents. Uploads are attached to the step(s) listed here. A required document belongs to one output of its step: that output cannot be checked — and the step cannot be completed — until at least one version is uploaded (a message alone is not accepted).</p>
      <button class="btn primary" data-dt="">+ Add document</button></div>
      ${App.meta.docSections.map((sec) => `<section class="section"><header><h2>${esc(sec)}</h2></header><div class="tablewrap"><table class="grid"><tbody>
        ${App.meta.docTypes.filter((t) => t.section === sec).map((t) => `<tr><td>${esc(t.name)}${t.active ? '' : ' <span class="tag">hidden</span>'}</td><td class="mono" style="width:120px">step ${t.steps.join(', ')}</td><td style="width:230px">${t.required_step ? `<span class="tag teal">required · step ${t.required_step}${t.required_output ? `, output ${t.required_output}` : ''}</span>` : '<span class="faint small">optional</span>'}</td><td style="width:80px"><button class="btn sm" data-dt="${t.id}">Edit</button></td></tr>`).join('') || '<tr><td class="muted">No documents in this section.</td></tr>'}
      </tbody></table></div></section>`).join('')}`;
  },
  b_doctypes(el) {
    $$('[data-dt]', el).forEach((b) => { b.onclick = () => {
      const t = App.meta.docTypes.find((x) => x.id === Number(b.dataset.dt)) || { section: App.meta.docSections[0], name: '', steps: [], active: 1, required_step: null };
      modal({
        title: t.id ? 'Edit document' : 'Add document', width: 560,
        body: `<label class="field"><span>Section</span><input type="text" id="dt_s" list="dt_secs" value="${esc(t.section)}"><datalist id="dt_secs">${App.meta.docSections.map((s) => `<option value="${esc(s)}">`).join('')}</datalist></label>
          <label class="field"><span>Document name</span><textarea id="dt_n" rows="2">${esc(t.name)}</textarea></label>
          <label class="field"><span>Uploaded at step(s)</span><input type="text" id="dt_st" value="${t.steps.join(', ')}"></label>
          <div class="formgrid"><label class="field"><span>Required at step (empty = optional)</span><input type="number" id="dt_rq" min="1" value="${t.required_step || ''}"></label>
          <label class="field"><span>…as part of output no.</span><input type="number" id="dt_ro" min="1" value="${t.required_output || ''}"></label></div>
          ${t.id ? `<label class="check"><input type="checkbox" id="dt_a" ${t.active ? 'checked' : ''}> Visible</label>` : ''}`,
        actions: [{ label: 'Cancel' }, { label: 'Save', primary: true, onClick: async (w) => {
          await api('POST', '/api/admin/doctypes', { id: t.id, section: $('#dt_s', w).value, name: $('#dt_n', w).value, steps: $('#dt_st', w).value.split(/[,\s]+/).filter(Boolean), required_step: $('#dt_rq', w).value || null, required_output: $('#dt_ro', w).value || null, active: t.id ? $('#dt_a', w).checked : true });
          App.meta = await api('GET', '/api/meta'); toast('Document list saved'); Main.render(true);
        } }],
      });
    }; });
  },

  // ---------- database ----------
  async s_database() {
    const products = await api('GET', '/api/products?all=1');
    return `
    ${App.isAdmin() ? `<div class="panel pad"><h3 style="font-size:15px">Whole application database</h3>
      <p class="small muted" style="margin:4px 0 10px">One SQLite file with products, steps, System-Upload messages, notes, users and SOP versions. Uploaded documents are stored as files in the server's <span class="mono">data/files</span> folder (keeps the database small and fast) — the IT backup must include the whole <span class="mono">data</span> folder. The server also keeps an automatic daily copy of the database in <span class="mono">data/backups</span> (last 14 days).</p>
      <div class="row"><a class="btn primary" href="/api/export/db">Download full database</a><button class="btn" id="bk_go">Save a backup copy on the server now</button></div>
      <details style="margin-top:10px"><summary class="small" style="cursor:pointer">How to restore a backup</summary><ol class="small"><li>Stop the application on the server.</li><li>Replace <span class="mono">data/sop-tracker.sqlite</span> with the backup file (rename it to that name) and delete the <span class="mono">-wal</span> / <span class="mono">-shm</span> files next to it. Restore the <span class="mono">data/files</span> folder from the same IT backup date.</li><li>Start the application again.</li></ol></details></div>` : ''}
    <div class="panel pad" style="margin-top:14px"><h3 style="font-size:15px">Export one product</h3>
      <p class="small muted" style="margin:4px 0 10px">ZIP = product.json + steps.csv + System-Upload messages + every uploaded document version in folders by step and output. JSON = data only.</p>
      <div class="row"><select id="ex_p">${products.map((p) => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select>
      <button class="btn" id="ex_zip">Download ZIP</button><button class="btn" id="ex_json">Download JSON</button><button class="btn" id="ex_csv">Steps CSV</button></div></div>
    <div class="panel pad" style="margin-top:14px"><h3 style="font-size:15px">Export a tab (CSV, opens in Excel)</h3>
      <div class="row" style="margin-top:8px"><a class="btn" href="/api/export/csv/dashboard">Dashboard — products</a><a class="btn" href="/api/export/csv/analytics">Department analytics (this month)</a><a class="btn" href="/api/export/csv/mydept">My department</a><a class="btn" href="/api/export/csv/documents">Document archive</a><a class="btn" href="/api/export/csv/notifications">Notifications</a></div></div>`;
  },
  b_database(el) {
    if ($('#bk_go', el)) $('#bk_go', el).onclick = async () => { try { const r = await api('POST', '/api/admin/backup', {}); toast(`<b>Backup saved</b><span class="mono small">${esc(r.file)}</span>`); } catch (e) { fail(e); } };
    const p = () => $('#ex_p', el).value;
    if (!$('#ex_p', el)) return;
    $('#ex_zip', el).onclick = () => download(`/api/export/product/${p()}`);
    $('#ex_json', el).onclick = () => download(`/api/export/product/${p()}?format=json`);
    $('#ex_csv', el).onclick = () => download(`/api/export/csv/flow?product=${p()}`);
  },

  // ---------- upload rules: outputs where a file upload is mandatory ----------
  async s_rules() {
    const r = await api('GET', '/api/admin/output-rules');
    const on = new Set(r.rules.map((x) => `${x.step_no}.${x.output_idx}`));
    const by = new Map(r.rules.map((x) => [`${x.step_no}.${x.output_idx}`, x]));
    const q = (this.ruleQ || '').toLowerCase();
    const onlyOn = !!this.ruleOn;
    const steps = r.steps.map((s) => ({ ...s, outputs: s.outputs.filter((o) => (!onlyOn || on.has(`${s.no}.${o.idx}`) || o.docs.length) && (!q || `${s.no} ${s.name} ${o.t}`.toLowerCase().includes(q))) })).filter((s) => s.outputs.length);
    const admin = App.isAdmin();
    return `<div class="panel pad">
      <p class="small muted" style="margin:0 0 10px">Every output needs a System-Upload (a file or a short message) before it can be checked. Switch on <b>File upload required</b> for an output when a message alone must not be enough — the output can then only be checked after at least one file is uploaded to it. Outputs that carry an SOP-controlled document always need that document. Changes apply immediately to every product (outputs already checked are not affected).</p>
      <div class="toolbar" style="margin:0 0 10px"><input type="search" id="ru_q" placeholder="Search step, output…" value="${esc(this.ruleQ || '')}" style="width:260px">
        <label class="check"><input type="checkbox" id="ru_on" ${onlyOn ? 'checked' : ''}> Only outputs with a mandatory file / document</label><span class="small muted">${on.size} output${on.size === 1 ? '' : 's'} switched on</span></div>
      <div class="tablewrap"><table class="grid rules"><thead><tr><th style="width:70px">Step</th><th style="width:60px">Output</th><th>Output (SOP text)</th><th style="width:230px">File upload required</th></tr></thead><tbody>
      ${steps.map((s) => `<tr class="grprow"><td colspan="4"><b>Step ${s.no}</b> · ${esc(s.name)}</td></tr>${s.outputs.map((o) => { const k = `${s.no}.${o.idx}`; const x = by.get(k); return `<tr>
        <td class="mono">${s.no}</td><td class="mono">${o.idx}</td><td>${o.group ? `<div class="small muted">${esc(o.group)}</div>` : ''}${esc(o.t)}${o.docs.length ? `<div class="small"><span class="tag teal">SOP-controlled</span> <span class="muted">${esc(o.docs.join('; '))}</span></div>` : ''}</td>
        <td>${o.docs.length ? '<span class="tag green">Always — SOP-controlled document</span>' : `<label class="switch"><input type="checkbox" data-rule="${k}" ${on.has(k) ? 'checked' : ''} ${admin ? '' : 'disabled'}><span>${on.has(k) ? 'Required' : 'Off'}</span></label>${x ? `<div class="small faint">${esc(x.updated_by || '')} · ${esc(fmtDT(x.updated_at))}</div>` : ''}`}</td></tr>`; }).join('')}`).join('') || '<tr><td colspan="4" class="muted">No output matches.</td></tr>'}
      </tbody></table></div></div>`;
  },
  b_rules(el) {
    const v = this;
    let t; $('#ru_q', el).oninput = (e) => { clearTimeout(t); t = setTimeout(() => { v.ruleQ = e.target.value; Main.render(true); }, 300); };
    $('#ru_on', el).onchange = (e) => { v.ruleOn = e.target.checked; Main.render(true); };
    $$('[data-rule]', el).forEach((c) => { c.onchange = async () => {
      const [no, idx] = c.dataset.rule.split('.').map(Number);
      try { await api('PUT', '/api/admin/output-rules', { step_no: no, output_idx: idx, file_required: c.checked }); toast(`Step ${no}, output ${idx}: file upload ${c.checked ? 'required' : 'no longer required'}`); Main.render(true); }
      catch (e) { fail(e); c.checked = !c.checked; }
    }; });
  },

  // ---------- general settings ----------
  async s_settings() {
    return `<div class="panel pad"><div class="formgrid">
      <label class="field"><span>Company / plant name (shown in the header and sign-in page)</span><input type="text" id="st_c" value="${esc(App.meta.company)}"></label>
      <label class="field"><span>Maximum upload size (MB)</span><input type="number" id="st_u" value="${App.meta.uploadMaxMb}" min="1" max="1000"></label>
      <label class="field full"><span>SOP general recommendations (shown under the workflow of every product; one per line, start a line with “- ” for a sub-bullet)</span>
        <textarea id="st_g" rows="8">${esc((App.meta.generalNotes || []).map((i) => [i.t, ...(i.b || []).map((b) => `- ${b}`)].join('\n')).join('\n'))}</textarea></label>
    </div><button class="btn primary" id="st_go" style="margin-top:12px">Save settings</button></div>`;
  },
  b_settings(el) {
    $('#st_go', el).onclick = async () => { await api('PUT', '/api/admin/settings', { company_name: $('#st_c').value, upload_max_mb: $('#st_u').value, general_notes: (() => { const out = []; $('#st_g').value.split('\n').forEach((l) => { const t = l.trim(); if (!t) return; if (/^[-•]\s+/.test(t) && out.length) (out[out.length - 1].b = out[out.length - 1].b || []).push(t.replace(/^[-•]\s+/, '')); else out.push({ t }); }); return out; })() }); App.meta = await api('GET', '/api/meta'); Main.shell(); Main.route(); toast('Settings saved'); };
  },
};
