'use strict';
/* Announcement — administrator, Business Development and Plant Manager send a message (with or without files)
   to one, several or all departments, about one product or in general. It arrives in their Notifications. */
App.views.announce = {
  draft: { depts: [], all: false, product: '', subject: '', text: '' },
  files: [],
  async load() {
    if (!App.canAnnounce()) return '<div class="panel empty">Announcements are sent by the administrator, Business Development and the Plant Manager.</div>';
    const [products, hist] = await Promise.all([api('GET', '/api/products'), api('GET', '/api/announcements')]);
    const d = this.draft;
    const depts = App.meta.departments.filter((x) => x.code !== 'ADM' && x.active !== 0);
    return `<div class="pagehead"><div><h1>Announcement</h1><p>Send a message — with or without attached files — to one, several or all departments, about a product or in general. It arrives at once in the Notifications of the selected departments.</p></div></div>
    <div class="annwrap">
      <section class="panel pad annform">
        <h3 style="margin-top:0">New announcement</h3>
        <div class="field"><span>To departments</span>
          <label class="check allck"><input type="checkbox" id="an_all" ${d.all ? 'checked' : ''}> <b>All departments</b></label>
          <div class="deptgrid">${depts.map((x) => `<label class="check"><input type="checkbox" class="an_d" value="${x.code}" ${d.all || d.depts.includes(x.code) ? 'checked' : ''} ${d.all ? 'disabled' : ''}> ${esc(x.name)}</label>`).join('')}</div>
        </div>
        <label class="field"><span>Regarding product</span><select id="an_p"><option value="">General — not about one product</option>${products.filter((p) => p.status !== 'archived').map((p) => `<option value="${p.id}" ${String(d.product) === String(p.id) ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}</select></label>
        <label class="field"><span>Subject (optional)</span><input type="text" id="an_s" maxlength="200" value="${esc(d.subject)}" placeholder="e.g. Updated plan for pilot batches"></label>
        <label class="field"><span>Message</span><textarea id="an_t" rows="6" placeholder="Write the announcement…">${esc(d.text)}</textarea></label>
        <div class="field"><span>Attachments (optional)</span>
          <div class="row"><button class="btn sm" id="an_add">Add files…</button><span class="small muted">Up to ${App.meta.uploadMaxMb} MB each</span></div>
          ${this.files.length ? `<div class="annfiles">${this.files.map((f, i) => `<span class="fchip">📎 ${esc(f.name)} <span class="small muted">${fmtSize(f.size)}</span> <button class="btn sm ghost" data-rmf="${i}" title="Remove">✕</button></span>`).join('')}</div>` : ''}
        </div>
        <div class="row" style="margin-top:6px"><button class="btn primary" id="an_send">Send announcement</button><span class="small muted" id="an_info"></span></div>
      </section>
      <section class="annhist">
        <h3 style="margin:0 0 8px">Sent announcements <span class="small muted">(${hist.total})</span></h3>
        ${hist.rows.length ? hist.rows.map((a) => `<div class="panel pad anncard">
          <div class="row" style="justify-content:space-between;align-items:baseline"><b>${esc(a.subject || 'Announcement')}</b><span class="small muted mono">${esc(fmtDT(a.created_at))}</span></div>
          <div class="small muted">From ${esc(a.full_name || a.username)} (${esc(deptName(a.dept))}) · ${a.product ? `about <b>${esc(a.product)}</b>` : 'general'}</div>
          <div class="row" style="gap:4px;margin:6px 0">${a.depts.length >= depts.length ? '<span class="tag teal">All departments</span>' : a.depts.map((x) => deptTag(x)).join('')}</div>
          <div class="mb">${linkify(a.text)}</div>
          ${a.files.length ? `<div class="annfiles">${a.files.map((f) => `<a href="/api/announcements/files/${f.id}" target="_blank" rel="noopener">📎 ${esc(f.filename)}</a> <span class="small muted">${fmtSize(f.size)}</span>`).join(' ')}</div>` : ''}
        </div>`).join('') : '<div class="panel empty">No announcement sent yet.</div>'}
      </section>
    </div>`;
  },
  bind(el) {
    const v = this; const d = v.draft;
    const sync = () => {
      d.all = $('#an_all', el).checked;
      d.depts = $$('.an_d', el).filter((c) => c.checked).map((c) => c.value);
      d.product = $('#an_p', el).value; d.subject = $('#an_s', el).value; d.text = $('#an_t', el).value;
      $('#an_info', el).textContent = d.all ? 'To all departments' : d.depts.length ? `To ${d.depts.length} department${d.depts.length > 1 ? 's' : ''}` : '';
    };
    if (!$('#an_all', el)) return;
    $('#an_all', el).onchange = () => { sync(); $$('.an_d', el).forEach((c) => { c.disabled = d.all; c.checked = d.all || d.depts.includes(c.value); }); sync(); };
    $$('.an_d, #an_p', el).forEach((c) => { c.onchange = sync; });
    $$('#an_s, #an_t', el).forEach((c) => { c.oninput = sync; });
    sync();
    $('#an_add', el).onclick = () => {
      const inp = document.createElement('input'); inp.type = 'file'; inp.multiple = true;
      inp.onchange = () => { sync(); v.files.push(...inp.files); Main.render(true); };
      inp.click();
    };
    $$('[data-rmf]', el).forEach((b) => { b.onclick = () => { sync(); v.files.splice(Number(b.dataset.rmf), 1); Main.render(true); }; });
    $('#an_send', el).onclick = async (e) => {
      sync();
      if (!d.all && !d.depts.length) return toast('Choose at least one department (or All departments)', 'err');
      if (!d.text.trim()) return toast('Write the message first', 'err');
      const btn = e.currentTarget; btn.disabled = true; btn.textContent = 'Sending…';
      try {
        const ids = [];
        for (const f of v.files) {
          if (f.size > (App.meta.uploadMaxMb || 200) * 1048576) throw new Error(`${f.name} is larger than ${App.meta.uploadMaxMb} MB`);
          const r = await api('POST', `/api/announcements/upload?${new URLSearchParams({ name: f.name })}`, f, { type: f.type || 'application/octet-stream' });
          ids.push(r.id);
        }
        await api('POST', '/api/announcements', { depts: d.all ? '*' : d.depts, product_id: d.product || null, subject: d.subject, text: d.text, files: ids });
        toast(`<b>Announcement sent</b>${d.all ? 'All departments' : d.depts.map(deptShort).join(', ')}`);
        v.draft = { depts: [], all: false, product: '', subject: '', text: '' }; v.files = [];
        Main.render(true);
      } catch (err) { fail(err); btn.disabled = false; btn.textContent = 'Send announcement'; }
    };
  },
};
