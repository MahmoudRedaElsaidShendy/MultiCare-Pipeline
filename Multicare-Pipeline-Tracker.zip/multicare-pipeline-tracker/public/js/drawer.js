'use strict';
/* Step detail panel — inputs, tasks, outputs, documents, notes, risks, history */
const Drawer = {
  pid: null, no: null, d: null, el: null,
  async open(pid, no, fromRoute) {
    if (!fromRoute) { location.hash = `#/flow/${pid}?pid=${pid}&step=${no}`; return; }
    const same = this.pid === pid && this.no === no && this.el;
    this.pid = pid; this.no = no;
    if (!this.el) {
      this.el = document.createElement('div');
      this.el.innerHTML = '<div class="scrim"></div><aside class="drawer" role="dialog" aria-modal="true"><div class="empty">Loading…</div></aside>';
      document.body.appendChild(this.el);
      $('.scrim', this.el).onclick = () => Drawer.close();
      this.onKey = (e) => { if (e.key === 'Escape' && !$('.modal')) Drawer.close(); };
      document.addEventListener('keydown', this.onKey);
    }
    await this.refresh(!same, false);
  },
  close(fromRoute) {
    if (this.el) { this.el.remove(); this.el = null; document.removeEventListener('keydown', this.onKey); }
    const had = this.no; this.pid = null; this.no = null; this.d = null;
    if (!fromRoute && had) { const pid = App.params.args && App.params.args[0]; history.pushState(null, '', `#/flow/${pid || ''}`); App.params.step = undefined; App.params.pid = undefined; Main.render(true); }
  },
  // quiet = background refresh after a change elsewhere: on failure keep what is on screen
  async refresh(resetScroll, quiet = true) {
    if (!this.el || !this.no) return;
    const pid = this.pid; const no = this.no;
    let d;
    try { d = await api('GET', `/api/products/${pid}/steps/${no}`); } catch (e) {
      if (this.el && this.no === no && (!quiet || !this.d)) this.fail(e.message);
      return;
    }
    if (!this.el || this.no !== no || this.pid !== pid) return; // another step was opened meanwhile
    this.d = d;
    const box = $('.drawer', this.el);
    try {
      preserve(box, () => { box.innerHTML = this.html(d); this.bind(box, d); });
    } catch (e) {
      reportError(e, `step ${no}`);
      this.fail(`This step could not be displayed (${e.message}). The error was recorded in the server log.`);
      return;
    }
    if (resetScroll) { const b = $('.dbody', box); if (b) b.scrollTop = 0; }
  },
  fail(msg) {
    const box = this.el && $('.drawer', this.el); if (!box) return;
    this.d = null;
    box.innerHTML = `<div class="dhead"><div class="bigno">${this.no}</div><div><h2>${esc(App.stepName(this.no))}</h2></div><button class="btn ghost" data-close>✕</button></div>
      <div class="dbody"><div class="banner warn">${esc(msg)}</div><div style="margin-top:12px"><button class="btn primary" data-retry>Try again</button></div></div>`;
    $('[data-close]', box).onclick = () => Drawer.close();
    $('[data-retry]', box).onclick = () => { box.innerHTML = '<div class="empty">Loading…</div>'; Drawer.refresh(true, false); };
  },

  html(d) {
    const phase = App.meta.phases.find((p) => p.no === d.phase);
    if (d.restricted) return `<div class="dhead"><div class="bigno">${d.no}</div><div><h2>${esc(d.name)}</h2></div><button class="btn ghost" data-close>✕</button></div><div class="dbody"><div class="banner warn">You have no access to this step. Ask the administrator if you need it.</div></div>`;
    const edit = d.level === 'edit';
    const late = d.overdueDays > 0 && d.state !== 'done' && d.state !== 'na';
    const tfs = [...new Set(d.outputs.map((o) => o.tfShort))];
    const flow = App.meta.flow.find((g) => g.steps.includes(d.no));
    const grpText = flow ? (flow.type === 'seq' ? 'Sequential' : flow.type === 'par' ? `Parallel with step ${flow.steps.filter((x) => x !== d.no).join(', ')}` : `Parallel & iterative loop with step ${flow.steps.filter((x) => x !== d.no).join(', ')}`) : '';
    const depts = [...new Set([...(d.def.accountable || []), ...(d.responsible || [])])];
    const isExec = App.isExec();
    const stateBox = d.state === 'waiting'
      ? `<div class="info"><div class="k">READY SINCE</div><div class="v">Waiting for ${d.deps.filter((x) => x.state !== 'done' && x.state !== 'na' && !x.released).map((x) => `step ${x.no}`).join(', ') || 'start date'}<div class="small muted">forecast ${fmtDate(d.fReady)}</div></div></div>`
      : `<div class="info"><div class="k">READY SINCE</div><div class="v">${fmtDate(d.readyDate)}</div></div>`;

    const dvById = new Map(d.docVersions.map((t) => [t.id, t]));
    const canPost = edit && d.state !== 'waiting';
    let lastGroup = null;
    const outputs = d.outputs.map((o) => {
      // multi-accountable steps: each output is checked by its own accountable department(s);
      // steps 20 / 33: filled by the named department, checked by the Plant Manager or QA
      const so = o.signoff || [];
      const ck = o.checkers || [];
      const mySign = so.length && (App.isAdmin() || so.includes(App.me.dept));
      const can = d.state === 'in_progress' && o.canCheck;
      const fill = canPost && o.canFill;
      const grpHead = o.group && o.group !== lastGroup ? `<div class="ogroup">${esc(o.group)}</div>` : '';
      lastGroup = o.group || null;
      const checked = o.state === 'done' || (so.length && !o.state && o.signs.some((g) => g.dept === App.me.dept));
      // System-Upload (file and/or message, plus the SOP-controlled documents) is required before checking
      const blocked = can && !checked && !o.state && !o.evidenceOk;
      const cls = o.state === 'done' ? 'done' : o.state === 'na' ? 'na' : o.overdue ? 'late' : '';
      const tip = !edit ? 'Editor rights are needed' : d.state === 'ready' ? 'Start the step first' : d.state !== 'in_progress' ? 'The step is not in progress' : so.length && !mySign ? `Checked by ${so.map(deptName).join(' and ')} only` : ck.length && !o.canCheck ? `Checked by ${ck.map(deptName).join(' or ')} (final accountability)` : blocked ? o.evidenceHint : 'Tick when this output is delivered';
      const nEv = o.files.length + o.msgs.length;
      const docRows = o.docs.map((dc) => {
        const t = dvById.get(dc.id); const last = t && t.versions[0];
        return `<div class="cdoc ${dc.uploaded ? 'ok' : 'miss'}"><span class="ic">${dc.uploaded ? '✓' : '!'}</span><div class="grow"><div>${esc(dc.name)} <span class="tag ${dc.uploaded ? 'teal' : 'red'}">${dc.uploaded ? 'SOP-controlled document' : 'SOP-controlled document · required'}</span></div>
          ${last ? `<div class="small muted">latest <b>v${last.version}</b> · <a href="/api/files/${last.id}" target="_blank" rel="noopener">${esc(last.filename)}</a> · ${esc(deptShort(last.dept))} · ${esc(last.full_name || last.username)} · ${fmtDT(last.uploaded_at)}</div>` : '<div class="small muted">No version uploaded yet — a message alone is not accepted for this document</div>'}</div>
          <span class="row" style="gap:6px">${t ? `<button class="btn sm" data-docv="${dc.id}">Versions (${t.versions.length})</button>` : ''}${fill ? `<button class="btn sm primary" data-docup="${dc.id}">${last ? 'Upload new version' : 'Upload document'}</button>` : ''}</span></div>`;
      }).join('');
      const evList = [...o.files.filter((f) => !f.doc_type_id).map((f) => ({ k: 'f', at: f.uploaded_at, f })), ...o.msgs.map((m) => ({ k: 'm', at: m.created_at, m }))].sort((a, b) => (a.at < b.at ? -1 : 1));
      const evHtml = (x) => (x.k === 'f' ? `<div class="evrow">${fileChip(x.f)}</div>` : msgCard(x.m));
      const sysup = `<div class="sysup ${o.state ? '' : nEv || (o.docs.length && o.docs.every((x) => x.uploaded)) ? 'has' : 'need'}">
        <div class="suh"><b>System-Upload</b><span class="small muted">to</span>${o.rcpt.map((c) => deptTag(c)).join('')}
          <span class="spacer"></span>${o.state ? '' : nEv || o.docs.length ? `<span class="small ${o.evidenceOk ? 'okc' : 'warnc'}">${o.evidenceOk ? '✓ ready to be checked' : esc(o.evidenceHint || '')}</span>` : '<span class="small warnc">Required before this output can be checked</span>'}</div>
        ${docRows}
        ${evList.length > 6 ? `<details class="evmore"><summary class="small">Show ${evList.length - 4} earlier upload${evList.length - 4 > 1 ? 's' : ''} / message${evList.length - 4 > 1 ? 's' : ''}</summary>${evList.slice(0, -4).map(evHtml).join('')}</details>${evList.slice(-4).map(evHtml).join('')}` : evList.map(evHtml).join('')}
        ${fill ? `<div class="composer"><textarea id="msg${o.idx}" rows="2" placeholder="Short message to ${esc(o.rcpt.map(deptShort).join(', '))} (replaces e-mail)…"></textarea>
          <div class="row"><button class="btn sm primary" data-msg="${o.idx}">Send message</button><button class="btn sm ${o.fileReq ? 'primary' : ''}" data-upl="${o.idx}">Upload file</button><button class="btn sm ghost" data-link="${o.idx}">Add link</button></div></div>`
          : canPost && o.by.length && !o.state ? `<div class="small faint">Filled by ${esc(o.by.map(deptName).join(', '))}${ck.length ? ` or ${esc(ck.map(deptShort).join(' / '))}` : ''}.</div>` : ''}
      </div>`;
      return `${grpHead}<div class="oitem ${cls} ${o.defer ? 'longrun' : ''} ${o.group ? 'ingroup' : ''}">
        <input type="checkbox" data-out="${o.idx}" ${checked ? 'checked' : ''} ${can && o.state !== 'na' && !blocked ? '' : 'disabled'} aria-label="Output ${o.idx} delivered" title="${esc(tip)}">
        <div>
          <div class="txt"><span class="num">${o.idx}.</span> ${linkify(o.t)}${o.b.length ? `<ul>${o.b.map((b) => `<li>${linkify(b)}</li>`).join('')}</ul>` : ''}</div>
          <div class="ometa">
            ${o.by.length ? `<span class="small muted">filled by</span>${o.by.map((x) => deptTag(x, 'teal')).join('')}` : o.dept ? deptTag(o.dept, 'teal') : ''}
            ${ck.length ? `<span class="small muted">checked by</span><span class="tag">${esc(ck.map(deptShort).join(' or '))}</span>` : ''}
            ${o.fileReq ? '<span class="tag amber" title="Set in Settings → Upload rules: a message alone is not enough">file upload required</span>' : ''}
            <span title="SOP timeframe">⏱ ${esc(o.tfText)}${o.assumed ? ' <span class="tag" title="The SOP does not state a timeframe for this output. Default value — edit it in SOP Control.">default</span>' : ''}</span>
            ${o.due ? `<span>due <b class="mono">${fmtDate(o.due)}</b></span>` : o.fDue ? `<span class="faint">≈ due ${fmtDate(o.fDue)}</span>` : ''}
            ${o.overdue ? `<span class="tag red">${o.overdue} d overdue</span>` : ''}
            ${o.fin ? '<span class="tag" title="Delivered after the loop reaches the formula of choice">final output after loop</span>' : ''}
            ${o.defer ? `<span class="tag amber" title="Long-running output: the next steps may start once every other output of this step is delivered">long-running · ${!o.releaseTo ? 'next steps may start before it' : o.releaseTo.length ? `step ${o.releaseTo.join(', ')} may start before it` : 'next steps wait for it'}</span>` : ''}
            ${o.to.length ? `<span>hand-off → ${o.to.map((t) => `<span class="steplink" data-open-step="${t}" data-pid="${d.product.id}">step ${t}</span>`).join(', ')}</span>` : ''}
            ${o.state ? `<span class="${o.state === 'na' ? '' : ''}">${o.state === 'done' ? '✓ delivered' : 'not applicable'} ${fmtDT(o.at)} · ${esc(o.by)}${o.reason ? ` — ${esc(o.reason)}` : ''}</span>` : ''}
            ${can && !o.state && !(so.length && o.signs.length) ? `<button class="btn sm ghost" data-outna="${o.idx}">Not applicable</button>` : ''}
            ${can && o.state === 'na' ? `<button class="btn sm ghost" data-outre="${o.idx}">Undo not applicable</button>` : ''}
          </div>
          ${so.length ? `<div class="signs"><span class="small muted">${so.length > 1 ? `Must be checked by ${so.length === 2 ? 'both' : `all ${so.length}`}:` : 'Checked by its accountable:'}</span>${so.map((dp) => { const g = o.signs.find((x) => x.dept === dp); return g ? `<span class="sign ok" title="${esc(fmtDT(g.at))}">✓ ${esc(deptShort(dp))} · ${esc(g.by)}</span>` : `<span class="sign">${esc(deptShort(dp))} · pending</span>`; }).join('')}</div>` : ''}
          ${sysup}
        </div></div>`;
    }).join('');

    const inputs = d.inputs.map((i) => {
      const can = edit && (d.state === 'ready' || d.state === 'in_progress');
      return `<div class="iitem ${i.confirmed ? 'oitem done' : ''}" style="${i.confirmed ? '' : ''}">
        <input type="checkbox" data-in="${i.idx}" ${i.confirmed ? 'checked' : ''} ${can ? '' : 'disabled'} aria-label="Input ${i.idx} received" title="${can ? 'Tick to confirm you received and checked this input' : 'Editor rights and a ready / in-progress step are needed'}">
        <div><div class="txt"><span class="num">${i.idx}.</span> ${linkify(i.t)}${i.b.length ? `<ul>${i.b.map((b) => `<li>${linkify(b)}</li>`).join('')}</ul>` : ''}</div>
          <div class="ometa">
            ${i.sources.length ? `<span class="sources">${i.sources.map((s) => `<span class="src ${s.ok ? 'ok' : ''} steplink" data-open-step="${s.step}" data-pid="${d.product.id}" title="${esc(s.name)}">step ${s.step}${s.out ? ` · output ${s.out}` : ''} ${s.ok ? '✓ delivered' : '… pending'}</span>`).join('')}</span>` : ''}
            ${i.dept ? `<span>from ${deptTag(i.dept)}</span>` : ''}
            ${i.confirmed ? `<span>✓ received ${fmtDT(i.at)} · ${esc(i.by)}</span>` : (i.available === false ? '<span class="small" style="color:var(--prog)">source output not delivered in the app yet</span>' : '')}
          </div>
          ${i.delivered.length ? `<div class="delivered">${i.delivered.map((g) => `<div class="dgrp"><div class="dgh small"><span class="steplink" data-open-step="${g.step}" data-pid="${d.product.id}">Step ${g.step} · output ${g.out}</span> — System-Upload received</div>${g.files.map((f) => `<div class="evrow">${fileChip(f)}</div>`).join('')}${g.msgs.map((m) => msgCard(m)).join('')}</div>`).join('')}</div>`
            : i.sources.length ? '<div class="small faint" style="margin-top:4px">Nothing uploaded by the source step yet.</div>' : ''}
        </div></div>`;
    }).join('');

    const docs = d.docVersions.filter((t) => !t.out).map((t) => {
      const last = t.versions[0];
      return `<div class="oitem ${t.required && !last ? 'late' : ''}"><span class="num">📁</span><div><div class="txt">${esc(t.name)} <span class="tag">${esc(t.section)}</span>${t.required ? ` <span class="tag ${last ? 'teal' : 'red'}" title="At least one version must be uploaded before this step can be completed">${last ? 'required ✓' : 'required before completion'}</span>` : ''}</div>
        <div class="ometa">${last ? `<span>latest <b>v${last.version}</b> · <a href="/api/files/${last.id}" target="_blank" rel="noopener">${esc(last.filename)}</a> · ${esc(deptShort(last.dept))} · ${esc(last.full_name || last.username)} · ${fmtDT(last.uploaded_at)}</span>` : '<span>No version uploaded yet</span>'}
        <button class="btn sm" data-docv="${t.id}">All versions (${t.versions.length})</button>${edit ? `<button class="btn sm primary" data-docup="${t.id}">Upload ${last ? 'new version' : 'document'}</button>` : ''}</div></div></div>`;
    }).join('');

    const note = (n, incoming) => `<div class="note ${incoming ? 'in' : ''}"><div class="h">${incoming ? `From step ${n.step_no} (${esc(App.stepName(n.step_no))}) · ` : ''}<b>${esc(n.full_name || n.username)}</b> · ${esc(deptShort(n.dept))} · ${fmtDT(n.created_at)}${n.to_depts.length ? ` · to ${n.to_depts.map(deptShort).map(esc).join(', ')}` : ''}</div><div class="b">${linkify(n.text)}</div></div>`;
    const defaultRecip = [...new Set(d.handoff.flatMap((h) => { const s = App.step(h.no); return s ? [...s.accountable, ...s.responsible] : []; }))];

    const btn = (cond, attrs, label, cls = '') => (cond ? `<button class="btn ${cls}" ${attrs}>${label}</button>` : '');
    const pendingSign = d.outputs.filter((o) => !o.state && o.signoff.length && o.signs.length).map((o) => o.signoff.filter((x) => !o.signs.some((g) => g.dept === x)).map(deptShort).join(' & '));
    const whyNot = edit && !d.canComplete && d.state === 'in_progress'
      ? (d.inputs.some((i) => !i.confirmed) ? 'Confirm all inputs first'
        : d.outputs.some((o) => !o.state) ? (pendingSign.length ? `Waiting for ${[...new Set(pendingSign)].join(', ')} to check their output` : d.released ? `Waiting for the long-running output (${d.deferLabels.join(', ')})` : 'Tick all outputs first')
          : d.missingDocs.length ? `Upload the required document${d.missingDocs.length > 1 ? 's' : ''} first` : '') : '';
    return `
    <div class="dhead">
      <div class="bigno">${d.no}</div>
      <div><div class="ctx">${esc((phase && phase.name) || '')} · ${esc(d.product.name)}</div><h2>${esc(d.name)}</h2>
        <div class="row">${pill(d.state, late ? d.overdueDays : 0)}${depts.map((c) => deptTag(c)).join('')}${grpText ? `<span class="small muted">${grpText}</span>` : ''}${d.level === 'view' ? '<span class="tag">view only</span>' : ''}</div></div>
      <button class="btn ghost" data-close aria-label="Close">✕</button>
    </div>
    <div class="dbody" data-scroll="drawer">
      <div class="infogrid">
        <div class="info"><div class="k">ACCOUNTABLE</div><div class="v">${esc(d.accText)}</div></div>
        <div class="info"><div class="k">SOP TIMEFRAME</div><div class="v">${tfs.map(esc).join(' · ') || '—'}</div></div>
        ${stateBox}
        ${d.responsible.length ? `<div class="info"><div class="k">RESPONSIBLE DEPARTMENTS</div><div class="v">${d.responsible.map((c) => esc(deptName(c))).join(', ')}</div></div>` : ''}
        <div class="info ${late ? 'alert' : ''}"><div class="k">DUE${d.due_override ? ' (changed)' : ''}${d.dues.length > 1 ? ' · ONE PER OUTPUT' : ''}</div><div class="v">${d.state === 'done' || d.state === 'na' ? (d.due ? fmtDate(d.due) : '—') : d.dues.length ? `<div class="duelist">${dueLines(d.dues)}</div>` : (d.due ? fmtDate(d.due) : `≈ ${fmtDate(d.fClose)}`)}</div>
          ${isExec && d.state !== 'done' && d.state !== 'na' ? `<div class="row" style="margin-top:6px"><input type="date" id="dueov" value="${d.due || ''}" style="padding:3px 6px"><button class="btn sm" data-due>Set</button>${d.due_override ? '<button class="btn sm ghost" data-dueclr>SOP date</button>' : ''}</div>` : ''}</div>
        <div class="info"><div class="k">READY → STARTED</div><div class="v">${d.waitWD == null ? '—' : `${d.waitWD} working day${d.waitWD === 1 ? '' : 's'}${d.state === 'ready' ? ' (not started yet)' : ''}`}</div></div>
        <div class="info"><div class="k">STARTED</div><div class="v">${d.started_at ? `${fmtDT(d.started_at)}<div class="small muted">${esc(d.started_by)}</div>` : '—'}</div></div>
        <div class="info"><div class="k">${d.state === 'na' ? 'CANCELLED' : 'COMPLETED'}</div><div class="v">${d.state === 'done' ? `${fmtDT(d.completed_at)}<div class="small ${d.onTime ? '' : ''}" style="color:${d.onTime ? 'var(--done)' : 'var(--late)'}">${d.onTime ? 'within timeframe' : `${d.lateDays} d after deadline`}</div>` : d.state === 'na' ? `${fmtDT(d.na_at)}<div class="small muted">${esc(d.na_reason)}</div>` : '—'}</div></div>
      </div>
      ${d.conditional ? `<div class="banner info">${esc(d.conditional)}. If the authority does not require it, mark this step as not applicable with the reason.</div>` : ''}
      ${d.loop ? `<div class="banner loop">↻ Iterative loop with step ${flow ? flow.steps.filter((x) => x !== d.no).join(', ') : ''}: repeat until the formula of choice is reached${d.iterations ? ` · ${d.iterations} iteration(s) logged` : ''}. Use “Log loop iteration” for each trial cycle; tick the final outputs once the formula of choice is reached.</div>` : ''}
      ${d.released && d.deferLabels.length ? `<div class="banner long">⧗ <b>${esc(d.deferLabels.join(' · '))}</b> — every other output is delivered, so the next step${d.handoff.length > 1 ? 's' : ''} could start on ${fmtDate(d.releaseDate)}. This step stays open until the long-running output is delivered.</div>` : ''}
      ${d.missingDocs.length && d.state !== 'waiting' ? `<div class="banner warn">Required document${d.missingDocs.length > 1 ? 's' : ''} not uploaded yet — the step cannot be completed without: ${d.missingDocs.map(esc).join('; ')}.</div>` : ''}
      ${d.level === 'view' ? '<div class="banner warn">View only — your department is not an editor of this step. You can still send a reminder, post notes and raise risk findings.</div>' : ''}

      <div class="blk"><h3>Depends on</h3><div class="chips">${d.deps.length ? d.deps.map((x) => `<button class="chip st-${x.state}" data-open-step="${x.no}" data-pid="${d.product.id}" ${x.released ? 'title="Released — only its long-running output is still pending"' : ''}>${x.no} · ${esc(x.name.length > 48 ? x.name.slice(0, 46) + '…' : x.name)}${x.released ? ' · released' : ''}</button>`).join('') : `<span class="muted">First step — ready on the product start date</span>`}</div></div>

      <div class="blk"><h3>Input (trigger) · ${d.inputsDone}/${d.inputs.length} confirmed</h3>${inputs || '<span class="muted">—</span>'}</div>
      <div class="blk"><h3>Key tasks</h3>${items(d.def.tasks)}</div>
      ${d.def.notes && d.def.notes.length ? `<div class="blk"><h3>SOP notes &amp; guidance</h3>${d.def.notes.map((n) => `<details class="sopnotes"><summary>${esc(n.title)}</summary>${items(n.items)}</details>`).join('')}</div>` : ''}

      <div class="blk"><h3>Required outputs · ${d.outputsDone}/${d.outputs.length} ticked</h3>${outputs}</div>
      ${docs ? `<div class="blk"><h3>Other SOP-controlled documents uploadable at this step</h3>${docs}</div>` : ''}

      <div class="blk"><h3>Hand-off to</h3><div class="chips">${d.handoff.length ? d.handoff.map((h) => `<button class="chip st-${h.state || 'waiting'}" data-open-step="${h.no}" data-pid="${d.product.id}">${h.no} · ${esc(h.name.length > 40 ? h.name.slice(0, 38) + '…' : h.name)}</button>`).join('') : '<span class="muted">End of pipeline</span>'}</div>
        ${d.handoff.length ? `<div class="small muted" style="margin-top:6px">${d.handoff.map((h) => `${h.no}: ${esc(h.acc)}`).join(' · ')}</div>` : ''}</div>

      ${d.incoming.length ? `<div class="blk notes"><h3>Notes delivered from previous steps</h3>${d.incoming.map((n) => note(n, true)).join('')}</div>` : ''}

      <div class="blk"><h3>Risk findings (${d.risks.filter((r) => r.status === 'open').length} open)</h3>
        ${d.risks.map((r) => `<div class="riskrow ${r.status}"><span class="tag sev-${r.severity}">${r.severity}</span><div><div>${esc(r.title)}</div><div class="small muted">${r.action ? `Action: ${esc(r.action)} · ` : ''}${r.owner_dept ? `Owner: ${esc(deptName(r.owner_dept))} · ` : ''}raised by ${esc(r.raised_by)} ${fmtDT(r.raised_at)}${r.status === 'closed' ? ` · closed ${fmtDT(r.closed_at)} by ${esc(r.closed_by)}${r.close_note ? ` — ${esc(r.close_note)}` : ''}` : ''}</div></div>
          ${r.status === 'open' ? `<button class="btn sm" data-rclose="${r.id}">Close</button>` : `<button class="btn sm ghost" data-ropen="${r.id}">Re-open</button>`}</div>`).join('')}
        <details ${d.risks.length ? '' : ''}><summary class="btn sm" style="display:inline-flex">+ Raise a risk finding</summary>
          <div class="formgrid" style="margin-top:10px">
            <label class="field"><span>Severity</span><select id="rk_sev"><option>Critical</option><option>Major</option><option>Minor</option></select></label>
            <label class="field"><span>Action owner</span><select id="rk_own"><option value="">—</option>${App.meta.departments.filter((x) => x.code !== 'ADM').map((x) => `<option value="${x.code}" ${d.def.accountable[0] === x.code ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select></label>
            <label class="field full"><span>Finding</span><textarea id="rk_t" rows="2" placeholder="What is the risk?"></textarea></label>
            <label class="field full"><span>Action needed</span><input type="text" id="rk_a" placeholder="What must be done, by when"></label>
            <div><button class="btn primary sm" data-radd>Raise finding</button></div>
          </div></details></div>

      <div class="blk notes"><h3>Notes &amp; discussion</h3>
        ${d.notes.length ? d.notes.map((n) => note(n)).join('') : '<p class="muted" style="margin:0 0 8px">No notes yet.</p>'}
        <textarea id="nt_text" rows="3" placeholder="Add a note (issue, decision, delay reason)…"></textarea>
        <div class="row" style="margin-top:6px"><span class="small muted">Deliver to:</span>
          ${App.meta.departments.filter((x) => x.code !== 'ADM').map((x) => `<label class="check small"><input type="checkbox" id="nt_d_${x.code}" data-ntd="${x.code}" ${defaultRecip.includes(x.code) ? 'checked' : ''}>${esc(deptShort(x.code))}</label>`).join('')}
        </div>
        <div class="row" style="margin-top:6px"><button class="btn sm" data-note>Post note</button><span class="small muted">The note also appears inside the hand-off steps (${d.handoff.map((h) => h.no).join(', ') || '—'}).</span></div>
      </div>

      <div class="blk"><h3>Step history</h3>${d.history.length ? `<div class="hist">${d.history.map((h) => `<div><time>${esc(fmtDT(h.at))}</time><span><b>${esc(h.username)}</b>${h.dept ? ` (${esc(deptShort(h.dept))})` : ''} — ${esc(h.detail || h.action)}</span></div>`).join('')}</div>` : '<span class="muted">No history yet.</span>'}</div>
    </div>
    <div class="dfoot">
      ${btn(edit && d.state === 'ready', 'data-act="start"', 'Start step', 'primary')}
      ${d.state === 'waiting' && edit ? '<button class="btn primary" disabled title="Waiting for the steps it depends on">Start step</button>' : ''}
      ${btn(edit && d.state === 'in_progress', `data-act="complete" ${d.canComplete ? '' : `aria-disabled="true" title="${whyNot}"`}`, 'Complete step', 'primary')}
      ${btn(d.loop && edit && d.state === 'in_progress', 'data-act="iterate"', '↻ Log loop iteration')}
      ${btn((edit || isExec) && d.state !== 'done' && d.state !== 'na', 'data-act="na"', 'Mark not applicable')}
      ${btn(d.state !== 'done' && d.state !== 'na', 'data-act="remind"', 'Send reminder')}
      ${btn(isExec && (d.state === 'done' || d.state === 'na'), 'data-act="reopen"', 'Re-open step')}
      <span class="spacer"></span>
      ${whyNot ? `<span class="small muted" style="align-self:center">${whyNot}</span>` : ''}
    </div>`;
  },

  bind(box, d) {
    const pid = this.pid; const no = this.no;
    const base = `/api/products/${pid}/steps/${no}`;
    const run = async (fn, msg) => { try { await fn(); if (msg) toast(msg); await Drawer.refresh(); } catch (e) { fail(e); } };
    $$('[data-close]', box).forEach((b) => { b.onclick = () => Drawer.close(); });
    if (d.restricted) return;
    $$('[data-act]', box).forEach((b) => {
      b.onclick = async () => {
        const a = b.dataset.act;
        if (b.getAttribute('aria-disabled') === 'true') return toast(esc(b.title), 'err');
        if (a === 'start') return run(() => api('POST', `${base}/action`, { action: 'start' }), `Step ${no} started`);
        if (a === 'complete') return run(() => api('POST', `${base}/action`, { action: 'complete' }), `<b>Step ${no} completed</b>Hand-off notifications were sent.`);
        if (a === 'na') { const r = await ask(`Mark step ${no} not applicable`, 'Reason for cancelling this step (shown on the dashboard)'); if (r !== null) run(() => api('POST', `${base}/action`, { action: 'na', reason: r }), `Step ${no} marked not applicable`); return; }
        if (a === 'remind') { const r = await ask(`Send reminder — step ${no}`, 'Message to the accountable departments', { required: false, okLabel: 'Send reminder', hint: `Goes to: ${[...new Set([...d.def.accountable, ...d.responsible])].map(deptName).join(', ')}` }); if (r !== null) run(() => api('POST', `${base}/action`, { action: 'remind', reason: r }), 'Reminder sent'); return; }
        if (a === 'reopen') { const r = await ask(`Re-open step ${no}`, 'Reason for re-opening'); if (r !== null) run(() => api('POST', `${base}/action`, { action: 'reopen', reason: r }), 'Step re-opened'); return; }
        if (a === 'iterate') { const r = await ask(`Log loop iteration — step ${no}`, 'Trial code / what was handed off in this iteration', { required: false, okLabel: 'Log iteration' }); if (r !== null) run(() => api('POST', `${base}/action`, { action: 'iterate', reason: r }), 'Iteration logged and partner step notified'); }
      };
    });
    $$('[data-in]', box).forEach((c) => { c.onchange = () => run(() => api('POST', `${base}/inputs/${c.dataset.in}`, { confirmed: c.checked })); });
    $$('[data-out]', box).forEach((c) => { c.onchange = () => run(() => api('POST', `${base}/outputs/${c.dataset.out}`, { state: c.checked ? 'done' : null }), c.checked ? 'Output confirmed' : ''); });
    $$('[data-outna]', box).forEach((b) => { b.onclick = async () => { const r = await ask('Output not applicable', 'Reason'); if (r !== null) run(() => api('POST', `${base}/outputs/${b.dataset.outna}`, { state: 'na', reason: r })); }; });
    $$('[data-outre]', box).forEach((b) => { b.onclick = () => run(() => api('POST', `${base}/outputs/${b.dataset.outre}`, { state: null })); });
    $$('[data-msg]', box).forEach((b) => { b.onclick = () => {
      const ta = $(`#msg${b.dataset.msg}`, box); const text = ta.value.trim(); if (!text) return toast('Write the message first', 'err');
      run(async () => { await api('POST', `${base}/outputs/${b.dataset.msg}/messages`, { text }); ta.value = ''; }, 'Message delivered to the receiving departments');
    }; });
    $$('[data-link]', box).forEach((b) => { b.onclick = async () => { const url = await ask('Add a link', 'Link (SharePoint, Drive or server path)', { multiline: false, okLabel: 'Add link' }); if (url) run(() => api('POST', `${base}/links`, { output: Number(b.dataset.link), url }), 'Link added'); }; });
    $$('[data-upl]', box).forEach((b) => { b.onclick = async () => { const f = await pickFile(); if (f) run(() => uploadFile(f, { product: pid, step: no, output: b.dataset.upl }), 'File uploaded and delivered'); }; });
    $$('[data-docv]', box).forEach((b) => { b.onclick = () => Docs.openType(pid, Number(b.dataset.docv)); });
    $$('[data-docup]', box).forEach((b) => { b.onclick = async () => {
      const f = await pickFile(); if (!f) return;
      const comment = await ask('Version comment (optional)', 'What changed in this version?', { required: false, okLabel: 'Upload' }); if (comment === null) return;
      run(async () => { const r = await uploadFile(f, { product: pid, step: no, doctype: b.dataset.docup, comment }); toast(`Uploaded version ${r.version}`); });
    }; });
    const dueBtn = $('[data-due]', box);
    if (dueBtn) dueBtn.onclick = async () => { const v = $('#dueov', box).value; if (!v) return; const r = await ask('Change deadline', `Reason for setting the deadline of step ${no} to ${fmtDate(v)}`); if (r !== null) run(() => api('POST', `${base}/action`, { action: 'due', date: v, reason: r }), 'Deadline changed'); };
    const dueClr = $('[data-dueclr]', box);
    if (dueClr) dueClr.onclick = () => run(() => api('POST', `${base}/action`, { action: 'due', date: null }), 'Deadline back to SOP timeframe');
    $('[data-note]', box).onclick = () => {
      const t = $('#nt_text', box).value.trim(); if (!t) return toast('Write the note first', 'err');
      const to = $$('[data-ntd]', box).filter((c) => c.checked).map((c) => c.dataset.ntd);
      run(async () => { await api('POST', `${base}/notes`, { text: t, to_depts: to }); $('#nt_text', box).value = ''; }, 'Note posted and delivered');
    };
    $('[data-radd]', box).onclick = () => {
      const t = $('#rk_t', box).value.trim(); if (!t) return toast('Describe the finding', 'err');
      run(async () => { await api('POST', `/api/products/${pid}/risks`, { step_no: no, severity: $('#rk_sev', box).value, title: t, action: $('#rk_a', box).value, owner_dept: $('#rk_own', box).value }); $('#rk_t', box).value = ''; $('#rk_a', box).value = ''; }, 'Risk finding raised');
    };
    $$('[data-rclose]', box).forEach((b) => { b.onclick = async () => { const r = await ask('Close risk finding', 'How was it resolved?', { required: false, okLabel: 'Close finding' }); if (r !== null) run(() => api('PUT', `/api/risks/${b.dataset.rclose}`, { status: 'closed', close_note: r }), 'Risk finding closed'); }; });
    $$('[data-ropen]', box).forEach((b) => { b.onclick = () => run(() => api('PUT', `/api/risks/${b.dataset.ropen}`, { status: 'open' })); });
  },
};
