'use strict';
/* Project flow — documents + phase lanes (sequential → / parallel ‖ / loop ↻) */
const Flow = {
  pid: null, data: null,
};
App.views.flow = {
  async load(params) {
    const products = await api('GET', '/api/products?all=1');
    let pid = Number(params.args[0]) || null;
    if (!pid) { try { pid = Number(localStorage.getItem('sop.pid')) || null; } catch { /* */ } }
    if (!products.find((p) => p.id === pid)) pid = (products.find((p) => p.status === 'active') || products[0] || {}).id || null;
    if (!pid) return `<div class="panel empty">No product projects yet.${App.isExec() ? ' Create one at the bottom of the <a href="#/dashboard">Dashboard</a>.' : ''}</div>`;
    if (Number(params.args[0]) !== pid) { history.replaceState(null, '', `#/flow/${pid}`); App.params.args = [String(pid)]; }
    try { localStorage.setItem('sop.pid', pid); } catch { /* */ }
    Flow.pid = pid;
    const d = await api('GET', `/api/products/${pid}`);
    Flow.data = d;
    const p = d.summary; const byNo = new Map(d.steps.map((s) => [s.no, s]));
    const myDepts = new Set(App.meta.steps.filter((s) => s.depts.includes(App.me.dept)).map((s) => s.no));
    const focus = Number(params.step) || null;

    const card = (no) => {
      const s = byNo.get(no); if (!s) return '';
      const late = s.overdue && s.state !== 'done' && s.state !== 'na';
      const restricted = s.level === 'none';
      return `<button class="card s-${s.state} ${late ? 'late' : ''} ${myDepts.has(no) ? 'mine' : ''} ${focus === no ? 'focus' : ''}" data-open-step="${no}" data-pid="${pid}" aria-label="Step ${no} ${esc(s.name)} — ${STATE[s.state]}">
        <div class="top"><span class="no">${no}</span>${pill(s.state, late ? s.overdueDays : 0)}${s.loop && s.iterations ? `<span class="tag" title="Loop iterations">↻${s.iterations}</span>` : ''}</div>
        <div class="nm" title="${esc(s.name)}">${esc(s.name)}</div>
        <div class="acc" title="${esc(s.accText)}">${esc(s.accText)}</div>
        <div class="meta">${s.state === 'done' ? `<span>Done ${fmtDate(s.completed_at)}</span>${s.onTime === false ? `<span style="color:var(--late)">+${s.lateDays} d</span>` : '<span style="color:var(--done)">on time</span>'}`
          : s.state === 'na' ? `<span title="${esc(s.na_reason)}">Cancelled: ${esc((s.na_reason || '').slice(0, 26))}</span>`
          : s.due ? `<span class="cdues">${s.dues.length > 1 ? `${s.dues.length} due dates` : 'Due'} ${dueLines(s.dues.slice(0, 1), { short: true })}${s.dues.length > 1 ? `<span class="faint" title="${esc(s.dues.map((g) => `Output ${g.outs.join(', ')}: ${fmtDate(g.due)}${g.overdueDays ? ` (${g.overdueDays} d late)` : ''}`).join('\n'))}"> +${s.dues.length - 1}</span>` : ''}</span><span>${s.state === 'ready' ? `${s.waitWD} WD idle` : ''}</span>` : `<span class="faint">≈ ready ${fmtDate(s.fReady)}</span>`}</div>
        ${s.released && s.deferLabels.length ? `<div class="deferflag" title="Next steps may start; this step stays open until the long-running output is delivered">⧗ ${esc(s.deferLabels.join(' · '))}</div>` : ''}
        <div class="ind">${restricted ? '<span class="lock">🔒 no access</span>' : `<span title="Outputs confirmed">out ${s.outputsDone}/${s.outputsTotal}</span><span title="Inputs confirmed">in ${s.inputsDone}/${s.inputsTotal}</span>${s.notes ? `<span title="Notes">✎${s.notes}</span>` : ''}${s.risks ? `<span class="r" title="Open risk findings">⚠${s.risks}</span>` : ''}${s.docsMissing && s.state !== 'waiting' ? `<span class="r" title="Required document(s) not uploaded yet">📄${s.docsMissing}</span>` : ''}`}</div>
      </button>`;
    };
    const group = (g) => {
      if (g.type === 'seq') return `<div class="grp seq">${g.steps.map(card).join('<span class="arrow" aria-hidden="true">→</span>')}</div>`;
      const label = g.type === 'loop' ? '↻ PARALLEL · ITERATIVE LOOP' : '‖ PARALLEL';
      return `<div class="grp ${g.type}" title="${esc(g.label || (g.type === 'par' ? 'These steps run at the same time' : ''))}"><span class="gl">${label}</span>${g.steps.map(card).join('')}${g.label ? `<div class="glnote">${esc(g.label)}</div>` : ''}</div>`;
    };
    const lanes = App.meta.phases.map((ph) => {
      const gs = App.meta.flow.filter((g) => g.phase === ph.no);
      const nums = gs.flatMap((g) => g.steps);
      const done = nums.filter((n) => byNo.get(n) && (byNo.get(n).state === 'done' || byNo.get(n).state === 'na')).length;
      return `<section class="lane" aria-label="Phase ${ph.no}">
        <div class="lh"><span class="pn">${ph.no}</span><span class="pt">${esc(ph.name)}</span><span class="pc">steps ${nums[0]}–${nums[nums.length - 1]}<br>${done}/${nums.length} closed</span></div>
        <div class="lb">${gs.map(group).join('<span class="arrow" aria-hidden="true">→</span>')}</div>
      </section>`;
    }).join('');

    return `
    <div class="flowhead">
      <div>
        <div class="row"><select id="fprod" aria-label="Product">${products.map((x) => `<option value="${x.id}" ${x.id === pid ? 'selected' : ''}>${esc(x.name)}${x.status !== 'active' ? ` (${x.status.replace('_', ' ')})` : ''}</option>`).join('')}</select>
          <span class="tag teal">${p.progress.pct}% · ${p.progress.done}/${p.progress.total} license steps</span>
          ${p.overdue.length ? `<span class="tag red">${p.overdue.length} overdue</span>` : ''}${p.criticalRisks ? `<span class="tag sev-Critical">${p.criticalRisks} critical risk</span>` : ''}</div>
        <h1 style="margin-top:8px">${esc(p.name)}</h1>
        <p class="muted" style="margin:2px 0 0">${esc(p.api || '—')} · ${esc(p.dosage || '—')} · ${esc(p.markets || '—')} · start ${fmtDate(p.start_date)} · expected license <b>${p.license ? fmtDate(p.license.date) : '—'}</b> · 1st 3 commercial batches <b>${p.commercial ? fmtDate(p.commercial.date) : '—'}</b></p>
      </div>
      <div class="row" style="justify-content:flex-end">
        ${App.isExec() ? '<button class="btn" id="fedit">Edit product</button>' : ''}
        <a class="btn" href="/api/export/csv/flow?product=${pid}">Steps CSV</a>
        ${App.isExec() ? `<a class="btn" href="/api/export/product/${pid}">Export product (ZIP)</a>` : ''}
      </div>
    </div>

    <section class="section" style="margin-top:18px" id="pdocs">
      <header><h2>Product documents</h2><p>All SOP-controlled documents of this product in SOP step order (step 1 first) — green when uploaded, grey until uploaded. Search, filter, or click a column title to sort.</p>
        <span class="spacer"></span>${App.isExec() ? '<button class="btn sm" id="fall">Search all products</button>' : ''}</header>
      <div id="pd_box">${Flow.docHtml && Flow.docPid === pid ? Flow.docHtml : '<div class="panel empty">Loading documents…</div>'}</div>
    </section>

    <section class="section">
      <header><h2>Workflow</h2>
        <div class="legend"><span><span class="sym">→</span> sequential</span><span><span class="sym">‖</span> parallel (same time)</span><span><span class="sym" style="color:#8a6200">↻</span> iterative loop</span>
          ${['waiting', 'ready', 'in_progress', 'done', 'na'].map((s) => `<span class="pill st-${s}">${STATE[s]}</span>`).join('')}<span class="pill st-overdue">Overdue</span><span class="tag" style="background:var(--teal);color:#fff;border-color:var(--teal)">my dept</span></div></header>
      ${lanes}
    </section>
    ${(App.meta.generalNotes || []).length ? `<section class="section"><header><h2>SOP general recommendations</h2><p>Apply to every product.</p></header>
      <div class="panel pad">${items(App.meta.generalNotes)}</div></section>` : ''}`;
  },
  bind(el) {
    const sel = $('#fprod', el); if (!sel) return;
    sel.onchange = () => { location.hash = `#/flow/${sel.value}`; };
    if ($('#fall', el)) $('#fall', el).onclick = () => Docs.archive(null);
    Flow.loadDocs(el);
    if ($('#fedit', el)) $('#fedit', el).onclick = () => Flow.editProduct();
  },
};

Flow.editProduct = function () {
  const p = Flow.data.summary;
  modal({
    title: 'Edit product project', width: 620,
    body: `<div class="formgrid">
      <label class="field full"><span>Product name</span><input type="text" id="ep_n" value="${esc(p.name)}"></label>
      <label class="field"><span>API / salt</span><input type="text" id="ep_a" value="${esc(p.api)}"></label>
      <label class="field"><span>Dosage form & strengths</span><input type="text" id="ep_d" value="${esc(p.dosage)}"></label>
      <label class="field"><span>Target markets</span><input type="text" id="ep_m" value="${esc(p.markets)}"></label>
      <label class="field"><span>Start date (step 1)</span><input type="date" id="ep_s" value="${p.start_date}"></label>
      <label class="field"><span>Status</span><select id="ep_st">${[['active', 'Active'], ['on_hold', 'On hold'], ['archived', 'Archived']].map(([k, l]) => `<option value="${k}" ${p.status === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
    </div>`,
    actions: [
      ...(App.isAdmin() ? [{ label: 'Delete product', danger: true, onClick: async () => {
        const r = await ask('Delete product permanently', `Type the product name to confirm deletion of all its steps, notes and documents:`, { multiline: false, okLabel: 'Delete' });
        if (r === null) return false;
        if (r !== p.name) { toast('Name does not match — nothing deleted', 'err'); return false; }
        await api('DELETE', `/api/products/${p.id}`); toast('Product deleted'); location.hash = '#/dashboard';
      } }] : []),
      { label: 'Cancel' },
      { label: 'Save', primary: true, onClick: async (w) => {
        await api('PUT', `/api/products/${p.id}`, { name: $('#ep_n', w).value, api: $('#ep_a', w).value, dosage: $('#ep_d', w).value, markets: $('#ep_m', w).value, start_date: $('#ep_s', w).value, status: $('#ep_st', w).value });
        toast('Product saved');
      } },
    ],
  });
};

/* ---------- product documents: step-ordered, searchable, sortable, paged (all done by the server) ---------- */
Flow.docState = { q: '', status: '', section: '', latest: true, sort: 'step', dir: 'asc' };
Flow.loadDocs = async function (el) {
  const box = $('#pd_box', el); if (!box) return;
  const pid = Flow.pid; const st = Flow.docState;
  const qs = new URLSearchParams({ sort: st.sort, dir: st.dir, latest: st.latest ? '1' : '0' });
  if (st.q) qs.set('q', st.q); if (st.status) qs.set('status', st.status); if (st.section) qs.set('section', st.section);
  let r;
  try { r = await api('GET', `/api/products/${pid}/sopdocs?${qs}`); } catch (e) { box.innerHTML = `<div class="panel empty">${esc(e.message)}</div>`; return; }
  if (Flow.pid !== pid || !document.body.contains(box)) return;
  const c = r.counts;
  const html = `
    <div class="toolbar">
      <input type="search" id="pd_q" placeholder="Search document, file, user, step no., version (v2)…" value="${esc(st.q)}" style="width:300px">
      <select id="pd_status" aria-label="Status"><option value="">All SOP-controlled documents (${c.types})</option><option value="uploaded" ${st.status === 'uploaded' ? 'selected' : ''}>Uploaded (${c.uploaded})</option><option value="missing" ${st.status === 'missing' ? 'selected' : ''}>Not uploaded yet (${c.missing})</option></select>
      <select id="pd_section" aria-label="Section"><option value="">All sections</option>${r.sections.map((x) => `<option ${st.section === x ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
      <label class="check"><input type="checkbox" id="pd_latest" ${st.latest ? 'checked' : ''}> Latest version only</label>
      <span class="small muted"><span class="tag green">${c.uploaded} uploaded</span> <span class="tag grey">${c.missing} not uploaded yet</span></span>
    </div>
    ${Docs.sopTable(r.rows, st, pid)}`;
  Flow.docHtml = html; Flow.docPid = pid;
  preserve(box, () => { box.innerHTML = html; });
  const reload = () => Flow.loadDocs(el);
  let t; $('#pd_q', box).oninput = (e) => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value.trim(); reload(); }, 300); };
  $('#pd_status', box).onchange = (e) => { st.status = e.target.value; reload(); };
  $('#pd_section', box).onchange = (e) => { st.section = e.target.value; reload(); };
  $('#pd_latest', box).onchange = (e) => { st.latest = e.target.checked; reload(); };
  Docs.bindTable(box, st, reload);
  Docs.bindDeletes(box, reload);
  $$('[data-dtv]', box).forEach((b) => { b.onclick = () => Docs.openType(pid, Number(b.dataset.dtv)); });
  $$('[data-dtup]', box).forEach((b) => { b.onclick = async () => {
    const [typeId, step] = b.dataset.dtup.split(':').map(Number);
    const f = await pickFile(); if (!f) return;
    const comment = await ask('Version comment (optional)', 'What is this version?', { required: false, okLabel: 'Upload' });
    if (comment === null) return;
    try { const u = await uploadFile(f, { product: pid, step, doctype: typeId, comment }); toast(`<b>Uploaded v${u.version}</b>`); reload(); } catch (e) { fail(e); }
  }; });
};

const Docs = {
  cols: [['step', 'Step'], ['name', 'Document'], ['version', 'Ver.', 'num'], ['dept', 'Department'], ['user', 'Uploaded by'], ['date', 'Uploaded']],
  table(rows, { sort = 'step', dir = 'asc', group = false, showProduct = false, pid = null } = {}) {
    if (!rows.length) return '<div class="panel empty">No documents match. Documents appear here as soon as a department uploads them inside a step.</div>';
    const head = `<tr>${showProduct ? `<th data-k="product">Product${sort === 'product' ? (dir === 'asc' ? ' ▲' : ' ▼') : ''}</th>` : ''}${Docs.cols.map(([k, l, cls]) => `<th data-k="${k}" class="${cls || ''}" title="Sort by ${l.toLowerCase()}">${l}${sort === k ? (dir === 'asc' ? ' ▲' : ' ▼') : ''}</th>`).join('')}<th></th></tr>`;
    let last = null;
    const body = rows.map((f) => {
      const ppid = f.product_id || pid;
      const grp = group && f.step_no !== last ? `<tr class="grprow"><td colspan="${showProduct ? 8 : 7}"><span class="steplink" data-open-step="${f.step_no}" data-pid="${ppid}">Step ${f.step_no}</span> · ${esc(App.stepName(f.step_no))}</td></tr>` : '';
      last = f.step_no;
      const name = f.doc_type_id ? `<div>${esc(f.doc_name)}</div><div class="small"><span class="tag teal">SOP-controlled</span> <span class="muted">${esc(f.section || '')}</span></div>`
        : f.kind === 'link' ? `<div>Link</div><div class="small muted">${esc(f.url || '')}</div>` : `<div>${esc(f.filename)}</div><div class="small muted">Output ${f.output_idx || '—'} upload</div>`;
      const file = f.restricted ? '<span class="small muted">no access</span>' : f.kind === 'link' ? `<a class="btn sm" href="${esc(f.url)}" target="_blank" rel="noopener">Open link</a>`
        : `<a class="btn sm" href="/api/files/${f.id}" target="_blank" rel="noopener" title="${esc(f.filename)}">Open</a> <a class="btn sm" href="/api/files/${f.id}?download=1">Download</a>`;
      return `${grp}<tr>
        ${showProduct ? `<td>${esc(f.product)}</td>` : ''}
        <td class="stepcell"><span class="steplink" data-open-step="${f.step_no}" data-pid="${ppid}">Step ${f.step_no}</span>${f.output_idx ? `<div class="small muted">output ${f.output_idx}</div>` : ''}</td>
        <td>${name}${f.doc_type_id && !f.restricted ? `<div class="small muted">${esc(f.filename)} · ${fmtSize(f.size)}</div>` : ''}${f.comment ? `<div class="small muted">“${esc(f.comment)}”</div>` : ''}</td>
        <td class="num"><b>v${f.version}</b>${f.latest ? '' : '<div class="small faint">older</div>'}</td>
        <td>${esc(deptShort(f.dept))}</td><td>${esc(f.full_name || f.username)}</td><td class="nowrap mono small">${esc(fmtDT(f.uploaded_at))}</td>
        <td class="nowrap">${file}${App.isAdmin() && !f.restricted ? ` <button class="btn sm danger" data-del="${f.id}" title="Administrator only">Delete</button>` : ''}</td>
      </tr>`;
    }).join('');
    return `<div class="tablewrap doctable"><table class="grid"><thead>${head}</thead><tbody>${body}</tbody></table></div>`;
  },
  // every SOP-controlled document of a product, uploaded (green) or not yet uploaded (greyed out), in SOP step order
  sopTable(rows, st, pid) {
    if (!rows.length) return '<div class="panel empty">No SOP-controlled document matches.</div>';
    const sort = st.sort; const dir = st.dir;
    const cols = [['step', 'Step'], ['name', 'Document'], ['version', 'Ver.'], ['dept', 'Department'], ['user', 'Uploaded by'], ['date', 'Uploaded']];
    const head = `<tr>${cols.map(([k, l]) => `<th data-k="${k}" title="Sort by ${l.toLowerCase()}">${l}${sort === k ? (dir === 'asc' ? ' ▲' : ' ▼') : ''}</th>`).join('')}<th></th></tr>`;
    let last = null;
    const body = rows.map((f) => {
      const grp = sort === 'step' && f.step_no !== last ? `<tr class="grprow"><td colspan="7"><span class="steplink" data-open-step="${f.step_no}" data-pid="${pid}">Step ${f.step_no}</span> · ${esc(App.stepName(f.step_no))}</td></tr>` : '';
      last = f.step_no;
      const s = App.step(f.req_step); const canUp = s && s.level === 'edit';
      const label = f.uploaded ? '<span class="tag green">SOP-controlled · uploaded</span>' : '<span class="tag grey">SOP-controlled · not uploaded yet</span>';
      const actions = f.uploaded
        ? (f.restricted ? '<span class="small muted">no access</span>' : `<a class="btn sm" href="/api/files/${f.id}" target="_blank" rel="noopener" title="${esc(f.filename)}">Open</a> <a class="btn sm" href="/api/files/${f.id}?download=1">Download</a> <button class="btn sm" data-dtv="${f.doc_type_id}" title="All versions">Versions (${f.versions})</button>${App.isAdmin() ? ` <button class="btn sm danger" data-del="${f.id}" title="Administrator only">Delete</button>` : ''}`)
        : `${canUp ? `<button class="btn sm primary" data-dtup="${f.doc_type_id}:${f.req_step}">Upload</button> ` : ''}<button class="btn sm" data-open-step="${f.req_step}" data-pid="${pid}">Open step ${f.req_step}</button>`;
      return `${grp}<tr class="${f.uploaded ? '' : 'missing'}">
        <td class="stepcell"><span class="steplink" data-open-step="${f.step_no}" data-pid="${pid}">Step ${f.step_no}</span>${f.output_idx ? `<div class="small muted">output ${f.output_idx}</div>` : ''}</td>
        <td><div>${esc(f.doc_name)}</div><div class="small">${label} <span class="muted">${esc(f.section)}</span></div>${f.uploaded && !f.restricted ? `<div class="small muted">${esc(f.filename)} · ${fmtSize(f.size)}${f.comment ? ` · “${esc(f.comment)}”` : ''}</div>` : ''}</td>
        <td class="num">${f.uploaded ? `<b>v${f.version}</b>${f.latest ? '' : '<div class="small faint">older</div>'}` : '<span class="faint">—</span>'}</td>
        <td>${f.uploaded ? esc(deptShort(f.dept)) : '<span class="faint">—</span>'}</td><td>${f.uploaded ? esc(f.full_name || f.username) : '<span class="faint">—</span>'}</td>
        <td class="nowrap mono small">${f.uploaded ? esc(fmtDT(f.uploaded_at)) : '<span class="faint">—</span>'}</td>
        <td class="nowrap">${actions}</td></tr>`;
    }).join('');
    return `<div class="tablewrap doctable sopdocs"><table class="grid"><thead>${head}</thead><tbody>${body}</tbody></table></div>`;
  },
  pager(r) {
    if (r.total <= 10) return `<div class="pager small muted">${r.total} document${r.total === 1 ? '' : 's'}</div>`;
    const a = (r.page - 1) * r.size + 1; const b = Math.min(r.total, r.page * r.size);
    return `<div class="pager"><span class="small muted">Showing ${a}–${b} of ${r.total}</span><span class="spacer"></span>
      <label class="check small">Per page <select data-psize>${[25, 50, 100, 200].map((n) => `<option ${n === r.size ? 'selected' : ''}>${n}</option>`).join('')}</select></label>
      <button class="btn sm" data-page="${r.page - 1}" ${r.page <= 1 ? 'disabled' : ''}>‹ Previous</button><span class="small">Page ${r.page} / ${r.pages}</span><button class="btn sm" data-page="${r.page + 1}" ${r.page >= r.pages ? 'disabled' : ''}>Next ›</button></div>`;
  },
  bindTable(box, st, reload) {
    $$('th[data-k]', box).forEach((th) => { th.onclick = () => { if (st.sort === th.dataset.k) st.dir = st.dir === 'asc' ? 'desc' : 'asc'; else { st.sort = th.dataset.k; st.dir = th.dataset.k === 'date' ? 'desc' : 'asc'; } st.page = 1; reload(); }; });
    $$('[data-page]', box).forEach((b) => { b.onclick = () => { st.page = Number(b.dataset.page); reload(); }; });
    const ps = $('[data-psize]', box); if (ps) ps.onchange = () => { st.size = Number(ps.value); st.page = 1; reload(); };
  },
  bindDeletes(w, after) {
    $$('[data-del]', w).forEach((b) => { b.onclick = async () => {
      const r = await ask('Delete uploaded document', 'Reason for deletion (recorded in the step history):', { okLabel: 'Delete' });
      if (r === null) return;
      try { await api('DELETE', `/api/files/${b.dataset.del}`); toast('Document deleted'); after(); } catch (e) { fail(e); }
    }; });
  },
  // every version of one SOP-controlled document
  async openType(pid, typeId) {
    const t = App.meta.docTypes.find((x) => x.id === typeId);
    const r = await api('GET', `/api/documents?product=${pid}&doctype=${typeId}&sort=version&dir=desc&size=200`);
    const editable = t.steps.filter((n) => { const s = App.step(n); return s && s.level === 'edit'; });
    const m = modal({
      title: t.name, width: 980,
      body: `<div class="row"><span class="tag teal">${esc(t.section)}</span><span class="muted small">Uploaded at step ${t.steps.join(' / ')}${t.required_step ? ` · required to complete step ${t.required_step}${t.required_output ? `, output ${t.required_output}` : ''}` : ''}. Versions are permanent — a new upload becomes the next version.</span></div>
        <div id="dt_tbl">${Docs.table(r.rows, { sort: 'version', dir: 'desc', pid })}</div>`,
      actions: [{ label: 'Close' }, ...(editable.length ? [{ label: 'Upload new version', primary: true, onClick: async () => {
        let step = editable.includes(t.required_step) ? t.required_step : editable[0];
        if (editable.length > 1) { const a = await ask('Upload at which step?', `Step number (${editable.join(' or ')})`, { multiline: false, value: String(step), okLabel: 'Choose file' }); if (a === null) return false; step = Number(a); if (!editable.includes(step)) { toast('Choose one of the listed steps', 'err'); return false; } }
        const f = await pickFile(); if (!f) return false;
        const comment = await ask('Version comment (optional)', 'What changed in this version?', { required: false, okLabel: 'Upload' });
        if (comment === null) return false;
        const u = await uploadFile(f, { product: pid, step, doctype: typeId, comment });
        toast(`<b>Uploaded v${u.version}</b>${esc(t.name)}`);
        m.close(); Docs.openType(pid, typeId);
        return false;
      } }] : [])],
    });
    Docs.bindDeletes(m.el, () => { m.close(); Docs.openType(pid, typeId); });
  },
  // all products (executives)
  async archive(pid) {
    const st = { q: '', kind: 'controlled', dept: '', latest: false, sort: 'date', dir: 'desc', page: 1, size: 50 };
    const m = modal({
      title: pid ? 'Documents of this product' : 'Documents — all products', width: 1220,
      body: `<div class="toolbar" style="margin:0">
        <input type="search" id="ar_q" placeholder="Search product, document, file, user, step no., version…" style="width:320px">
        <select id="ar_d"><option value="">All departments</option>${App.meta.departments.map((d) => `<option value="${d.code}">${esc(d.name)}</option>`).join('')}</select>
        <select id="ar_k"><option value="">All uploads</option><option value="controlled" selected>SOP-controlled documents</option><option value="evidence">Output uploads</option><option value="link">Links</option></select>
        <label class="check"><input type="checkbox" id="ar_l"> Latest version only</label></div><div id="ar_t"><div class="empty">Loading…</div></div>`,
      actions: [{ label: 'Close' }],
    });
    const draw = async () => {
      const qs = new URLSearchParams({ sort: st.sort, dir: st.dir, page: String(st.page), size: String(st.size), latest: st.latest ? '1' : '0' });
      if (pid) qs.set('product', pid); if (st.q) qs.set('q', st.q); if (st.kind) qs.set('kind', st.kind); if (st.dept) qs.set('dept', st.dept);
      const r = await api('GET', `/api/documents?${qs}`);
      const box = $('#ar_t', m.el); if (!box) return;
      box.innerHTML = Docs.table(r.rows, { sort: st.sort, dir: st.dir, showProduct: !pid, group: false }) + Docs.pager(r);
      Docs.bindTable(box, st, draw);
      Docs.bindDeletes(box, draw);
    };
    let t; $('#ar_q', m.el).oninput = (e) => { clearTimeout(t); t = setTimeout(() => { st.q = e.target.value.trim(); st.page = 1; draw(); }, 300); };
    $('#ar_d', m.el).onchange = (e) => { st.dept = e.target.value; st.page = 1; draw(); };
    $('#ar_k', m.el).onchange = (e) => { st.kind = e.target.value; st.page = 1; draw(); };
    $('#ar_l', m.el).onchange = (e) => { st.latest = e.target.checked; st.page = 1; draw(); };
    draw();
  },
};
