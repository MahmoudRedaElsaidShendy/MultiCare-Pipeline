'use strict';
/* Dashboard — portfolio overview, department analytics, new product */
App.views.dashboard = {
  month: null, q: '', sort: 'next', showArchived: false,
  async load() {
    if (!this.month) this.month = todayStr().slice(0, 7);
    const [products, an] = await Promise.all([api('GET', `/api/products${this.showArchived ? '?all=1' : ''}`), api('GET', `/api/analytics?month=${this.month}`)]);
    this.products = products; this.an = an;
    const active = products.filter((p) => p.status !== 'archived');
    const withReady = active.filter((p) => p.ready.length).length;
    const withOver = active.filter((p) => p.overdue.length).length;
    const withRisk = active.filter((p) => p.risks.length).length;
    const nextLic = active.filter((p) => p.license && !p.license.actual).sort((a, b) => (a.license.date < b.license.date ? -1 : 1))[0];
    const nextCom = active.filter((p) => p.commercial && !p.commercial.actual).sort((a, b) => (a.commercial.date < b.commercial.date ? -1 : 1))[0];
    const q = this.q.toLowerCase();
    let list = products.filter((p) => !q || `${p.name} ${p.api} ${p.dosage} ${p.markets}`.toLowerCase().includes(q));
    const sorters = {
      next: (a, b) => ((a.next && a.next.due) || '9999') < ((b.next && b.next.due) || '9999') ? -1 : 1,
      progress: (a, b) => b.progress.pct - a.progress.pct,
      overdue: (a, b) => b.overdue.length - a.overdue.length,
      license: (a, b) => ((a.license && a.license.date) || '9999') < ((b.license && b.license.date) || '9999') ? -1 : 1,
      name: (a, b) => a.name.localeCompare(b.name),
    };
    list = list.sort(sorters[this.sort]);
    return `
    <div class="pagehead"><div><h1>Dashboard</h1><p>All new-product projects at a glance. Dates are forecasts from the SOP timeframes unless marked actual.</p></div>
      <span class="spacer"></span><a class="btn" href="/api/export/csv/dashboard">Export CSV</a></div>
    <div class="kpis">
      <div class="kpi"><div class="v">${active.length}</div><div class="l">Products tracked</div><div class="s">${products.length - active.length ? `${products.length - active.length} archived` : 'active projects'}</div></div>
      <div class="kpi warn"><div class="v">${withReady}</div><div class="l">With ready-to-start steps</div><div class="s">${active.reduce((a, p) => a + p.ready.length, 0)} steps not started yet</div></div>
      <div class="kpi ${withOver ? 'alert' : ''}"><div class="v">${withOver}</div><div class="l">With overdue steps</div><div class="s">${active.reduce((a, p) => a + p.overdue.length, 0)} overdue steps in total</div></div>
      <div class="kpi ${withRisk ? 'alert' : ''}"><div class="v">${withRisk}</div><div class="l">With risk findings</div><div class="s">${active.reduce((a, p) => a + p.criticalRisks, 0)} critical open</div></div>
      <div class="kpi"><div class="v date">${nextLic ? fmtDate(nextLic.license.date) : '—'}</div><div class="l">Next expected license (step ${App.meta.license_step})</div><div class="s" title="${esc(nextLic ? nextLic.name : '')}">${nextLic ? esc(nextLic.name) : 'No product pending'}</div></div>
      <div class="kpi"><div class="v date">${nextCom ? fmtDate(nextCom.commercial.date) : '—'}</div><div class="l">Next 1st 3 commercial batches (step ${App.meta.commercial_step})</div><div class="s" title="${esc(nextCom ? nextCom.name : '')}">${nextCom ? esc(nextCom.name) : 'No product pending'}</div></div>
    </div>

    <section class="section">
      <header><h2>Products</h2><p>Progress = completed license steps ÷ (${App.meta.license_step} − cancelled steps)</p></header>
      <div class="toolbar">
        <input type="search" id="dq" placeholder="Search product, API, market…" value="${esc(this.q)}" style="width:280px">
        <label class="check">Sort by <select id="dsort">${[['next', 'Next deadline'], ['overdue', 'Most overdue'], ['progress', 'Progress'], ['license', 'Expected license'], ['name', 'Name']].map(([k, l]) => `<option value="${k}" ${this.sort === k ? 'selected' : ''}>${l}</option>`).join('')}</select></label>
        <label class="check"><input type="checkbox" id="darch" ${this.showArchived ? 'checked' : ''}> Show archived</label>
      </div>
      ${list.length ? list.map((p) => this.prodCard(p)).join('') : `<div class="panel empty">${products.length ? 'No product matches the search.' : 'No products yet. Create the first product project in the form at the bottom of this page.'}</div>`}
    </section>

    <section class="section">
      <header><h2>Department analytics</h2><p>Monthly KPIs per accountable department. Positive / negative points and the final conclusion are entered by Business Development or the Plant Manager.</p>
        <span class="spacer"></span>
        <label class="check">Month <input type="month" id="dmonth" value="${this.month}"></label>
        <a class="btn sm" href="/api/export/csv/analytics?month=${this.month}">Export CSV</a></header>
      ${this.analytics(an)}
    </section>

    <section class="section">
      <header><h2>New product project</h2><p>Creates the full ${App.meta.steps.length}-step SOP pipeline. Step 1 becomes ready on the start date.</p></header>
      ${App.isExec() ? `<form class="panel pad createform" id="newp">
        <label class="field"><span>Product name</span><input type="text" id="np_name" placeholder="e.g. Cinacalcet 30 mg film coated tablets" required></label>
        <label class="field"><span>API / salt</span><input type="text" id="np_api" placeholder="e.g. Cinacalcet HCl"></label>
        <label class="field"><span>Dosage form & strengths</span><input type="text" id="np_dos" placeholder="e.g. 30 mg film coated tablets"></label>
        <label class="field"><span>Target markets</span><input type="text" id="np_mk" placeholder="e.g. Egypt, GCC"></label>
        <label class="field"><span>Start date (step 1)</span><input type="date" id="np_start" value="${todayStr()}" required></label>
        <button class="btn primary" type="submit">Create product</button>
      </form>` : '<div class="panel empty">Only Business Development, the Plant Manager (executive role) or the administrator can create product projects.</div>'}
    </section>`;
  },

  prodCard(p) {
    const s = (x) => `<li><span class="n">${x.no}</span><span><span class="steplink" data-open-step="${x.no}" data-pid="${p.id}">${esc(x.name)}</span>${x.extra || ''}</span></li>`;
    const pctDone = (p.progress.done / p.progress.total) * 100; const pctNa = (p.progress.na / p.progress.total) * 100;
    return `<article class="prod">
      <div class="id">
        <h3 data-goto="${p.id}">${esc(p.name)}</h3>
        <div class="row" style="margin-top:4px"><span class="tag teal">Phase ${p.phase ? p.phase.no : ''}${p.phase && p.phase.no <= 7 ? ` · ${esc(p.phase.name)}` : ' · all steps closed'}</span>${p.status !== 'active' ? `<span class="tag">${esc(p.status.replace('_', ' '))}</span>` : ''}</div>
        <dl><dt>API / salt</dt><dd>${esc(p.api || '—')}</dd><dt>Dosage form</dt><dd>${esc(p.dosage || '—')}</dd><dt>Markets</dt><dd>${esc(p.markets || '—')}</dd><dt>Start</dt><dd>${fmtDate(p.start_date)}</dd></dl>
        <div class="progress" title="${p.progress.done} done, ${p.progress.na} cancelled of ${p.progress.total}">
          <div class="nums"><span><b>${p.progress.pct}%</b></span><span>${p.progress.done}/${p.progress.total} steps</span></div>
          <div class="bar"><i style="width:${pctDone}%"></i><i class="na" style="width:${pctNa}%"></i></div>
        </div>
      </div>
      <div class="facts">
        <div class="fact"><h4>Last completed step</h4>${p.lastDone ? `<ul>${s({ ...p.lastDone, extra: `<div class="small muted">${fmtDT(p.lastDone.at)}</div>` })}</ul>` : '<span class="muted">None yet</span>'}</div>
        <div class="fact"><h4>Steps in process (${p.inProc.length})</h4>${p.inProc.length ? `<ul>${p.inProc.map((x) => s({ ...x, extra: `<div class="duelist small">${dueLines(x.dues)}</div>${x.released && x.deferLabels.length ? `<div class="deferflag">⧗ ${esc(x.deferLabels.join(' · '))}</div>` : ''}` })).join('')}</ul>` : '<span class="muted">None</span>'}</div>
        <div class="fact ${p.overdue.length ? 'alert' : ''}"><h4>Overdue steps (${p.overdue.length})</h4>${p.overdue.length ? `<ul>${p.overdue.map((x) => s({ ...x, extra: `<div class="small">${(x.outs && x.outs.length ? x.outs : [{ idx: '', due: x.due, days: x.overdueDays }]).map((o) => `<span class="tag red" title="Output ${o.idx} due ${fmtDate(o.due)}">${o.idx ? `O${o.idx} · ` : ''}${o.days} d late</span>`).join(' ')} ${esc(x.acc)}</div>` })).join('')}</ul>` : '<span class="muted">None</span>'}</div>
        <div class="fact"><h4>Next deadline</h4>${p.next ? `<div class="date">${fmtDate(p.next.due)}</div><ul>${s({ ...p.next, extra: `<div class="small muted">${esc(p.next.acc)}</div>` })}</ul>` : '<span class="muted">—</span>'}</div>
        <div class="fact"><h4>Ready to start, not started (${p.ready.length})</h4>${p.ready.length ? `<ul>${p.ready.map((x) => s({ ...x, extra: `<div class="small muted">ready since ${fmtDate(x.readyDate)} · ${x.waitWD} WD waiting</div>` })).join('')}</ul>` : '<span class="muted">None</span>'}</div>
        <div class="fact ${p.criticalRisks ? 'alert' : ''}"><h4>Critical risk findings (${p.criticalRisks})</h4>${p.risks.length ? `<ul>${p.risks.slice(0, 5).map((r) => `<li><span class="tag sev-${r.severity}">${r.severity}</span><span>${r.step_no ? `<span class="steplink" data-open-step="${r.step_no}" data-pid="${p.id}">Step ${r.step_no}</span>: ` : ''}${esc(r.title)}${r.action ? `<div class="small muted">Action: ${esc(r.action)}${r.owner_dept ? ` · ${esc(deptShort(r.owner_dept))}` : ''}</div>` : ''}</span></li>`).join('')}</ul>${p.risks.length > 5 ? `<div class="small muted">+${p.risks.length - 5} more</div>` : ''}` : '<span class="muted">No open findings</span>'}</div>
        <div class="fact"><h4>Cancelled steps (${p.cancelled.length})</h4>${p.cancelled.length ? `<ul>${p.cancelled.map((x) => s({ ...x, extra: `<div class="small muted">Reason: ${esc(x.reason)}</div>` })).join('')}</ul>` : '<span class="muted">None</span>'}</div>
        <div class="fact"><h4>Expected dates</h4>
          <div class="small muted">License (step ${App.meta.license_step})</div><div class="date">${p.license ? fmtDate(p.license.date) : '—'} ${p.license && p.license.actual ? '<span class="tag teal">actual</span>' : ''}</div>
          <div class="small muted" style="margin-top:4px">1st 3 commercial batches (step ${App.meta.commercial_step})</div><div class="date">${p.commercial ? fmtDate(p.commercial.date) : '—'} ${p.commercial && p.commercial.actual ? '<span class="tag teal">actual</span>' : ''}</div></div>
      </div>
    </article>`;
  },

  analytics(an) {
    const canEdit = App.isExec();
    const max = Math.max(1, ...an.depts.flatMap((d) => d.trend.map((t) => t.completed + t.overdue)));
    return `<div class="tablewrap"><table class="grid">
      <thead><tr><th>Department</th><th class="num">Products with steps completed on time</th><th class="num">Steps completed within timeframe</th><th class="num">Steps overdue</th><th class="num">Ready → started, avg WD</th><th>Positive points</th><th>Negative points</th><th>Final conclusion</th><th>Last 6 months</th>${canEdit ? '<th></th>' : ''}</tr></thead>
      <tbody>${an.depts.map((d) => `<tr>
        <td class="dcell"><b>${esc(d.name)}</b><div class="small muted">${d.outDone ? `${d.outOnTime}/${d.outDone} outputs delivered on time` : ''}</div></td>
        <td class="num">${d.productsOnTime}</td>
        <td class="num">${d.onTime} / ${d.completed}${d.rate != null ? `<div class="small ${d.rate >= 75 ? '' : 'muted'}">${d.rate}%</div>` : ''}</td>
        <td class="num" title="${esc(d.overdueList.join('\n'))}">${d.overdue ? `<span class="tag red">${d.overdue}</span>` : '0'}</td>
        <td class="num" title="${esc(d.notStartedList.join('\n'))}">${d.avgWait ?? '—'}${d.notStarted ? `<div class="small" style="color:var(--ready)">${d.notStarted} still not started</div>` : ''}</td>
        <td><div class="evaltext pos">${esc(d.positives) || '<span class="faint">—</span>'}</div></td>
        <td><div class="evaltext neg">${esc(d.negatives) || '<span class="faint">—</span>'}</div></td>
        <td><div class="evaltext">${esc(d.conclusion) || `<span class="muted">${esc(d.auto)}</span>`}</div>${d.updated_by ? `<div class="small faint">by ${esc(d.updated_by)}</div>` : ''}</td>
        <td><div class="spark" title="Completed (blue) and overdue (red) steps per month">${d.trend.map((t) => (t.completed || t.overdue) ? `<i style="height:${Math.max(3, (t.completed / max) * 26)}px" title="${fmtMonth(t.month)}: ${t.onTime}/${t.completed} on time"></i><i class="bad" style="height:${t.overdue ? Math.max(3, (t.overdue / max) * 26) : 0}px" title="${fmtMonth(t.month)}: ${t.overdue} overdue"></i>` : `<i class="none" title="${fmtMonth(t.month)}: no activity"></i>`).join('')}</div></td>
        ${canEdit ? `<td><button class="btn sm" data-eval="${d.code}">Evaluate</button></td>` : ''}
      </tr>`).join('')}</tbody></table></div>`;
  },

  bind(el) {
    const v = this;
    let t; $('#dq', el).oninput = (e) => { clearTimeout(t); t = setTimeout(() => { v.q = e.target.value; Main.render(true); }, 250); };
    $('#dsort', el).onchange = (e) => { v.sort = e.target.value; Main.render(true); };
    $('#darch', el).onchange = (e) => { v.showArchived = e.target.checked; Main.render(true); };
    $('#dmonth', el).onchange = (e) => { if (e.target.value) { v.month = e.target.value; Main.render(true); } };
    $$('[data-goto]', el).forEach((h) => { h.onclick = () => { location.hash = `#/flow/${h.dataset.goto}`; }; });
    $$('[data-eval]', el).forEach((b) => { b.onclick = () => v.evaluate(b.dataset.eval); });
    const f = $('#newp', el);
    if (f) f.onsubmit = async (e) => {
      e.preventDefault();
      try {
        const p = await api('POST', '/api/products', { name: $('#np_name').value, api: $('#np_api').value, dosage: $('#np_dos').value, markets: $('#np_mk').value, start_date: $('#np_start').value });
        ['np_name', 'np_api', 'np_dos', 'np_mk'].forEach((id) => { $(`#${id}`).value = ''; });
        toast(`<b>Product created</b>${esc(p.name)} — step 1 is ready to start.`);
        location.hash = `#/flow/${p.id}`;
      } catch (err) { fail(err); }
    };
  },

  evaluate(code) {
    const d = this.an.depts.find((x) => x.code === code);
    modal({
      title: `${d.name} — ${fmtMonth(this.month)}`, width: 640,
      body: `<div class="banner info" style="margin:0">Auto assessment: ${esc(d.auto)} (${d.onTime}/${d.completed} steps on time, ${d.overdue} overdue, average ready→start ${d.avgWait ?? '—'} WD)</div>
        <label class="field"><span>Positive points</span><textarea id="ev_p" rows="3">${esc(d.positives)}</textarea></label>
        <label class="field"><span>Negative points</span><textarea id="ev_n" rows="3">${esc(d.negatives)}</textarea></label>
        <label class="field"><span>Final conclusion</span><textarea id="ev_c" rows="3">${esc(d.conclusion)}</textarea></label>`,
      actions: [{ label: 'Cancel' }, { label: 'Save evaluation', primary: true, onClick: async (w) => {
        await api('POST', '/api/evaluations', { dept: code, month: this.month, positives: $('#ev_p', w).value, negatives: $('#ev_n', w).value, conclusion: $('#ev_c', w).value });
        toast('Evaluation saved'); Main.render(true);
      } }],
    });
  },
};
