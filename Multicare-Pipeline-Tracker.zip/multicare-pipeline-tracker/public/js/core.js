'use strict';
/* Core helpers shared by all views */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// long official links are shown as a short source name
const linkify = (s) => esc(s).replace(/(https?:\/\/[^\s<]+)/g, (u) => { let h = u; try { h = new URL(u.replace(/&amp;/g, '&')).hostname.replace(/^www\./, ''); } catch { /* */ } return `<a href="${u}" target="_blank" rel="noopener" title="${u}">${h} ↗</a>`; });

const App = {
  me: null, meta: null, view: null, params: {}, live: false, online: [],
  views: {},
  stepName(no) { const s = App.meta && App.meta.steps.find((x) => x.no === no); return s ? s.name : ''; },
  step(no) { return App.meta.steps.find((x) => x.no === no); },
  canAnnounce() { return !!(App.meta && App.meta.canAnnounce); },
  isAdmin() { return App.me && App.me.role === 'admin'; },
  isExec() { return App.me && (App.me.role === 'admin' || App.me.role === 'executive'); },
  canDash() { return !!(App.meta && App.meta.canDash); },
};

// every request has a time limit, so a screen never stays on "Loading…" for ever (uploads excepted)
const API_TIMEOUT_MS = 30000;
async function api(method, url, body, opts = {}) {
  const init = { method, headers: { 'X-Requested-With': 'sop-tracker' }, credentials: 'same-origin' };
  const upload = body instanceof Blob || body instanceof ArrayBuffer;
  if (upload) { init.body = body; init.headers['Content-Type'] = opts.type || 'application/octet-stream'; }
  else if (body !== undefined) { init.body = JSON.stringify(body); init.headers['Content-Type'] = 'application/json'; }
  const limit = opts.timeout || (upload ? 0 : method === 'GET' ? API_TIMEOUT_MS : API_TIMEOUT_MS * 4);
  const ctl = limit && typeof AbortController === 'function' ? new AbortController() : null;
  let timer = null; let timedOut = false;
  if (ctl) { init.signal = ctl.signal; timer = setTimeout(() => { timedOut = true; ctl.abort(); }, limit); }
  let res; let data;
  try {
    try { res = await fetch(url, init); } catch (e) {
      throw new Error(timedOut ? `The server did not answer within ${Math.round(limit / 1000)} seconds. Press "Try again". If it keeps happening, close the other tabs of this system and see "If a screen stays on Loading" in the guide.` : 'Cannot reach the server. Check the network connection.');
    }
    if (res.status === 401 && !opts.noAuthRedirect) { App.me = null; Main.showLogin(); throw new Error('Please sign in'); }
    const ct = res.headers.get('content-type') || '';
    try { data = ct.includes('json') ? await res.json() : await res.text(); } catch (e) {
      throw new Error(timedOut ? `The server answer did not arrive within ${Math.round(limit / 1000)} seconds. Press "Try again".` : 'The server answer was incomplete. Press "Try again".');
    }
  } finally { clearTimeout(timer); }
  if (!res.ok) throw new Error((data && data.error) || `Request failed (${res.status})`);
  return data;
}

// errors in the browser are sent to the server log (data/server.log), so a problem on one laptop can be traced
const reportError = (() => {
  let n = 0;
  return (err, where) => {
    const msg = String((err && err.message) || err || '');
    if (!msg || msg === 'Please sign in' || ++n > 20 || !App.me) return;
    try {
      fetch('/api/client-log', { method: 'POST', credentials: 'same-origin', keepalive: true, headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'sop-tracker' },
        body: JSON.stringify({ msg: msg.slice(0, 500), stack: String((err && err.stack) || '').slice(0, 1500), where, url: location.hash }) }).catch(() => {});
    } catch { /* */ }
  };
})();
window.addEventListener('error', (e) => reportError(e.error || e.message, 'page'));
window.addEventListener('unhandledrejection', (e) => reportError(e.reason, 'page'));

// ---------- formatting ----------
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
function fmtDate(d) { if (!d) return '—'; const [y, m, dd] = d.slice(0, 10).split('-'); return `${Number(dd)} ${MON[Number(m) - 1]} ${y}`; }
function fmtDT(t) { if (!t) return '—'; return `${fmtDate(t)} ${t.slice(11, 16)}`; }
function fmtMonth(m) { const [y, mm] = m.split('-'); return `${MON[Number(mm) - 1]} ${y}`; }
function ago(t) {
  if (!t) return '';
  const d = (Date.now() - new Date(t.replace(' ', 'T')).getTime()) / 1000;
  if (d < 60) return 'just now'; if (d < 3600) return `${Math.floor(d / 60)} min ago`; if (d < 86400) return `${Math.floor(d / 3600)} h ago`;
  if (d < 86400 * 7) return `${Math.floor(d / 86400)} d ago`; return fmtDate(t);
}
function fmtSize(n) { if (n == null) return ''; if (n < 1024) return `${n} B`; if (n < 1048576) return `${(n / 1024).toFixed(0)} KB`; return `${(n / 1048576).toFixed(1)} MB`; }
const STATE = { waiting: 'Waiting', ready: 'Ready to start', in_progress: 'In progress', done: 'Done', na: 'Not applicable' };
function pill(state, overdueDays) {
  if (overdueDays > 0 && state !== 'done' && state !== 'na') return `<span class="pill st-overdue">Overdue ${overdueDays} d</span>`;
  return `<span class="pill st-${state}">${STATE[state] || state}</span>`;
}
function deptName(c) { const d = App.meta && App.meta.departments.find((x) => x.code === c); return d ? d.name : c; }
function deptTag(c, cls = '') { return `<span class="tag ${cls}" title="${esc(deptName(c))}">${esc(deptShort(c))}</span>`; }
function deptShort(c) { return { BD: 'BD / CEO', PM: 'Plant Mgr', RD: 'R&D', MET: 'Methodology', QC: 'QC', SC: 'Supply Chain', RA: 'RA', CTD: 'CTD', QA: 'QA', PROD: 'Production', STAB: 'Stability', ADM: 'Admin' }[c] || c; }
function stepChip(no, state, overdue, pid) {
  const cls = overdue ? 'st-overdue' : `st-${state || 'waiting'}`;
  return `<button class="sc ${cls}" data-open-step="${no}" ${pid ? `data-pid="${pid}"` : ''} title="${esc(App.stepName(no))}">${no}</button>`;
}
function items(list, cls = 'items') {
  if (!list || !list.length) return '<span class="muted">—</span>';
  return `<ol class="${cls}">${list.map((i) => `<li>${linkify(i.t)}${i.b && i.b.length ? `<ul>${i.b.map((b) => `<li>${linkify(b)}</li>`).join('')}</ul>` : ''}</li>`).join('')}</ol>`;
}
// one line per due date (a step can have one timeframe per output)
function dueLines(dues, { short = false } = {}) {
  if (!dues || !dues.length) return '';
  return dues.map((g) => `<span class="dueline ${g.overdueDays ? 'late' : ''} ${g.deferred ? 'long' : ''}" title="Output${g.outs.length > 1 ? 's' : ''} ${g.outs.join(', ')} due ${fmtDate(g.due)}${g.overdueDays ? ` — ${g.overdueDays} d overdue` : ''}">${short ? '' : `<b>out ${g.outs.join(',')}</b> `}${g.forecast ? '≈ ' : ''}${fmtDate(g.due)}${g.overdueDays ? ` · ${g.overdueDays} d late` : ''}</span>`).join('');
}
// one uploaded file / link, openable from any step that receives it
function fileChip(f) {
  if (f.kind === 'link') return `<span class="fchip">🔗 <a href="${esc(f.url)}" target="_blank" rel="noopener">${esc(f.label || f.url)}</a> <span class="small muted">${esc(deptShort(f.dept))} · ${esc(f.full_name || f.username)} · ${fmtDT(f.uploaded_at)}</span></span>`;
  return `<span class="fchip">📄 <a href="/api/files/${f.id}" target="_blank" rel="noopener" title="Open">${esc(f.filename)}</a> <a class="dl" href="/api/files/${f.id}?download=1" title="Download">⭳</a> <span class="small muted">v${f.version} · ${fmtSize(f.size)} · ${esc(deptShort(f.dept))} · ${esc(f.full_name || f.username)} · ${fmtDT(f.uploaded_at)}${f.comment ? ` · ${esc(f.comment)}` : ''}</span></span>`;
}
// one System-Upload message
function msgCard(m) {
  return `<div class="msgcard"><div class="mh"><b>${esc(m.full_name || m.username)}</b> · ${esc(deptShort(m.dept))} · ${fmtDT(m.created_at)}</div><div class="mb">${linkify(m.text)}</div></div>`;
}
function todayStr() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; }

// ---------- toast / modal ----------
function toast(msg, type = '', onClick) {
  const el = document.createElement('div');
  el.className = `toast ${type}`; el.innerHTML = msg;
  if (onClick) el.onclick = () => { onClick(); el.remove(); }; else el.onclick = () => el.remove();
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), type === 'err' ? 7000 : 5000);
}
const fail = (e) => toast(esc(e.message || e), 'err');

function modal({ title, body, width, actions = [], onOpen }) {
  const wrap = document.createElement('div');
  wrap.className = 'modal';
  wrap.innerHTML = `<div class="box" style="--w:${width || 640}px" role="dialog" aria-modal="true" aria-label="${esc(title)}">
    <div class="mh"><h3>${esc(title)}</h3><button class="btn ghost sm" data-x aria-label="Close">✕</button></div>
    <div class="mb">${body}</div>
    ${actions.length ? `<div class="mf">${actions.map((a, i) => `<button class="btn ${a.primary ? 'primary' : ''} ${a.danger ? 'danger' : ''}" data-a="${i}">${esc(a.label)}</button>`).join('')}</div>` : ''}
  </div>`;
  const close = () => { wrap.remove(); document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  wrap.addEventListener('mousedown', (e) => { if (e.target === wrap) close(); });
  $('[data-x]', wrap).onclick = close;
  actions.forEach((a, i) => {
    $(`[data-a="${i}"]`, wrap).onclick = async () => {
      if (!a.onClick) return close();
      try { const r = await a.onClick(wrap); if (r !== false) close(); } catch (e) { fail(e); }
    };
  });
  document.body.appendChild(wrap);
  const f = $('input,textarea,select', $('.mb', wrap)); if (f) f.focus();
  if (onOpen) onOpen(wrap, close);
  return { el: wrap, close };
}
function ask(title, label, { required = true, value = '', multiline = true, okLabel = 'Save', hint = '' } = {}) {
  return new Promise((resolve) => {
    let done = false;
    const m = modal({
      title, width: 520,
      body: `${hint ? `<p class="muted" style="margin:0">${hint}</p>` : ''}<label class="field"><span>${esc(label)}</span>${multiline ? `<textarea id="askv" rows="4">${esc(value)}</textarea>` : `<input type="text" id="askv" value="${esc(value)}">`}</label>`,
      actions: [{ label: 'Cancel' }, { label: okLabel, primary: true, onClick: (w) => { const v = $('#askv', w).value.trim(); if (required && !v) { toast('This field is required', 'err'); return false; } done = true; resolve(v); return true; } }],
    });
    const obs = new MutationObserver(() => { if (!document.body.contains(m.el)) { obs.disconnect(); if (!done) resolve(null); } });
    obs.observe(document.body, { childList: true });
  });
}

function confirmBox(title, text, okLabel = 'Confirm') {
  return new Promise((resolve) => {
    let done = false;
    const m = modal({ title, width: 480, body: `<p style="margin:0">${text}</p>`, actions: [{ label: 'Cancel' }, { label: okLabel, primary: true, onClick: () => { done = true; resolve(true); } }] });
    const obs = new MutationObserver(() => { if (!document.body.contains(m.el)) { obs.disconnect(); if (!done) resolve(false); } });
    obs.observe(document.body, { childList: true });
  });
}

// keep typed values & focus across live re-renders
function preserve(container, fn) {
  if (!container) return fn();
  const vals = {}; const act = document.activeElement; let focusId = null; let sel = null;
  $$('input[id],textarea[id],select[id]', container).forEach((el) => {
    if (el.type === 'file') return;
    vals[el.id] = el.type === 'checkbox' ? el.checked : el.value;
  });
  if (act && act.id && container.contains(act)) { focusId = act.id; try { sel = [act.selectionStart, act.selectionEnd]; } catch { sel = null; } }
  const scrolls = $$('[data-scroll]', container).map((el) => [el.dataset.scroll, el.scrollTop]);
  fn();
  Object.entries(vals).forEach(([id, v]) => {
    const el = document.getElementById(id); if (!el || el.dataset.nokeep !== undefined) return;
    if (el.type === 'checkbox') el.checked = v; else if (el.value !== v) el.value = v;
  });
  scrolls.forEach(([k, t]) => { const el = $(`[data-scroll="${k}"]`); if (el) el.scrollTop = t; });
  if (focusId) { const el = document.getElementById(focusId); if (el) { el.focus(); if (sel && sel[0] != null) { try { el.setSelectionRange(sel[0], sel[1]); } catch { /* */ } } } }
}

function download(url) { const a = document.createElement('a'); a.href = url; a.download = ''; document.body.appendChild(a); a.click(); a.remove(); }

function pickFile(accept) {
  return new Promise((resolve) => {
    const i = document.createElement('input'); i.type = 'file'; if (accept) i.accept = accept;
    i.onchange = () => resolve(i.files[0] || null);
    i.click();
  });
}
async function uploadFile(file, q) {
  const max = (App.meta.uploadMaxMb || 200) * 1048576;
  if (file.size > max) throw new Error(`File is larger than ${App.meta.uploadMaxMb} MB`);
  const params = new URLSearchParams({ ...q, name: file.name });
  return api('POST', `/api/upload?${params}`, file, { type: file.type || 'application/octet-stream' });
}
