@echo off
REM ===== Run ONCE as Administrator (right-click > Run as administrator) =====
REM 1) opens the firewall port for the LAN
REM 2) registers a scheduled task that starts the system automatically when the server boots
REM    (also removes the task of the previous version, "SOP Pipeline Tracker", if present)
set PORT=3000
set TASK=Multicare Pipeline Tracker
cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  echo Please right-click this file and choose "Run as administrator".
  pause
  exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install the LTS version from https://nodejs.org first.
  pause
  exit /b 1
)
if not exist "%~dp0data" mkdir "%~dp0data"
REM stop a running copy (previous version) so the new one can take the port
schtasks /end /tn "%TASK%" >nul 2>&1
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:":%PORT% .*LISTENING"') do taskkill /F /PID %%p >nul 2>&1
timeout /t 2 /nobreak >nul
schtasks /end /tn "SOP Pipeline Tracker" >nul 2>&1
schtasks /delete /tn "SOP Pipeline Tracker" /f >nul 2>&1
netsh advfirewall firewall delete rule name="SOP Pipeline Tracker" >nul 2>&1
netsh advfirewall firewall delete rule name="%TASK%" >nul 2>&1
netsh advfirewall firewall add rule name="%TASK%" dir=in action=allow protocol=TCP localport=%PORT%
schtasks /create /f /tn "%TASK%" /sc onstart /ru SYSTEM /rl HIGHEST /tr "\"%~dp0run-service.bat\""
REM Windows stops scheduled tasks after 3 days by default - remove that limit, also allow running on battery power
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew; Set-ScheduledTask -TaskName '%TASK%' -Settings $s | Out-Null"
if errorlevel 1 echo WARNING: could not remove the 3-day time limit. In Task Scheduler open "%TASK%" - Settings - untick "Stop the task if it runs longer than".
schtasks /run /tn "%TASK%"
echo.
echo Done. The system now starts automatically with the server (log: data\server.log).
echo Open http://THIS-SERVER-IP:%PORT% from any PC on the network.
echo To stop it:   schtasks /end /tn "%TASK%"
echo To remove it: schtasks /delete /tn "%TASK%" /f
pause
