'use strict';
/*
 * Multicare Pipeline Tracker and Management System — self-hosted LAN web application.
 * Zero external dependencies: Node.js ≥ 22.13 (built-in SQLite) is the only requirement.
 */
if (!process.env.TZ) process.env.TZ = 'Africa/Cairo';
const [NODE_MAJ, NODE_MIN] = process.versions.node.split('.').map(Number);
if (NODE_MAJ < 22 || (NODE_MAJ === 22 && NODE_MIN < 13)) {
  console.error(`\n  Node.js ${process.versions.node} detected — this application needs Node.js 22.13 or newer (LTS 22.x or 24.x).\n  Download: https://nodejs.org\n`);
  process.exit(1);
}
process.removeAllListeners('warning');
process.on('warning', (w) => { if (w.name !== 'ExperimentalWarning') logErr('warning', w); });

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const zlib = require('zlib');
const { pipeline } = require('stream');
const DB = require('./src/db');
const { Calendar, computeProduct, tfText, diffDays, addDays } = require('./src/engine');
const { streamZip } = require('./src/zip');

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || '0.0.0.0';
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC_DIR = path.join(__dirname, 'public');
const SESSION_HOURS = Number(process.env.SESSION_HOURS) || 12;
const APP_NAME = 'Multicare Pipeline Tracker and Management System';
const APP_VERSION = (() => { try { return require('./package.json').version; } catch { return ''; } })();

// Errors and warnings go to data/server.log. When the server runs in a console window (start-windows.bat),
// nothing is written to the window after start-up: on Windows a click inside the window (QuickEdit selection)
// pauses every write to it and would freeze the whole server until Esc is pressed.
const LOG_TO_FILE = !!process.stdout.isTTY;
function logErr(...parts) {
  const line = `${new Date().toISOString()} ${parts.map((x) => (x instanceof Error ? x.stack || x.message : typeof x === 'string' ? x : JSON.stringify(x))).join(' ')}\n`;
  if (LOG_TO_FILE) fs.appendFile(path.join(DATA_DIR, 'server.log'), line, () => {});
  else process.stderr.write(line);
}

const db = DB.open(DATA_DIR);
const { now, today } = DB;

// ───────────────────────── settings / caches ─────────────────────────
const S = {
  get(k, def = null) { const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return r ? r.value : def; },
  json(k, def) { try { const v = S.get(k); return v == null ? def : JSON.parse(v); } catch { return def; } },
  set(k, v) { db.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)').run(k, typeof v === 'string' ? v : JSON.stringify(v)); },
};
// cache versions: a change to one product only invalidates that product; SOP / calendar / access changes invalidate all
let GLOBAL_V = 1;
const PROD_V = new Map();
const bump = (pid) => { if (pid) PROD_V.set(Number(pid), (PROD_V.get(Number(pid)) || 0) + 1); else GLOBAL_V++; };

let defs = null;
function loadDefs() {
  const rows = db.prepare('SELECT id,step_no,product_id,effective_from,data,created_by,created_at,note FROM step_defs ORDER BY effective_from, id').all();
  const general = new Map(); const product = new Map();
  for (const r of rows) {
    const v = { id: r.id, step_no: r.step_no, product_id: r.product_id, effective_from: r.effective_from, created_by: r.created_by, created_at: r.created_at, note: r.note, data: JSON.parse(r.data) };
    const key = r.product_id ? `${r.product_id}:${r.step_no}` : r.step_no;
    const m = r.product_id ? product : general;
    if (!m.has(key)) m.set(key, []);
    m.get(key).push(v);
  }
  defs = { general, product };
}
loadDefs();
function stepNos() { return [...defs.general.keys()].sort((a, b) => a - b); }
function pickVersion(list, ref) {
  if (!list || !list.length) return null;
  let pick = null;
  for (const v of list) if (v.effective_from <= ref) pick = v;
  return pick;
}
function getDefFor(pid) {
  return (no, ref) => {
    ref = ref || today();
    const pv = pid ? pickVersion(defs.product.get(`${pid}:${no}`), ref) : null;
    const gv = pickVersion(defs.general.get(no), ref) || defs.general.get(no)[0];
    return (pv || gv).data;
  };
}
const curDef = (no) => getDefFor(null)(no, today());

let calCache = null;
function cal() {
  if (!calCache) {
    const hol = db.prepare('SELECT date FROM holidays').all().map((r) => r.date);
    calCache = new Calendar({ weekend: S.json('weekend', [5, 6]), holidays: hol });
  }
  return calCache;
}

const DEPTS = () => db.prepare('SELECT code,name,active,sort FROM departments ORDER BY sort, name').all();
const deptName = (c) => { const r = db.prepare('SELECT name FROM departments WHERE code=?').get(c); return r ? r.name : c; };
function stepDepts(def) {
  return [...new Set([...(def.accountable || []), ...(def.responsible || []), ...((def.outputs || []).flatMap((o) => [o.dept, ...(o.signoff || []), ...(o.by || []), ...(o.checkers || [])]).filter(Boolean))])];
}
function dependents(no) {
  const out = new Set();
  for (const n of stepNos()) {
    const d = curDef(n);
    if ((d.deps || []).includes(no)) out.add(n);
  }
  (curDef(no).outputs || []).forEach((o) => (o.to || []).forEach((t) => out.add(t)));
  out.delete(no);
  return [...out].sort((a, b) => a - b);
}

// ───────────────────────── engine wrapper ─────────────────────────
const computeCache = new Map();
function getProduct(pid) { return db.prepare('SELECT * FROM products WHERE id=?').get(pid); }
function compute(pid) {
  pid = Number(pid);
  const key = `${GLOBAL_V}|${PROD_V.get(pid) || 0}|${today()}`;
  const c = computeCache.get(pid);
  if (c && c.key === key) return c.val;
  const product = getProduct(pid);
  if (!product) return null;
  const rows = new Map(db.prepare('SELECT * FROM psteps WHERE product_id=?').all(pid).map((r) => [r.step_no, r]));
  const outs = new Map(db.prepare('SELECT * FROM poutputs WHERE product_id=?').all(pid).map((r) => [`${r.step_no}.${r.idx}`, r]));
  const ins = new Map(db.prepare('SELECT * FROM pinputs WHERE product_id=?').all(pid).map((r) => [`${r.step_no}.${r.idx}`, r]));
  const signs = new Map();
  db.prepare('SELECT * FROM poutput_signs WHERE product_id=? ORDER BY at').all(pid).forEach((r) => { const k = `${r.step_no}.${r.idx}`; if (!signs.has(k)) signs.set(k, []); signs.get(k).push(r); });
  const steps = computeProduct({ product, stepNos: stepNos(), getDef: getDefFor(pid), rows, outs, ins, signs, cal: cal(), today: today() });
  const val = { product, steps };
  computeCache.set(pid, { key, val });
  return val;
}

// open outputs grouped by due date (a step can have one timeframe per output)
function dueList(s) {
  const m = new Map();
  for (const o of s.outputs) {
    if (o.state || !(o.due || o.fDue)) continue;
    const d = o.due || o.fDue;
    if (!m.has(d)) m.set(d, { due: d, forecast: !o.due, outs: [], overdueDays: 0, deferred: false });
    const g = m.get(d); g.outs.push(o.idx); g.overdueDays = Math.max(g.overdueDays, o.overdueDays || 0); if (o.def.defer) g.deferred = true;
  }
  return [...m.values()].sort((a, b) => (a.due < b.due ? -1 : 1));
}
// SOP-controlled documents that must exist before a step can be completed
function missingDocs(pid, no) {
  return db.prepare('SELECT id, name, required_output FROM doc_types WHERE active=1 AND required_step=?').all(no)
    .filter((d) => !db.prepare('SELECT 1 FROM files WHERE product_id=? AND doc_type_id=? LIMIT 1').get(pid, d.id));
}
function accText(def) { return def.accText || (def.accountable || []).map(deptName).join(', '); }

// ---- System-Upload: every output is delivered inside the app (file and/or short message), replacing e-mail ----
const FILE_COLS = 'id,product_id,step_no,output_idx,doc_type_id,version,kind,filename,mime,size,url,label,dept,username,full_name,uploaded_at,comment,sha256';
// departments that receive an output: SOP recipients + the departments of the hand-off steps
function recipients(o, pid) {
  const r = [...(o.rcpt || []), ...(o.to || []).flatMap((x) => ownerDepts(defForProduct(pid, x)))];
  return [...new Set(r.length ? r : ['PM'])];
}
const defForProduct = (pid, no) => { try { return getDefFor(pid)(no); } catch { return { accountable: [], responsible: [] }; } };
// uploads and messages attached to the outputs of one step
function stepEvidence(pid, no) {
  const files = db.prepare(`SELECT ${FILE_COLS} FROM files WHERE product_id=? AND step_no=? ORDER BY uploaded_at DESC, id DESC`).all(pid, no);
  const msgs = db.prepare('SELECT id,output_idx,text,dept,username,full_name,created_at FROM messages WHERE product_id=? AND step_no=? ORDER BY id').all(pid, no);
  return { files, msgs };
}
// SOP-controlled documents that belong to an output (part of the output — a message alone is never enough)
function outputDocs(no) {
  return db.prepare('SELECT id,section,name,required_output FROM doc_types WHERE active=1 AND required_step=? AND required_output IS NOT NULL ORDER BY sort,id').all(no);
}
function evidenceState(pid, no, idx, ev, docs) {
  const files = ev.files.filter((f) => f.output_idx === idx);
  const msgs = ev.msgs.filter((m) => m.output_idx === idx);
  const mine = docs.filter((d) => d.required_output === idx);
  const have = new Set(mine.length ? db.prepare(`SELECT DISTINCT doc_type_id FROM files WHERE product_id=? AND doc_type_id IN (${mine.map(() => '?').join(',')})`).all(pid, ...mine.map((d) => d.id)).map((r) => r.doc_type_id) : []);
  const docsMissing = mine.filter((d) => !have.has(d.id));
  const depts = [...new Set([...files.map((f) => f.dept), ...msgs.map((m) => m.dept)].filter(Boolean))];
  return { files, msgs, docs: mine.map((d) => ({ id: d.id, name: d.name, section: d.section, uploaded: have.has(d.id) })), docsMissing, depts, any: files.length + msgs.length > 0 };
}
// Settings → Upload rules: outputs where a file upload is mandatory
const fileRequired = (no, idx) => !!((db.prepare('SELECT file_required FROM output_rules WHERE step_no=? AND output_idx=?').get(no, idx) || {}).file_required);
// who may fill an output (text / upload): its named departments + its checkers; any step editor when none are named
function canFill(user, odef) {
  if (user.role === 'admin' || !(odef.by || []).length) return true;
  return [...odef.by, ...(odef.checkers || [])].includes(user.dept);
}
function fillGuard(user, odef, idx) {
  if (!canFill(user, odef)) fail(403, `Output ${idx} is filled by ${odef.by.map(deptName).join(', ')}${(odef.checkers || []).length ? ` (or ${odef.checkers.map(deptName).join(' / ')})` : ''}.`);
}
// rule applied before an output can be checked as done
function evidenceProblem(o, es, signDepts, isAdmin, fileReq) {
  if (es.docsMissing.length) return `Upload the SOP-controlled document${es.docsMissing.length > 1 ? 's' : ''} of output ${o.idx} first: ${es.docsMissing.map((d) => d.name).join('; ')}. A message alone is not enough for SOP-controlled documents.`;
  if (fileReq && !es.files.some((f) => f.kind !== 'link')) return `A file upload is required for output ${o.idx} (set in Settings → Upload rules) — a message or a link alone is not enough.`;
  if (es.docs.length) return null;
  if (!es.any) return `System-Upload is required first: upload a file or write a short message on output ${o.idx} before checking it.`;
  if (signDepts && signDepts.length && !isAdmin) {
    const missing = signDepts.filter((d) => !es.depts.includes(d));
    if (missing.length) return `${missing.map(deptName).join(' and ')}: add your System-Upload (a file or a short message) to output ${o.idx} before checking it.`;
  }
  return null;
}

function summarize(pid) {
  const c = compute(pid); if (!c) return null;
  const { product, steps } = c;
  const LS = Number(S.get('license_step', 30)); const LO = Number(S.get('license_output', 1));
  const CS = Number(S.get('commercial_step', 34)); const CO = Number(S.get('commercial_output', 1));
  const arr = [...steps.values()];
  const lic = arr.filter((s) => s.no <= LS);
  const done = lic.filter((s) => s.state === 'done').length;
  const na = lic.filter((s) => s.state === 'na').length;
  const denom = Math.max(1, LS - na);
  const brief = (s) => ({ no: s.no, name: s.def.name, acc: accText(s.def), accountable: s.def.accountable });
  const lastDone = arr.filter((s) => s.state === 'done').sort((a, b) => (a.completed_at < b.completed_at ? 1 : -1))[0];
  const inProc = arr.filter((s) => s.state === 'in_progress').map((s) => ({ ...brief(s), due: s.due, overdueDays: s.overdueDays, dues: dueList(s), released: s.released, deferLabels: s.deferLabels }));
  const ready = arr.filter((s) => s.state === 'ready').map((s) => ({ ...brief(s), readyDate: s.readyDate, waitWD: s.waitWD, due: s.due, dues: dueList(s) }));
  const overdue = arr.filter((s) => s.overdue).map((s) => ({ ...brief(s), due: s.due, overdueDays: s.overdueDays, outs: s.outputs.filter((o) => o.overdueDays > 0).map((o) => ({ idx: o.idx, due: o.due, days: o.overdueDays })) }));
  // next deadline: earliest open output due date that is today or later (else earliest overdue)
  const open = [];
  arr.filter((s) => s.state === 'ready' || s.state === 'in_progress').forEach((s) => s.outputs.forEach((o) => { if (!o.state && o.due) open.push({ ...brief(s), due: o.due, output: o.idx }); }));
  open.sort((a, b) => (a.due < b.due ? -1 : 1));
  const next = open.find((x) => x.due >= today()) || open[0] || null;
  const cancelled = arr.filter((s) => s.state === 'na').map((s) => ({ ...brief(s), reason: s.na_reason, at: s.na_at, by: s.na_by }));
  const risks = db.prepare("SELECT * FROM risks WHERE product_id=? AND status='open' ORDER BY CASE severity WHEN 'Critical' THEN 0 WHEN 'Major' THEN 1 ELSE 2 END, id DESC").all(pid);
  const outForecast = (sn, oi) => {
    const s = steps.get(sn); if (!s) return null;
    if (s.state === 'na') return null;
    const o = s.outputs[oi - 1];
    if (o && o.state === 'done') return { date: o.at.slice(0, 10), actual: true };
    if (s.state === 'done') return { date: s.completed_at.slice(0, 10), actual: true };
    const d = o ? (o.due || o.fDue) : s.fClose;
    return { date: d && d < today() ? today() : d, actual: false };
  };
  const phases = S.json('phases', []);
  const curPhase = (arr.find((s) => s.state !== 'done' && s.state !== 'na') || {}).def;
  return {
    id: product.id, name: product.name, api: product.api, dosage: product.dosage, markets: product.markets,
    start_date: product.start_date, status: product.status, created_at: product.created_at,
    progress: { done, na, denom, total: LS, pct: Math.round((done / denom) * 1000) / 10 },
    phase: curPhase ? phases.find((p) => p.no === curPhase.phase) : { no: 8, name: 'Completed' },
    lastDone: lastDone ? { ...brief(lastDone), at: lastDone.completed_at } : null,
    inProc, ready, overdue, next, cancelled,
    risks: risks.map((r) => ({ id: r.id, step_no: r.step_no, severity: r.severity, title: r.title, action: r.action, owner_dept: r.owner_dept, raised_at: r.raised_at })),
    criticalRisks: risks.filter((r) => r.severity === 'Critical').length,
    license: outForecast(LS, LO), commercial: outForecast(CS, CO),
    allDone: arr.every((s) => s.closed),
  };
}

// ───────────────────────── permissions ─────────────────────────
function userPerms(user) {
  if (!user._perms) user._perms = new Map(db.prepare('SELECT step_no, level FROM perms WHERE user_id=?').all(user.id).map((r) => [r.step_no, r.level]));
  return user._perms;
}
function defaultLevel(dept, no) { return stepDepts(curDef(no)).includes(dept) ? 'edit' : 'view'; }
function stepLevel(user, no) {
  if (user.role === 'admin') return 'edit';
  const p = userPerms(user).get(no);
  return p || defaultLevel(user.dept, no);
}
const isExec = (u) => u.role === 'admin' || u.role === 'executive';
// Dashboard: Plant Manager, CEO / Business Development (executives) and the administrator
const canDash = (u) => isExec(u) || ['PM', 'BD'].includes(u.dept);
const needDash = (u) => { if (!canDash(u)) fail(403, 'The dashboard is available to the Plant Manager, CEO / Business Development and the administrator'); };

// ───────────────────────── notifications / events / live ─────────────────────────
const clients = new Set();
// change counters, read by browsers that check for updates instead of keeping a live connection
const live = { v: 1, mv: 1 };
function broadcast(evt) {
  if (evt.t !== 'presence' && evt.t !== 'hello') { live.v++; if (evt.t === 'all') live.mv++; }
  const data = `data: ${JSON.stringify(evt)}\n\n`;
  for (const c of clients) { try { c.res.write(data); } catch { clients.delete(c); } }
}
function notify(depts, n) {
  const list = [...new Set(depts.filter(Boolean))];
  if (!list.length) return;
  const ins = db.prepare('INSERT INTO notifications(created_at,dept,product_id,step_no,type,title,body,from_user,from_dept,ann_id) VALUES(?,?,?,?,?,?,?,?,?,?)');
  const t = now();
  for (const d of list) ins.run(t, d, n.product_id ?? null, n.step_no ?? null, n.type || 'update', n.title || '', n.body || '', n.from_user || null, n.from_dept || null, n.ann_id ?? null);
  broadcast({ t: 'notif', depts: list });
}
function logEvent(pid, no, user, action, detail) {
  db.prepare('INSERT INTO events(product_id,step_no,at,username,dept,action,detail) VALUES(?,?,?,?,?,?,?)')
    .run(pid ?? null, no ?? null, now(), user ? (user.full_name || user.username) : 'system', user ? user.dept : null, action, detail || null);
}
const ownerDepts = (def) => [...new Set([...(def.accountable || []), ...(def.responsible || [])])];

const START_ALERT_WD = Number(process.env.START_ALERT_WD) || 2;
// after any change: detect hand-offs (steps that became ready) and newly overdue steps
function afterChange(pid, actor, { silent = false, noBump = false } = {}) {
  if (!noBump) bump(pid);
  const c = compute(pid); if (!c) return;
  if (silent) {
    // align the stored states with the current ones without notifying (after the SOP version 3 upgrade)
    const up = db.prepare('INSERT INTO psteps(product_id,step_no,last_state) VALUES(?,?,?) ON CONFLICT(product_id,step_no) DO UPDATE SET last_state=excluded.last_state');
    for (const s of c.steps.values()) up.run(pid, s.no, s.state);
    return;
  }
  const pname = c.product.name;
  const upd = db.prepare('INSERT INTO psteps(product_id,step_no,last_state,overdue_notified,start_alert) VALUES(?,?,?,?,?) ON CONFLICT(product_id,step_no) DO UPDATE SET last_state=excluded.last_state, overdue_notified=excluded.overdue_notified, start_alert=excluded.start_alert');
  const rows = new Map(db.prepare('SELECT step_no,last_state,overdue_notified,start_alert FROM psteps WHERE product_id=?').all(pid).map((r) => [r.step_no, r]));
  let changed = false;
  for (const s of c.steps.values()) {
    const prev = rows.get(s.no) || {};
    let od = prev.overdue_notified || 0;
    let sa = prev.start_alert || 0;
    if (s.state === 'ready' && prev.last_state !== 'ready' && (prev.last_state == null || prev.last_state === 'waiting')) {
      notify(ownerDepts(s.def), {
        product_id: pid, step_no: s.no, type: 'handoff',
        title: `Step ${s.no} is ready to start — ${pname}`,
        body: `"${s.def.name}" became ready on ${s.readyDate}. SOP deadline: ${s.due}.`,
        from_user: actor ? actor.full_name || actor.username : 'System', from_dept: actor ? actor.dept : null,
      });
    }
    // ready but not started within 2 working days → Plant Manager, Business Development and the accountable departments
    if (s.state === 'ready' && s.waitWD > START_ALERT_WD && !sa) {
      notify([...ownerDepts(s.def), 'PM', 'BD'], {
        product_id: pid, step_no: s.no, type: 'delay',
        title: `Step ${s.no} not started ${s.waitWD} working days after becoming ready — ${pname}`,
        body: `"${s.def.name}" has been ready since ${s.readyDate} and has not been started. Accountable: ${accText(s.def)}.`, from_user: 'System',
      });
      sa = 1;
    } else if (s.state !== 'ready') sa = 0;
    if (s.overdue && !od) {
      notify([...ownerDepts(s.def), 'PM', 'BD'], {
        product_id: pid, step_no: s.no, type: 'overdue',
        title: `Step ${s.no} is overdue — ${pname}`,
        body: `"${s.def.name}" passed its deadline — ${s.outputs.filter((o) => o.overdueDays > 0).map((o) => `output ${o.idx} due ${o.due} (${o.overdueDays} d)`).join(', ') || s.due}. Accountable: ${accText(s.def)}.`, from_user: 'System',
      });
      od = 1;
    } else if (!s.overdue) od = 0;
    if (prev.last_state !== s.state || (prev.overdue_notified || 0) !== od || (prev.start_alert || 0) !== sa) { upd.run(pid, s.no, s.state, od, sa); changed = true; }
  }
  if (actor || changed) broadcast({ t: 'product', id: pid });
}

// ───────────────────────── HTTP helpers ─────────────────────────
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.woff2': 'font/woff2' };
function send(res, code, obj, headers = {}) {
  let body = typeof obj === 'string' || Buffer.isBuffer(obj) ? obj : JSON.stringify(obj);
  const h = { 'Content-Type': typeof obj === 'string' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers };
  // compress larger responses (step panels, document lists) — less waiting on slow network segments
  if (res._gzip && body.length > 2048) { body = zlib.gzipSync(body, { level: 5 }); h['Content-Encoding'] = 'gzip'; h.Vary = 'Accept-Encoding'; }
  res.writeHead(code, h);
  res.end(body);
}
// stream an upload straight to disk (never held in memory), with size limit and SHA-256 checksum
function receiveFile(req, absPath, limit) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256'); let size = 0; let failed = false;
    const out = fs.createWriteStream(absPath);
    const abort = (err) => { if (failed) return; failed = true; req.unpipe(out); out.destroy(); fs.unlink(absPath, () => {}); reject(err); };
    req.on('data', (c) => { size += c.length; hash.update(c); if (size > limit) { abort(new HttpError(413, `File too large (limit ${Math.round(limit / 1048576)} MB)`)); req.resume(); } });
    req.on('error', abort);
    out.on('error', abort);
    out.on('finish', () => { if (!failed) resolve({ size, sha256: hash.digest('hex') }); });
    req.pipe(out);
  });
}
class HttpError extends Error { constructor(code, msg) { super(msg); this.code = code; } }
const fail = (code, msg) => { throw new HttpError(code, msg); };
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new HttpError(413, `File too large (limit ${Math.round(limit / 1048576)} MB)`)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
function cookies(req) {
  const out = {}; (req.headers.cookie || '').split(';').forEach((p) => { const i = p.indexOf('='); if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); });
  return out;
}
function contentDisposition(type, name) {
  const ascii = String(name || 'file').replace(/[^\x20-\x7e]/g, '_').replace(/"/g, "'");
  return `${type}; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(name || 'file')}`;
}
const toBuf = (u8) => (u8 ? Buffer.from(u8.buffer, u8.byteOffset, u8.byteLength) : Buffer.alloc(0));
function csv(rows) {
  const esc = (v) => { const s = v == null ? '' : String(v); return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  return '﻿' + rows.map((r) => r.map(esc).join(',')).join('\r\n');
}
const str = (v, max = 5000) => (v == null ? '' : String(v)).trim().slice(0, max);
const isDate = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d || '');

// login throttling
const fails = new Map();
function throttle(ip) {
  const f = fails.get(ip); if (!f) return;
  if (f.n >= 8 && Date.now() - f.t < 5 * 60 * 1000) fail(429, 'Too many failed attempts. Try again in 5 minutes.');
  if (Date.now() - f.t > 10 * 60 * 1000) fails.delete(ip);
}

// ───────────────────────── routes ─────────────────────────
const routes = [];
const route = (method, pattern, handler, opts = {}) => {
  const keys = []; const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
  routes.push({ method, re, keys, handler, opts });
};

function publicUser(u) {
  const unread = db.prepare('SELECT COUNT(*) n FROM notifications n WHERE n.dept=? AND NOT EXISTS (SELECT 1 FROM notif_reads r WHERE r.user_id=? AND r.notif_id=n.id)').get(u.dept, u.id).n;
  return { id: u.id, username: u.username, full_name: u.full_name, dept: u.dept, dept_name: deptName(u.dept), role: u.role, must_change: !!u.must_change, unread };
}

// ---- auth
route('GET', '/api/public/info', () => ({ appName: APP_NAME, company: S.get('company_name'), departments: DEPTS().filter((d) => d.active) }), { public: true });
route('POST', '/api/login', ({ body, req }) => {
  const ip = req.socket.remoteAddress; throttle(ip);
  const u = db.prepare('SELECT * FROM users WHERE username=? AND active=1').get(str(body.username, 100));
  if (!u || u.dept !== body.dept || !DB.checkPassword(body.password || '', u.pw_salt, u.pw_hash)) {
    const f = fails.get(ip) || { n: 0, t: Date.now() }; f.n++; f.t = Date.now(); fails.set(ip, f);
    fail(401, 'Wrong department, username or password');
  }
  fails.delete(ip);
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token,user_id,created_at,expires) VALUES(?,?,?,?)').run(token, u.id, now(), Date.now() + SESSION_HOURS * 3600e3);
  db.prepare('UPDATE users SET last_login=? WHERE id=?').run(now(), u.id);
  return { _cookie: `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_HOURS * 3600}`, user: publicUser(u) };
}, { public: true });
route('POST', '/api/logout', ({ req }) => {
  const t = cookies(req).sid; if (t) db.prepare('DELETE FROM sessions WHERE token=?').run(t);
  return { _cookie: 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0', ok: true };
}, { public: true });
route('GET', '/api/me', ({ user }) => publicUser(user));
route('POST', '/api/me/password', ({ user, body }) => {
  if (!DB.checkPassword(body.current || '', user.pw_salt, user.pw_hash)) fail(400, 'Current password is not correct');
  if (str(body.password).length < 6) fail(400, 'New password must be at least 6 characters');
  const { hash, salt } = DB.hashPassword(body.password);
  db.prepare('UPDATE users SET pw_hash=?, pw_salt=?, must_change=0 WHERE id=?').run(hash, salt, user.id);
  return { ok: true };
}, { allowMustChange: true });

// ---- meta
route('GET', '/api/meta', ({ user }) => ({
  company: S.get('company_name'),
  departments: DEPTS(),
  phases: S.json('phases', []),
  flow: S.json('flow', []),
  docSections: S.json('doc_sections', []),
  appName: APP_NAME, canDash: canDash(user), canAnnounce: canAnnounce(user), generalNotes: S.json('general_notes', []),
  docTypes: db.prepare('SELECT id,section,name,steps,also_in,sort,active,required_step,required_output FROM doc_types ORDER BY sort,id').all().map((d) => ({ ...d, steps: JSON.parse(d.steps), also_in: JSON.parse(d.also_in || '[]') })),
  steps: stepNos().map((n) => { const d = curDef(n); return { no: n, name: d.name, phase: d.phase, accountable: d.accountable, responsible: d.responsible || [], accText: accText(d), deps: d.deps || [], loop: !!d.loop, conditional: d.conditional || null, depts: stepDepts(d), level: stepLevel(user, n), handoff: dependents(n) }; }),
  weekend: S.json('weekend', [5, 6]),
  holidays: db.prepare('SELECT date,name FROM holidays ORDER BY date').all(),
  license_step: Number(S.get('license_step', 30)), commercial_step: Number(S.get('commercial_step', 34)),
  today: today(),
  uploadMaxMb: Number(S.get('upload_max_mb', 200)),
}));

// ---- products
route('GET', '/api/products', ({ query, user }) => {
  const rows = db.prepare(`SELECT id FROM products ${query.all ? '' : "WHERE status!='archived'"} ORDER BY id`).all();
  if (!canDash(user)) return rows.map((r) => { const p = getProduct(r.id); return { id: p.id, name: p.name, status: p.status, api: p.api, dosage: p.dosage, markets: p.markets, start_date: p.start_date }; });
  return rows.map((r) => summarize(r.id));
});
route('POST', '/api/products', ({ user, body }) => {
  if (!isExec(user)) fail(403, 'Only executives / administrators can create products');
  const name = str(body.name, 200); if (!name) fail(400, 'Product name is required');
  if (!isDate(body.start_date)) fail(400, 'Start date is required');
  const r = db.prepare('INSERT INTO products(name,api,dosage,markets,start_date,created_by,created_at,notes) VALUES(?,?,?,?,?,?,?,?)')
    .run(name, str(body.api, 200), str(body.dosage, 200), str(body.markets, 300), body.start_date, user.username, now(), str(body.notes));
  const pid = Number(r.lastInsertRowid);
  logEvent(pid, null, user, 'product.create', `Created product "${name}" — start date ${body.start_date}`);
  notify(DEPTS().map((d) => d.code).filter((c) => c !== 'ADM'), { product_id: pid, type: 'update', title: `New product project created: ${name}`, body: `API: ${str(body.api) || '—'} · ${str(body.dosage) || ''} · Markets: ${str(body.markets) || '—'} · Step 1 start: ${body.start_date}`, from_user: user.full_name || user.username, from_dept: user.dept });
  afterChange(pid, user);
  return summarize(pid);
});
route('PUT', '/api/products/:id', ({ user, params, body }) => {
  if (!isExec(user)) fail(403, 'Only executives / administrators can edit products');
  const p = getProduct(params.id); if (!p) fail(404, 'Product not found');
  const f = { name: str(body.name ?? p.name, 200), api: str(body.api ?? p.api, 200), dosage: str(body.dosage ?? p.dosage, 200), markets: str(body.markets ?? p.markets, 300), start_date: isDate(body.start_date) ? body.start_date : p.start_date, status: ['active', 'on_hold', 'archived'].includes(body.status) ? body.status : p.status };
  db.prepare('UPDATE products SET name=?,api=?,dosage=?,markets=?,start_date=?,status=? WHERE id=?').run(f.name, f.api, f.dosage, f.markets, f.start_date, f.status, p.id);
  logEvent(p.id, null, user, 'product.edit', `Product details updated (${Object.keys(body).join(', ')})`);
  afterChange(p.id, user);
  return summarize(p.id);
});
route('DELETE', '/api/products/:id', ({ user, params }) => {
  if (user.role !== 'admin') fail(403, 'Only the administrator can delete a product');
  db.prepare('DELETE FROM products WHERE id=?').run(params.id);
  db.prepare('DELETE FROM notifications WHERE product_id=?').run(params.id);
  fs.rm(path.join(DATA_DIR, 'files', String(Number(params.id))), { recursive: true, force: true }, () => {});
  bump(params.id); broadcast({ t: 'product', id: Number(params.id) });
  return { ok: true };
});

function stepLite(s, user, pid) {
  return {
    no: s.no, name: s.def.name, phase: s.def.phase, state: s.state, overdue: s.overdue, overdueDays: s.overdueDays,
    readyDate: s.readyDate, due: s.due, fClose: s.fClose, fReady: s.fReady, waitWD: s.waitWD, onTime: s.onTime, lateDays: s.lateDays,
    started_at: s.started_at, completed_at: s.completed_at, na_reason: s.na_reason, na_at: s.na_at,
    accountable: s.def.accountable, accText: accText(s.def), loop: !!s.def.loop, conditional: s.def.conditional || null,
    outputsDone: s.outputsDone, outputsTotal: s.outputs.length, inputsDone: s.inputsDone, inputsTotal: s.inputs.length,
    iterations: s.iterations, level: stepLevel(user, s.no), deps: s.deps, due_override: s.due_override,
    dues: dueList(s), released: s.released, releaseDate: s.releaseDate, deferLabels: s.deferLabels,
  };
}
route('GET', '/api/products/:id', ({ user, params }) => {
  const c = compute(Number(params.id)); if (!c) fail(404, 'Product not found');
  const pid = c.product.id;
  const counts = new Map(db.prepare('SELECT step_no, COUNT(*) n FROM notes WHERE product_id=? GROUP BY step_no').all(pid).map((r) => [r.step_no, r.n]));
  const rk = new Map(db.prepare("SELECT step_no, COUNT(*) n FROM risks WHERE product_id=? AND status='open' GROUP BY step_no").all(pid).map((r) => [r.step_no, r.n]));
  const docs = db.prepare('SELECT doc_type_id, COUNT(*) n, MAX(version) v, MAX(uploaded_at) last FROM files WHERE product_id=? AND doc_type_id IS NOT NULL GROUP BY doc_type_id').all(pid);
  return {
    summary: summarize(pid),
    steps: [...c.steps.values()].map((s) => ({ ...stepLite(s, user, pid), notes: counts.get(s.no) || 0, risks: rk.get(s.no) || 0, docsMissing: s.closed ? 0 : missingDocs(pid, s.no).length })),
    docCounts: Object.fromEntries(docs.map((d) => [d.doc_type_id, { n: d.n, v: d.v, last: d.last }])),
  };
});

route('GET', '/api/products/:id/steps/:no', ({ user, params }) => {
  const pid = Number(params.id); const no = Number(params.no);
  const c = compute(pid); if (!c) fail(404, 'Product not found');
  const s = c.steps.get(no); if (!s) fail(404, 'Step not found');
  const level = stepLevel(user, no);
  if (level === 'none') return { no, name: s.def.name, level, restricted: true, state: s.state };
  const ev = stepEvidence(pid, no);
  const files = ev.files;
  const oDocs = outputDocs(no);
  const docTypes = db.prepare('SELECT id,section,name,steps,required_step,required_output FROM doc_types WHERE active=1 ORDER BY sort,id').all().filter((d) => JSON.parse(d.steps).includes(no) || d.required_step === no);
  const docVersions = docTypes.map((d) => ({ id: d.id, section: d.section, name: d.name, required: d.required_step === no, out: d.required_step === no ? d.required_output : null, versions: db.prepare('SELECT id,step_no,output_idx,version,filename,mime,size,dept,username,full_name,uploaded_at,comment,sha256 FROM files WHERE product_id=? AND doc_type_id=? ORDER BY version DESC').all(pid, d.id) }));
  // what the source steps delivered for each input (System-Upload files and messages, openable here)
  const srcCache = new Map();
  const srcEv = (sn) => { if (!srcCache.has(sn)) srcCache.set(sn, stepEvidence(pid, sn)); return srcCache.get(sn); };
  const delivered = (srcs) => srcs.flatMap((x) => {
    const sx = c.steps.get(x.step); if (!sx) return [];
    const e = srcEv(x.step);
    const outs = x.out ? [x.out] : sx.outputs.map((o) => o.idx);
    return outs.map((oi) => ({ step: x.step, out: oi, files: e.files.filter((f) => f.output_idx === oi), msgs: e.msgs.filter((m) => m.output_idx === oi) })).filter((g) => g.files.length || g.msgs.length);
  });
  const signDeptsOf = (o) => (o.def.signoff || []).filter(Boolean);
  const notes = db.prepare('SELECT * FROM notes WHERE product_id=? AND step_no=? ORDER BY id').all(pid, no).map((n) => ({ ...n, to_depts: JSON.parse(n.to_depts || '[]'), to_steps: JSON.parse(n.to_steps || '[]') }));
  const incoming = db.prepare('SELECT * FROM notes WHERE product_id=? AND step_no<>? ORDER BY id').all(pid, no)
    .map((n) => ({ ...n, to_depts: JSON.parse(n.to_depts || '[]'), to_steps: JSON.parse(n.to_steps || '[]') }))
    .filter((n) => n.to_steps.includes(no));
  const risks = db.prepare('SELECT * FROM risks WHERE product_id=? AND step_no=? ORDER BY status DESC, id DESC').all(pid, no);
  const history = db.prepare('SELECT at,username,dept,action,detail FROM events WHERE product_id=? AND step_no=? ORDER BY id DESC').all(pid, no);
  const stepName = (n) => { const x = c.steps.get(n); return x ? x.def.name : ''; };
  return {
    ...stepLite(s, user, pid), level, product: { id: c.product.id, name: c.product.name },
    def: s.def, accText: accText(s.def), responsible: s.def.responsible || [],
    tf: s.outputs.map((o) => o.def.tfLabel || tfText(o.tf)),
    deps: s.deps.map((d) => ({ no: d, name: stepName(d), state: c.steps.get(d).state, released: c.steps.get(d).released })),
    handoff: dependents(no).map((d) => ({ no: d, name: stepName(d), state: c.steps.get(d) ? c.steps.get(d).state : null, acc: c.steps.get(d) ? accText(c.steps.get(d).def) : '' })),
    inputs: s.inputs.map((i) => ({ idx: i.idx, t: i.def.t, b: i.def.b || [], dept: i.def.dept || null, confirmed: i.confirmed, at: i.at, by: i.by, available: i.available, sources: i.sources.map((x) => ({ ...x, name: stepName(x.step) })), delivered: delivered(i.sources) })),
    outputs: s.outputs.map((o) => {
      const es = evidenceState(pid, no, o.idx, ev, oDocs);
      const so = signDeptsOf(o);
      // which department(s) of the current user may still need to add their own System-Upload
      const fr = fileRequired(no, o.idx);
      const myProblem = o.state ? null : evidenceProblem(o, es, so.length ? (user.role === 'admin' ? [] : so.filter((d) => d === user.dept)) : [], user.role === 'admin', fr);
      const ck = o.def.checkers || [];
      const canCheck = level === 'edit' && (user.role === 'admin' || ((!so.length || so.includes(user.dept)) && (!ck.length || ck.includes(user.dept))));
      return {
        idx: o.idx, t: o.def.t, b: o.def.b || [], dept: o.def.dept, to: o.def.to || [], rcpt: recipients(o.def, pid), fin: !!o.def.fin, assumed: !!o.def.assumed, tfText: o.def.tfLabel || tfText(o.tf), tfShort: tfText(o.tf), rel: o.def.rel || null, due: o.due, fDue: o.fDue, state: o.state, at: o.at, by: o.by, reason: o.reason, overdue: o.overdueDays || 0, defer: !!o.def.defer, deferLabel: o.def.deferLabel || null, releaseTo: o.def.releaseTo || null, signoff: so, signs: o.signs.map((g) => ({ dept: g.dept, at: g.at, by: g.by })),
        files: es.files, msgs: es.msgs, docs: es.docs, evidenceOk: !myProblem, evidenceHint: myProblem,
        fileReq: fr, by: o.def.by || [], checkers: ck, group: o.def.group || null, canFill: level === 'edit' && canFill(user, o.def), canCheck,
      };
    }),
    missingDocs: s.closed ? [] : missingDocs(pid, no).map((d) => d.name), canComplete: s.canComplete && (s.closed || !missingDocs(pid, no).length), files, docVersions, notes, incoming, risks, history,
    started_by: s.started_by, completed_by: s.completed_by, na_by: s.na_by,
  };
});

// ---- step actions
function requireEdit(user, no) { if (stepLevel(user, no) !== 'edit') fail(403, `You have view-only access to step ${no}. Ask the administrator for editor rights.`); }
function ensureRow(pid, no) { db.prepare('INSERT OR IGNORE INTO psteps(product_id,step_no) VALUES(?,?)').run(pid, no); }

route('POST', '/api/products/:id/steps/:no/action', ({ user, params, body }) => {
  const pid = Number(params.id); const no = Number(params.no);
  const c = compute(pid); if (!c) fail(404, 'Product not found');
  const s = c.steps.get(no); if (!s) fail(404, 'Step not found');
  const who = user.full_name || user.username; const t = now();
  const act = body.action; const reason = str(body.reason, 2000);
  ensureRow(pid, no);
  const pname = c.product.name;
  const handoffDepts = () => [...new Set(dependents(no).flatMap((d) => ownerDepts(curDef(d))))];
  switch (act) {
    case 'start':
      requireEdit(user, no);
      if (s.state !== 'ready') fail(400, s.state === 'waiting' ? 'This step is still waiting for its dependencies to close.' : `Step cannot be started (current state: ${s.state}).`);
      db.prepare('UPDATE psteps SET started_at=?, started_by=? WHERE product_id=? AND step_no=?').run(t, who, pid, no);
      logEvent(pid, no, user, 'step.start', `Step started (waited ${s.waitWD} working day(s) since ready on ${s.readyDate})`);
      notify(handoffDepts().concat(ownerDepts(s.def)).filter((d) => d !== user.dept), { product_id: pid, step_no: no, type: 'update', title: `Step ${no} started — ${pname}`, body: `"${s.def.name}" was started by ${who} (${deptName(user.dept)}).`, from_user: who, from_dept: user.dept });
      break;
    case 'complete':
      requireEdit(user, no);
      if (s.state !== 'in_progress') fail(400, 'Only an in-progress step can be completed. Start the step first.');
      if (!s.inputs.every((x) => x.confirmed)) fail(400, 'Confirm receipt of all inputs before completing the step.');
      if (!s.outputs.every((o) => o.state)) fail(400, 'Tick all required outputs (or mark them not applicable) before completing the step.');
      { const md = missingDocs(pid, no); if (md.length) fail(400, `Upload the required document${md.length > 1 ? 's' : ''} first: ${md.map((d) => d.name).join('; ')}`); }
      db.prepare('UPDATE psteps SET completed_at=?, completed_by=? WHERE product_id=? AND step_no=?').run(t, who, pid, no);
      logEvent(pid, no, user, 'step.complete', s.due && today() > s.due ? `Completed ${diffDays(s.due, today())} day(s) after the deadline (${s.due})` : `Completed within timeframe (deadline ${s.due})`);
      notify(handoffDepts().concat(ownerDepts(s.def), ['PM']), { product_id: pid, step_no: no, type: 'update', title: `Step ${no} completed — ${pname}`, body: `"${s.def.name}" was completed by ${who} (${deptName(user.dept)}).`, from_user: who, from_dept: user.dept });
      break;
    case 'na':
      if (stepLevel(user, no) !== 'edit' && !isExec(user)) fail(403, 'Not allowed');
      if (s.state === 'done') fail(400, 'Step is already completed. Re-open it first.');
      if (!reason) fail(400, 'A reason is required to mark a step as not applicable (cancelled).');
      db.prepare('UPDATE psteps SET na_at=?, na_by=?, na_reason=? WHERE product_id=? AND step_no=?').run(t, who, reason, pid, no);
      logEvent(pid, no, user, 'step.na', `Marked not applicable: ${reason}`);
      notify(handoffDepts().concat(ownerDepts(s.def), ['PM']), { product_id: pid, step_no: no, type: 'update', title: `Step ${no} marked not applicable — ${pname}`, body: `Reason: ${reason}`, from_user: who, from_dept: user.dept });
      break;
    case 'reopen':
      if (!isExec(user)) fail(403, 'Only executives / administrators can re-open a step');
      if (!reason) fail(400, 'A reason is required to re-open a step');
      db.prepare('UPDATE psteps SET completed_at=NULL, completed_by=NULL, na_at=NULL, na_by=NULL, na_reason=NULL WHERE product_id=? AND step_no=?').run(pid, no);
      logEvent(pid, no, user, 'step.reopen', `Re-opened: ${reason}`);
      notify(ownerDepts(s.def), { product_id: pid, step_no: no, type: 'update', title: `Step ${no} re-opened — ${pname}`, body: `Reason: ${reason}`, from_user: who, from_dept: user.dept });
      break;
    case 'unstart':
      if (!isExec(user)) fail(403, 'Only executives / administrators can reset a step');
      db.prepare('UPDATE psteps SET started_at=NULL, started_by=NULL WHERE product_id=? AND step_no=?').run(pid, no);
      logEvent(pid, no, user, 'step.reset', `Start reset: ${reason}`);
      break;
    case 'remind': {
      if (stepLevel(user, no) === 'none') fail(403, 'Not allowed');
      const msg = reason || `Kind reminder about step ${no} "${s.def.name}" (state: ${s.state}${s.due ? `, deadline ${s.due}` : ''}).`;
      notify(ownerDepts(s.def), { product_id: pid, step_no: no, type: 'reminder', title: `Reminder from ${deptName(user.dept)} — step ${no}, ${pname}`, body: msg, from_user: who, from_dept: user.dept });
      logEvent(pid, no, user, 'step.remind', msg);
      break;
    }
    case 'iterate': {
      requireEdit(user, no);
      if (!s.def.loop) fail(400, 'This step is not part of an iterative loop');
      if (s.state !== 'in_progress') fail(400, 'Start the step before logging loop iterations');
      const n = (s.iterations || 0) + 1;
      db.prepare('UPDATE psteps SET iterations=? WHERE product_id=? AND step_no=?').run(n, pid, no);
      logEvent(pid, no, user, 'step.iteration', `Loop iteration #${n}${reason ? `: ${reason}` : ''}`);
      const partner = S.json('flow', []).find((g) => g.type === 'loop' && g.steps.includes(no));
      const others = partner ? partner.steps.filter((x) => x !== no) : [];
      notify(others.flatMap((o) => ownerDepts(curDef(o))), { product_id: pid, step_no: no, type: 'handoff', title: `Loop iteration #${n} hand-off from step ${no} — ${pname}`, body: reason || `Step ${no} logged iteration #${n}.`, from_user: who, from_dept: user.dept });
      break;
    }
    case 'due': {
      if (!isExec(user)) fail(403, 'Only executives / administrators can change a deadline');
      const d = body.date || null;
      if (d && !isDate(d)) fail(400, 'Invalid date');
      db.prepare('UPDATE psteps SET due_override=?, due_override_reason=? WHERE product_id=? AND step_no=?').run(d, reason || null, pid, no);
      logEvent(pid, no, user, 'step.deadline', d ? `Deadline changed to ${d}${reason ? ` — ${reason}` : ''}` : 'Deadline override removed (back to SOP timeframe)');
      notify(ownerDepts(s.def), { product_id: pid, step_no: no, type: 'update', title: `Deadline changed for step ${no} — ${pname}`, body: d ? `New deadline ${d}. ${reason}` : 'Deadline returned to the SOP timeframe.', from_user: who, from_dept: user.dept });
      break;
    }
    default: fail(400, 'Unknown action');
  }
  afterChange(pid, user);
  return { ok: true };
});

route('POST', '/api/products/:id/steps/:no/inputs/:idx', ({ user, params, body }) => {
  const pid = Number(params.id); const no = Number(params.no); const idx = Number(params.idx);
  requireEdit(user, no);
  const s = compute(pid).steps.get(no);
  if (!['ready', 'in_progress'].includes(s.state)) fail(400, 'Inputs can be confirmed only when the step is ready or in progress');
  if (!s.inputs[idx - 1]) fail(404, 'Input not found');
  if (body.confirmed) {
    db.prepare('INSERT OR REPLACE INTO pinputs(product_id,step_no,idx,at,by) VALUES(?,?,?,?,?)').run(pid, no, idx, now(), user.full_name || user.username);
    logEvent(pid, no, user, 'input.confirm', `Input ${idx} received and confirmed`);
  } else {
    guardRelease(pid, s, user);
    db.prepare('DELETE FROM pinputs WHERE product_id=? AND step_no=? AND idx=?').run(pid, no, idx);
    logEvent(pid, no, user, 'input.unconfirm', `Input ${idx} confirmation removed`);
  }
  afterChange(pid, user);
  return { ok: true };
});

route('POST', '/api/products/:id/steps/:no/outputs/:idx', ({ user, params, body }) => {
  const pid = Number(params.id); const no = Number(params.no); const idx = Number(params.idx);
  requireEdit(user, no);
  const c = compute(pid); const s = c.steps.get(no);
  if (s.state !== 'in_progress') fail(400, s.state === 'ready' ? 'Start the step before confirming outputs' : `Outputs cannot be changed (step is ${s.state})`);
  const o = s.outputs[idx - 1]; if (!o) fail(404, 'Output not found');
  const who = user.full_name || user.username;
  // outputs of multi-accountable steps are checked by their own accountable department(s)
  const so = (o.def.signoff || []).filter(Boolean);
  const mine = so.length ? (user.role === 'admin' ? so : so.filter((d) => d === user.dept)) : [];
  if (so.length && !mine.length) fail(403, `Output ${idx} must be checked by ${so.map(deptName).join(' and ')}.`);
  const ck = (o.def.checkers || []).filter(Boolean);
  if (ck.length && user.role !== 'admin' && !ck.includes(user.dept)) fail(403, `Output ${idx} is checked by ${ck.map(deptName).join(' or ')} (final accountability).`);
  if (body.state === 'done') {
    // System-Upload is mandatory: the output's file(s) and/or message — and its SOP-controlled documents — must be in the app
    const problem = evidenceProblem(o, evidenceState(pid, no, idx, stepEvidence(pid, no), outputDocs(no)), user.role === 'admin' ? [] : mine, user.role === 'admin', fileRequired(no, idx));
    if (problem) fail(400, problem);
  }
  const handoff = () => {
    const to = (o.def.to || []).filter((x) => x !== no);
    const depts = [...new Set([...recipients(o.def, pid), ...to.flatMap((x) => ownerDepts(curDef(x)))])].filter((d) => d !== user.dept);
    notify(depts, { product_id: pid, step_no: no, type: 'handoff', title: `${to.length ? `Hand-off from step ${no} → step ${to.join(', ')}` : `Step ${no} output ${idx} delivered`} — ${c.product.name}`, body: `Output ${idx} delivered by ${deptName(user.dept)}: ${o.def.t}${to.length ? `\nThe System-Upload (files and messages) is available in the input of step ${to.join(', ')}.` : ''}`, from_user: who, from_dept: user.dept });
  };
  const late = o.due && today() > o.due ? ` (${diffDays(o.due, today())} day(s) after deadline ${o.due})` : '';
  if (body.state === 'done' && so.length) {
    const insS = db.prepare('INSERT OR REPLACE INTO poutput_signs(product_id,step_no,idx,dept,at,by) VALUES(?,?,?,?,?,?)');
    mine.forEach((d) => insS.run(pid, no, idx, d, now(), who));
    const signed = db.prepare('SELECT dept, by FROM poutput_signs WHERE product_id=? AND step_no=? AND idx=?').all(pid, no, idx);
    const done = so.every((d) => signed.some((x) => x.dept === d));
    logEvent(pid, no, user, 'output.sign', `Output ${idx} checked by ${mine.map(deptName).join(' and ')}${late}`);
    if (done) {
      db.prepare('INSERT OR REPLACE INTO poutputs(product_id,step_no,idx,state,at,by,reason) VALUES(?,?,?,?,?,?,NULL)').run(pid, no, idx, 'done', now(), [...new Set(signed.map((x) => x.by))].join(' & '));
      handoff();
    } else {
      const waiting = so.filter((d) => !signed.some((x) => x.dept === d));
      notify(waiting, { product_id: pid, step_no: no, type: 'update', title: `Your check is needed — step ${no}, output ${idx} — ${c.product.name}`, body: `${deptName(user.dept)} checked output ${idx}. It is complete once ${waiting.map(deptName).join(' and ')} also check it.`, from_user: who, from_dept: user.dept });
    }
  } else if (body.state === 'done' || body.state === 'na') {
    if (body.state === 'na' && !str(body.reason)) fail(400, 'A reason is required');
    db.prepare('INSERT OR REPLACE INTO poutputs(product_id,step_no,idx,state,at,by,reason) VALUES(?,?,?,?,?,?,?)').run(pid, no, idx, body.state, now(), who, str(body.reason) || null);
    logEvent(pid, no, user, body.state === 'done' ? 'output.done' : 'output.na', `Output ${idx} ${body.state === 'done' ? 'delivered' : 'marked not applicable: ' + str(body.reason)}${late}`);
    if (body.state === 'done') handoff();
  } else {
    if (!o.def.defer) guardRelease(pid, s, user);
    if (so.length) { const del = db.prepare('DELETE FROM poutput_signs WHERE product_id=? AND step_no=? AND idx=? AND dept=?'); mine.forEach((d) => del.run(pid, no, idx, d)); }
    db.prepare('DELETE FROM poutputs WHERE product_id=? AND step_no=? AND idx=?').run(pid, no, idx);
    logEvent(pid, no, user, 'output.reopen', `Output ${idx} un-ticked${so.length ? ` (${mine.map(deptName).join(', ')} check removed)` : ''}`);
  }
  afterChange(pid, user);
  return { ok: true };
});

// a step "released" to its next steps (only long-running outputs pending) cannot be pulled back once a next step has started
function guardRelease(pid, s, user) {
  if (!s.released || isExec(user)) return;
  const st = compute(pid).steps;
  const started = stepNos().filter((n) => (curDef(n).deps || []).includes(s.no) && st.get(n) && st.get(n).started_at);
  if (started.length) fail(400, `Step ${started.join(', ')} already started on the basis of this step. Ask the Plant Manager or an executive to make this change.`);
}

// ---- notes
route('POST', '/api/products/:id/steps/:no/notes', ({ user, params, body }) => {
  const pid = Number(params.id); const no = Number(params.no);
  if (stepLevel(user, no) === 'none') fail(403, 'Not allowed');
  const text = str(body.text, 5000); if (!text) fail(400, 'Note is empty');
  const toSteps = Array.isArray(body.to_steps) ? body.to_steps.map(Number).filter(Boolean) : dependents(no);
  const toDepts = Array.isArray(body.to_depts) && body.to_depts.length ? body.to_depts : [...new Set(toSteps.flatMap((d) => ownerDepts(curDef(d))))];
  db.prepare('INSERT INTO notes(product_id,step_no,text,dept,username,full_name,created_at,to_depts,to_steps) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(pid, no, text, user.dept, user.username, user.full_name, now(), JSON.stringify(toDepts), JSON.stringify(toSteps));
  const p = getProduct(pid);
  notify(toDepts.filter((d) => d !== user.dept), { product_id: pid, step_no: no, type: 'note', title: `Note from ${deptName(user.dept)} on step ${no} — ${p.name}`, body: text, from_user: user.full_name || user.username, from_dept: user.dept });
  logEvent(pid, no, user, 'note', text.slice(0, 300));
  bump(pid); broadcast({ t: 'product', id: pid });
  return { ok: true };
});

// ---- risk findings
route('POST', '/api/products/:id/risks', ({ user, body, params }) => {
  const pid = Number(params.id); const no = body.step_no ? Number(body.step_no) : null;
  if (no && stepLevel(user, no) === 'none') fail(403, 'Not allowed');
  const title = str(body.title, 1000); if (!title) fail(400, 'Describe the risk finding');
  const sev = ['Critical', 'Major', 'Minor'].includes(body.severity) ? body.severity : 'Critical';
  db.prepare('INSERT INTO risks(product_id,step_no,severity,title,action,owner_dept,raised_by,raised_dept,raised_at) VALUES(?,?,?,?,?,?,?,?,?)')
    .run(pid, no, sev, title, str(body.action, 2000), str(body.owner_dept, 20) || null, user.full_name || user.username, user.dept, now());
  const p = getProduct(pid);
  logEvent(pid, no, user, 'risk.raise', `${sev} risk finding: ${title}`);
  notify([body.owner_dept, 'PM', 'BD', ...(no ? ownerDepts(curDef(no)) : [])], { product_id: pid, step_no: no, type: 'risk', title: `${sev} risk finding — ${p.name}${no ? ` (step ${no})` : ''}`, body: `${title}${body.action ? ` · Action needed: ${body.action}` : ''}`, from_user: user.full_name || user.username, from_dept: user.dept });
  bump(pid); broadcast({ t: 'product', id: pid });
  return { ok: true };
});
route('PUT', '/api/risks/:id', ({ user, params, body }) => {
  const r = db.prepare('SELECT * FROM risks WHERE id=?').get(params.id); if (!r) fail(404, 'Not found');
  if (!isExec(user) && user.dept !== r.owner_dept && user.dept !== r.raised_dept && !(r.step_no && stepLevel(user, r.step_no) === 'edit')) fail(403, 'Not allowed');
  if (body.status === 'closed') {
    db.prepare("UPDATE risks SET status='closed', closed_at=?, closed_by=?, close_note=? WHERE id=?").run(now(), user.full_name || user.username, str(body.close_note, 2000), r.id);
    logEvent(r.product_id, r.step_no, user, 'risk.close', `Risk finding closed: ${r.title}${body.close_note ? ` — ${body.close_note}` : ''}`);
  } else if (body.status === 'open') {
    db.prepare("UPDATE risks SET status='open', closed_at=NULL, closed_by=NULL WHERE id=?").run(r.id);
  }
  bump(r.product_id); broadcast({ t: 'product', id: r.product_id });
  return { ok: true };
});

// ---- System-Upload on an output: notify the receiving departments
function announceUpload(pid, no, outIdx, user, what) {
  const c = compute(pid); const s = c && c.steps.get(no); if (!s) return;
  const o = outIdx ? s.outputs[outIdx - 1] : null;
  const depts = o ? recipients(o.def, pid) : [...dependents(no).flatMap((d) => ownerDepts(curDef(d))), ...ownerDepts(s.def)];
  notify(depts.filter((d) => d !== user.dept), {
    product_id: pid, step_no: no, type: 'upload',
    title: `System-Upload from ${deptName(user.dept)} — step ${no}${o ? `, output ${outIdx}` : ''} — ${c.product.name}`,
    body: `${what}${o ? `\nOutput ${outIdx}: ${o.def.t}` : ''}`, from_user: user.full_name || user.username, from_dept: user.dept,
  });
}

// short text message on an output (replaces the e-mail between departments)
route('POST', '/api/products/:id/steps/:no/outputs/:idx/messages', ({ user, params, body }) => {
  const pid = Number(params.id); const no = Number(params.no); const idx = Number(params.idx);
  const c = compute(pid); if (!c) fail(404, 'Product not found');
  const s = c.steps.get(no); if (!s) fail(404, 'Step not found');
  if (!s.outputs[idx - 1]) fail(404, 'Output not found');
  if (stepLevel(user, no) !== 'edit') fail(403, `You need editor rights on step ${no} to send a System-Upload message`);
  if (s.state === 'waiting') fail(400, 'This step is still waiting for the steps it depends on');
  fillGuard(user, s.outputs[idx - 1].def, idx);
  const text = str(body.text, 4000); if (!text) fail(400, 'The message is empty');
  db.prepare('INSERT INTO messages(product_id,step_no,output_idx,text,dept,username,full_name,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(pid, no, idx, text, user.dept, user.username, user.full_name, now());
  logEvent(pid, no, user, 'message', `System-Upload message on output ${idx}: ${text.slice(0, 300)}`);
  announceUpload(pid, no, idx, user, `Message: ${text}`);
  bump(pid); broadcast({ t: 'product', id: pid });
  return { ok: true };
});

// ---- documents / files (stored on disk under data/files, streamed in and out)
route('POST', '/api/upload', async ({ user, query, req }) => {
  const pid = Number(query.product); const no = Number(query.step) || null;
  const p = getProduct(pid); if (!p) fail(404, 'Product not found');
  if (!no) fail(400, 'Step is required');
  if (stepLevel(user, no) !== 'edit') fail(403, `You need editor rights on step ${no} to upload`);
  const name = str(query.name, 255) || 'document';
  const limit = Number(S.get('upload_max_mb', 200)) * 1048576;
  const docType = query.doctype ? db.prepare('SELECT * FROM doc_types WHERE id=?').get(Number(query.doctype)) : null;
  if (query.doctype && !docType) fail(404, 'Document type not found');
  // an SOP-controlled document uploaded at its required step belongs to its output
  let outIdx = query.output ? Number(query.output) : null;
  if (docType && !outIdx && docType.required_step === no && docType.required_output) outIdx = docType.required_output;
  if (outIdx) { const so = compute(pid).steps.get(no); const od = so && so.outputs[outIdx - 1]; if (od) fillGuard(user, od.def, outIdx); }
  const rel = DB.newFilePath(DATA_DIR, pid, name);
  const { size, sha256 } = await receiveFile(req, path.join(DATA_DIR, rel), limit);
  if (!size) { fs.unlink(path.join(DATA_DIR, rel), () => {}); fail(400, 'Empty file'); }
  let version;
  if (docType) version = (db.prepare('SELECT MAX(version) v FROM files WHERE product_id=? AND doc_type_id=?').get(pid, docType.id).v || 0) + 1;
  else version = (db.prepare('SELECT MAX(version) v FROM files WHERE product_id=? AND step_no=? AND output_idx IS ? AND doc_type_id IS NULL AND filename=?').get(pid, no, outIdx, name).v || 0) + 1;
  const mime = str(req.headers['content-type'], 100) || 'application/octet-stream';
  const r = db.prepare('INSERT INTO files(product_id,step_no,output_idx,doc_type_id,version,kind,filename,mime,size,path,sha256,dept,username,full_name,uploaded_at,comment) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(pid, no, outIdx, docType ? docType.id : null, version, docType ? 'controlled' : 'evidence', name, mime, size, rel, sha256, user.dept, user.username, user.full_name, now(), str(query.comment, 500) || null);
  const label = docType ? docType.name : `output ${outIdx || '-'} file "${name}"`;
  logEvent(pid, no, user, 'file.upload', `Uploaded ${label} — version ${version} (${name}, ${Math.round(size / 1024)} KB)`);
  announceUpload(pid, no, outIdx, user, `${docType ? 'SOP-controlled document' : 'File'}: ${docType ? docType.name : name} · v${version}${query.comment ? ` — ${str(query.comment, 500)}` : ''}`);
  bump(pid); broadcast({ t: 'product', id: pid });
  return { ok: true, id: Number(r.lastInsertRowid), version };
});
route('POST', '/api/products/:id/steps/:no/links', ({ user, params, body }) => {
  const pid = Number(params.id); const no = Number(params.no);
  if (stepLevel(user, no) !== 'edit') fail(403, `You need editor rights on step ${no}`);
  const url = str(body.url, 2000); if (!url) fail(400, 'Link is empty');
  const outIdx = body.output ? Number(body.output) : null;
  if (outIdx) { const so = compute(pid).steps.get(no); const od = so && so.outputs[outIdx - 1]; if (od) fillGuard(user, od.def, outIdx); }
  const version = (db.prepare("SELECT MAX(version) v FROM files WHERE product_id=? AND step_no=? AND output_idx IS ? AND kind='link'").get(pid, no, outIdx).v || 0) + 1;
  db.prepare("INSERT INTO files(product_id,step_no,output_idx,version,kind,url,label,filename,dept,username,full_name,uploaded_at) VALUES(?,?,?,?,'link',?,?,?,?,?,?,?)")
    .run(pid, no, outIdx, version, url, str(body.label, 200) || null, url, user.dept, user.username, user.full_name, now());
  logEvent(pid, no, user, 'link.add', `Added link for output ${outIdx || '-'}: ${url}`);
  announceUpload(pid, no, outIdx, user, `Link: ${url}`);
  bump(pid); broadcast({ t: 'product', id: pid });
  return { ok: true };
});
route('GET', '/api/files/:id', ({ params, query, res, user }) => {
  const f = db.prepare('SELECT id,product_id,step_no,kind,url,filename,mime,size,path,data FROM files WHERE id=?').get(params.id); if (!f) fail(404, 'File not found');
  if (f.step_no && stepLevel(user, f.step_no) === 'none') fail(403, 'You have no access to this step');
  if (f.kind === 'link') { res.writeHead(302, { Location: f.url }); res.end(); return null; }
  const inline = query.download ? 'attachment' : 'inline';
  const head = { 'Content-Type': f.mime || 'application/octet-stream', 'Content-Disposition': contentDisposition(inline, f.filename), 'Cache-Control': 'private, max-age=3600', 'X-Content-Type-Options': 'nosniff' };
  if (f.path) {
    const abs = path.join(DATA_DIR, f.path);
    let st; try { st = fs.statSync(abs); } catch { fail(404, 'The file is missing on the server (data/files). Restore it from the backup.'); }
    res.writeHead(200, { ...head, 'Content-Length': st.size });
    pipeline(fs.createReadStream(abs), res, () => {});
    return null;
  }
  const buf = toBuf(f.data);
  res.writeHead(200, { ...head, 'Content-Length': buf.length });
  res.end(buf);
  return null;
});
route('DELETE', '/api/files/:id', ({ user, params }) => {
  if (user.role !== 'admin') fail(403, 'Uploaded documents can only be deleted by the administrator');
  const f = db.prepare('SELECT id,product_id,step_no,filename,version,doc_type_id,path FROM files WHERE id=?').get(params.id); if (!f) fail(404, 'Not found');
  db.prepare('DELETE FROM files WHERE id=?').run(f.id);
  if (f.path) fs.unlink(path.join(DATA_DIR, f.path), () => {});
  logEvent(f.product_id, f.step_no, user, 'file.delete', `Administrator deleted ${f.filename} (v${f.version})`);
  bump(f.product_id); broadcast({ t: 'product', id: f.product_id });
  return { ok: true };
});

// paged, searchable, sortable document list (one product or all products) — sorting and filtering run in the database
const DOC_SORT = {
  step: 'f.step_no {d}, f.output_idx {d}, COALESCE(d.sort, 999), f.doc_type_id, f.version DESC, f.id DESC',
  name: 'LOWER(COALESCE(d.name, f.filename)) {d}, f.version DESC',
  dept: 'f.dept {d}, f.step_no, f.output_idx',
  user: 'LOWER(COALESCE(f.full_name, f.username)) {d}, f.uploaded_at DESC',
  date: 'f.uploaded_at {d}, f.id {d}',
  version: 'f.version {d}, f.step_no',
  product: 'LOWER(p.name) {d}, f.step_no, f.output_idx',
  size: 'f.size {d}',
};
function documentList(query, user) {
  const where = []; const args = [];
  const inner = query.product ? 'WHERE f.product_id=?' : '';
  if (query.product) args.push(Number(query.product));
  if (query.doctype) { where.push('f.doc_type_id=?'); args.push(Number(query.doctype)); }
  if (query.kind === 'controlled') where.push('f.doc_type_id IS NOT NULL');
  else if (query.kind === 'evidence') where.push("f.doc_type_id IS NULL AND f.kind<>'link'");
  else if (query.kind === 'link') where.push("f.kind='link'");
  if (query.dept) { where.push('f.dept=?'); args.push(str(query.dept, 20)); }
  if (query.step) { where.push('f.step_no=?'); args.push(Number(query.step)); }
  const q = str(query.q, 200);
  if (/^\d+$/.test(q)) { where.push('f.step_no=?'); args.push(Number(q)); } // a plain number = step number
  else if (q) {
    const like = `%${q.replace(/[%_]/g, (m) => `\\${m}`)}%`;
    const prodSearch = query.product ? '' : " OR COALESCE(p.name,'') LIKE ? ESCAPE '\\'";
    where.push(`(COALESCE(d.name,'') LIKE ? ESCAPE '\\' OR COALESCE(f.filename,'') LIKE ? ESCAPE '\\' OR COALESCE(f.full_name,'') LIKE ? ESCAPE '\\' OR COALESCE(f.username,'') LIKE ? ESCAPE '\\' OR COALESCE(f.dept,'') LIKE ? ESCAPE '\\' OR COALESCE(f.comment,'') LIKE ? ESCAPE '\\'${prodSearch} OR ('v'||f.version)=LOWER(?) OR ('step '||f.step_no)=LOWER(?))`);
    args.push(like, like, like, like, like, like, ...(query.product ? [] : [like]), q, q);
  }
  const latest = query.latest === '1';
  const base = `FROM (SELECT f.*, ROW_NUMBER() OVER (PARTITION BY f.product_id, CASE WHEN f.doc_type_id IS NOT NULL THEN 'd' || f.doc_type_id ELSE 'e' || IFNULL(f.step_no,'') || '.' || IFNULL(f.output_idx,'') || '.' || IFNULL(f.filename,'') END ORDER BY f.version DESC, f.id DESC) rn FROM files f ${inner}) f
    JOIN products p ON p.id=f.product_id LEFT JOIN doc_types d ON d.id=f.doc_type_id
    WHERE ${[latest ? 'f.rn=1' : '1=1', ...where].join(' AND ')}`;
  const dir = query.dir === 'desc' ? 'DESC' : 'ASC';
  const order = (DOC_SORT[query.sort] || DOC_SORT.step).replace(/\{d\}/g, dir);
  const size = Math.max(10, Math.min(200, Number(query.size) || 50));
  const total = db.prepare(`SELECT COUNT(*) n ${base}`).get(...args).n;
  const page = Math.max(1, Math.min(Math.ceil(total / size) || 1, Number(query.page) || 1));
  let rows = db.prepare(`SELECT f.id,f.product_id,p.name product,f.step_no,f.output_idx,f.doc_type_id,d.name doc_name,d.section,f.version,f.kind,f.filename,f.mime,f.size,f.url,f.dept,f.username,f.full_name,f.uploaded_at,f.comment,f.sha256,f.rn=1 latest ${base} ORDER BY ${order} LIMIT ? OFFSET ?`).all(...args, size, (page - 1) * size);
  if (user) rows = rows.map((r) => (r.step_no && stepLevel(user, r.step_no) === 'none' ? { ...r, restricted: true, filename: '— restricted —', url: null } : r));
  return { total, page, size, pages: Math.max(1, Math.ceil(total / size)), rows };
}
route('GET', '/api/documents', ({ query, user }) => documentList(query, user));
route('GET', '/api/products/:id/documents', ({ params, query, user }) => {
  const pid = Number(params.id); if (!getProduct(pid)) fail(404, 'Product not found');
  const out = documentList({ ...query, product: pid }, user);
  // SOP-controlled documents that are still missing, in SOP step order
  if (query.missing === '1' && (!query.kind || query.kind === 'controlled') && !query.dept && !query.q) {
    const have = new Set(db.prepare('SELECT DISTINCT doc_type_id FROM files WHERE product_id=? AND doc_type_id IS NOT NULL').all(pid).map((r) => r.doc_type_id));
    out.missing = db.prepare('SELECT id,section,name,steps,required_step,required_output FROM doc_types WHERE active=1 ORDER BY sort,id').all()
      .filter((d) => !have.has(d.id)).map((d) => ({ doc_type_id: d.id, section: d.section, name: d.name, step_no: d.required_step || JSON.parse(d.steps)[0] || null, output_idx: d.required_output, steps: JSON.parse(d.steps) }))
      .sort((a, b) => (a.step_no || 999) - (b.step_no || 999) || (a.output_idx || 0) - (b.output_idx || 0));
  }
  out.counts = db.prepare("SELECT COUNT(*) n, SUM(doc_type_id IS NOT NULL) controlled, SUM(doc_type_id IS NULL AND kind<>'link') evidence, SUM(kind='link') links, COUNT(DISTINCT dept) depts FROM files WHERE product_id=?").get(pid);
  out.depts = db.prepare('SELECT DISTINCT dept FROM files WHERE product_id=? ORDER BY dept').all(pid).map((r) => r.dept);
  return out;
});

// ---- notifications
// ---- Product documents (Project flow): every SOP-controlled document of the product, uploaded or not, in SOP step order
route('GET', '/api/products/:id/sopdocs', ({ params, query, user }) => {
  const pid = Number(params.id); if (!getProduct(pid)) fail(404, 'Product not found');
  const types = db.prepare('SELECT id,section,name,steps,required_step,required_output,sort FROM doc_types WHERE active=1 ORDER BY sort,id').all();
  const files = db.prepare('SELECT id,doc_type_id,step_no,output_idx,version,filename,mime,size,dept,username,full_name,uploaded_at,comment,sha256 FROM files WHERE product_id=? AND doc_type_id IS NOT NULL ORDER BY version DESC, id DESC').all(pid);
  const latest = query.latest !== '0';
  let rows = [];
  for (const t of types) {
    const steps = JSON.parse(t.steps);
    const step = t.required_step || steps[0] || null;
    const base = { doc_type_id: t.id, doc_name: t.name, section: t.section, sort: t.sort, req_step: step, req_output: t.required_output, steps };
    const vs = files.filter((f) => f.doc_type_id === t.id);
    if (!vs.length) rows.push({ ...base, uploaded: false, step_no: step, output_idx: t.required_output });
    else (latest ? vs.slice(0, 1) : vs).forEach((f, i) => rows.push({ ...base, uploaded: true, latest: i === 0, versions: vs.length, ...f, restricted: f.step_no && stepLevel(user, f.step_no) === 'none' }));
  }
  const counts = { types: types.length, uploaded: new Set(files.map((f) => f.doc_type_id)).size };
  counts.missing = counts.types - counts.uploaded;
  if (query.status === 'uploaded') rows = rows.filter((r) => r.uploaded);
  if (query.status === 'missing') rows = rows.filter((r) => !r.uploaded);
  if (query.section) rows = rows.filter((r) => r.section === query.section);
  const q = String(query.q || '').trim().toLowerCase();
  if (/^\d+$/.test(q)) rows = rows.filter((r) => r.step_no === Number(q) || r.steps.includes(Number(q)));
  else if (q) rows = rows.filter((r) => [r.doc_name, r.section, r.filename, r.full_name, r.username, r.dept && deptName(r.dept), r.comment, r.version && `v${r.version}`, `step ${r.step_no}`].some((x) => x && String(x).toLowerCase().includes(q)));
  const dir = query.dir === 'desc' ? -1 : 1;
  const nz = (v) => (v === null || v === undefined || v === '' ? null : v);
  const key = {
    step: (r) => [r.step_no || 999, r.output_idx || 0, r.sort, -(r.version || 0)],
    name: (r) => [String(r.doc_name).toLowerCase()],
    version: (r) => [nz(r.version)],
    dept: (r) => [nz(r.dept && deptName(r.dept))],
    user: (r) => [nz(r.full_name || r.username)],
    date: (r) => [nz(r.uploaded_at)],
    section: (r) => [r.section, r.step_no || 999],
  }[query.sort] || ((r) => [r.step_no || 999, r.output_idx || 0, r.sort]);
  rows.sort((a, b) => {
    const ka = key(a); const kb = key(b);
    for (let i = 0; i < ka.length; i++) {
      if (ka[i] === kb[i]) continue;
      if (ka[i] === null) return 1; if (kb[i] === null) return -1; // empty values (not uploaded) always last
      return (ka[i] < kb[i] ? -1 : 1) * dir;
    }
    return a.sort - b.sort;
  });
  return { rows, counts, sections: [...new Set(types.map((t) => t.section))] };
});

// ---- Settings → Upload rules: make a file upload mandatory for an output (a message alone is then refused)
route('GET', '/api/admin/output-rules', ({ user }) => {
  if (!isExec(user)) fail(403, 'Executives only');
  const rules = db.prepare('SELECT step_no, output_idx, file_required, updated_by, updated_at FROM output_rules WHERE file_required=1').all();
  const docs = db.prepare('SELECT name, required_step, required_output FROM doc_types WHERE active=1 AND required_step IS NOT NULL AND required_output IS NOT NULL').all();
  const steps = stepNos().map((no) => { const d = curDef(no); return { no, name: d.name, outputs: (d.outputs || []).map((o, i) => ({ idx: i + 1, t: o.t, group: o.group || null, dept: o.dept, docs: docs.filter((x) => x.required_step === no && x.required_output === i + 1).map((x) => x.name) })) }; });
  return { rules, steps };
});
route('PUT', '/api/admin/output-rules', ({ user, body }) => {
  if (user.role !== 'admin') fail(403, 'Administrator only');
  const no = Number(body.step_no); const idx = Number(body.output_idx);
  if (!(curDef(no).outputs || [])[idx - 1]) fail(404, `Step ${no} has no output ${idx}`);
  db.prepare('INSERT INTO output_rules(step_no,output_idx,file_required,updated_by,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(step_no,output_idx) DO UPDATE SET file_required=excluded.file_required, updated_by=excluded.updated_by, updated_at=excluded.updated_at')
    .run(no, idx, body.file_required ? 1 : 0, user.full_name || user.username, now());
  logEvent(null, no, user, 'rule.file', `Step ${no} output ${idx}: file upload ${body.file_required ? 'mandatory' : 'no longer mandatory'}`);
  bump(); broadcast({ t: 'all' });
  return { ok: true };
});

// ---- Announcements: administrator, Business Development and Plant Manager → selected departments
const canAnnounce = (u) => u.role === 'admin' || canDash(u);
route('POST', '/api/announcements/upload', async ({ user, query, req }) => {
  if (!canAnnounce(user)) fail(403, 'Only the administrator, Business Development and the Plant Manager can send announcements');
  const name = str(query.name, 255) || 'attachment';
  const rel = DB.newFilePath(DATA_DIR, 'announcements', name);
  const { size, sha256 } = await receiveFile(req, path.join(DATA_DIR, rel), Number(S.get('upload_max_mb', 200)) * 1048576);
  if (!size) { fs.unlink(path.join(DATA_DIR, rel), () => {}); fail(400, 'Empty file'); }
  const r = db.prepare('INSERT INTO ann_files(announcement_id,filename,mime,size,path,sha256,username,uploaded_at) VALUES(NULL,?,?,?,?,?,?,?)')
    .run(name, str(req.headers['content-type'], 100) || 'application/octet-stream', size, rel, sha256, user.username, now());
  return { ok: true, id: Number(r.lastInsertRowid), name, size };
});
route('POST', '/api/announcements', ({ user, body }) => {
  if (!canAnnounce(user)) fail(403, 'Only the administrator, Business Development and the Plant Manager can send announcements');
  const all = db.prepare("SELECT code FROM departments WHERE active=1 AND code<>'ADM'").all().map((d) => d.code);
  const depts = body.depts === '*' ? all : [...new Set((body.depts || []).map(String))].filter((d) => all.includes(d));
  if (!depts.length) fail(400, 'Choose at least one department');
  const text = str(body.text, 8000); if (!text) fail(400, 'The message is empty');
  const pid = body.product_id ? Number(body.product_id) : null;
  const p = pid ? getProduct(pid) : null; if (pid && !p) fail(404, 'Product not found');
  const subject = str(body.subject, 200) || null;
  const r = db.prepare('INSERT INTO announcements(product_id,depts,subject,text,dept,username,full_name,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(pid, JSON.stringify(depts), subject, text, user.dept, user.username, user.full_name, now());
  const id = Number(r.lastInsertRowid);
  const link = db.prepare('UPDATE ann_files SET announcement_id=? WHERE id=? AND announcement_id IS NULL AND username=?');
  (body.files || []).forEach((f) => link.run(id, Number(f), user.username));
  const nf = db.prepare('SELECT COUNT(*) n FROM ann_files WHERE announcement_id=?').get(id).n;
  notify(depts, {
    product_id: pid, type: 'announce', ann_id: id,
    title: `Announcement${subject ? `: ${subject}` : ''} — ${p ? p.name : 'all products'}`,
    body: text + (nf ? `\n(${nf} attachment${nf > 1 ? 's' : ''})` : ''),
    from_user: user.full_name || user.username, from_dept: user.dept,
  });
  logEvent(pid, null, user, 'announcement', `Announcement to ${depts.length === all.length ? 'all departments' : depts.map(deptName).join(', ')}: ${subject || text.slice(0, 120)}`);
  return { ok: true, id };
});
route('GET', '/api/announcements', ({ user, query }) => {
  if (!canAnnounce(user)) fail(403, 'Not allowed');
  const lim = Math.max(20, Math.min(Number(query.limit) || 50, 500));
  const rows = db.prepare('SELECT a.*, p.name product FROM announcements a LEFT JOIN products p ON p.id=a.product_id ORDER BY a.id DESC LIMIT ?').all(lim);
  const files = rows.length ? db.prepare(`SELECT id,announcement_id,filename,size FROM ann_files WHERE announcement_id IN (${rows.map(() => '?').join(',')})`).all(...rows.map((r) => r.id)) : [];
  return { rows: rows.map((r) => ({ ...r, depts: JSON.parse(r.depts), files: files.filter((f) => f.announcement_id === r.id) })), total: db.prepare('SELECT COUNT(*) n FROM announcements').get().n };
});
route('GET', '/api/announcements/files/:id', ({ user, params, query, res }) => {
  const f = db.prepare('SELECT f.*, a.depts FROM ann_files f LEFT JOIN announcements a ON a.id=f.announcement_id WHERE f.id=?').get(params.id);
  if (!f) fail(404, 'File not found');
  const allowed = canAnnounce(user) || (f.depts && JSON.parse(f.depts).includes(user.dept));
  if (!allowed) fail(403, 'This attachment was not sent to your department');
  const abs = path.join(DATA_DIR, f.path);
  let st; try { st = fs.statSync(abs); } catch { fail(404, 'The file is missing on the server (data/files).'); }
  res.writeHead(200, { 'Content-Type': f.mime || 'application/octet-stream', 'Content-Length': st.size, 'Content-Disposition': contentDisposition(query.download ? 'attachment' : 'inline', f.filename), 'Cache-Control': 'private, max-age=3600', 'X-Content-Type-Options': 'nosniff' });
  pipeline(fs.createReadStream(abs), res, () => {});
  return null;
});

// paged: filters, search and counts are computed in the database (fast with tens of thousands of notifications)
route('GET', '/api/notifications', ({ user, query }) => {
  const dept = (isExec(user) && query.dept) ? query.dept : user.dept;
  const lim = Math.max(20, Math.min(Number(query.limit) || 100, 500));
  const off = Math.max(0, Number(query.offset) || 0);
  const base = []; const bargs = [];
  if (dept !== '*') { base.push('n.dept=?'); bargs.push(dept); }
  const unreadSql = 'NOT EXISTS (SELECT 1 FROM notif_reads r WHERE r.user_id=? AND r.notif_id=n.id)';
  const w = [...base]; const args = [...bargs];
  if (query.type) { w.push('n.type=?'); args.push(str(query.type, 20)); }
  if (query.unread === '1') { w.push(unreadSql); args.push(user.id); }
  const q = str(query.q, 200);
  if (q) { const like = `%${q.replace(/[%_]/g, (m) => `\\${m}`)}%`; w.push("(n.title LIKE ? ESCAPE '\\' OR n.body LIKE ? ESCAPE '\\' OR COALESCE(n.from_user,'') LIKE ? ESCAPE '\\' OR COALESCE(p.name,'') LIKE ? ESCAPE '\\')"); args.push(like, like, like, like); }
  const W = (list) => (list.length ? `WHERE ${list.join(' AND ')}` : '');
  const rows = db.prepare(`SELECT n.*, p.name product, NOT ${unreadSql} is_read FROM notifications n LEFT JOIN products p ON p.id=n.product_id ${W(w)} ORDER BY n.id DESC LIMIT ? OFFSET ?`).all(user.id, ...args, lim, off);
  const total = db.prepare(`SELECT COUNT(*) n FROM notifications n LEFT JOIN products p ON p.id=n.product_id ${W(w)}`).get(...args).n;
  const counts = Object.fromEntries(db.prepare(`SELECT n.type, COUNT(*) c FROM notifications n ${W(base)} GROUP BY n.type`).all(...bargs).map((r) => [r.type, r.c]));
  const all = db.prepare(`SELECT COUNT(*) c FROM notifications n ${W(base)}`).get(...bargs).c;
  const unread = db.prepare(`SELECT COUNT(*) c FROM notifications n ${W([...base, unreadSql])}`).get(...bargs, user.id).c;
  const annIds = [...new Set(rows.map((r) => r.ann_id).filter(Boolean))];
  const af = annIds.length ? db.prepare(`SELECT id,announcement_id,filename,size FROM ann_files WHERE announcement_id IN (${annIds.map(() => '?').join(',')})`).all(...annIds) : [];
  rows.forEach((r) => { if (r.ann_id) r.files = af.filter((f) => f.announcement_id === r.ann_id); });
  return { rows, total, all, counts, unread, offset: off, limit: lim };
});
// a notification stays unread until the user checks it as read (opening it does not mark it read)
route('POST', '/api/notifications/read', ({ user, body }) => {
  const ins = db.prepare('INSERT OR IGNORE INTO notif_reads(user_id,notif_id) VALUES(?,?)');
  const del = db.prepare('DELETE FROM notif_reads WHERE user_id=? AND notif_id=?');
  if (body.all) db.prepare('INSERT OR IGNORE INTO notif_reads(user_id,notif_id) SELECT ?, id FROM notifications WHERE dept=?').run(user.id, user.dept);
  else (body.ids || []).forEach((id) => (body.read === false ? del.run(user.id, Number(id)) : ins.run(user.id, Number(id))));
  return { ok: true, unread: publicUser(user).unread };
});

// ---- my department
function myDept(dept) {
  const prods = db.prepare("SELECT id FROM products WHERE status!='archived' ORDER BY id").all();
  return prods.map(({ id }) => {
    const c = compute(id); const st = c.steps;
    const mine = [...st.values()].filter((s) => stepDepts(s.def).includes(dept));
    const lite = (s) => ({ no: s.no, name: s.def.name, acc: accText(s.def), accountable: s.def.accountable, state: s.state, due: s.due, fReady: s.fReady, fDue: s.fDue, readyDate: s.readyDate, overdueDays: s.overdueDays, waitWD: s.waitWD, started_at: s.started_at, outputsDone: s.outputsDone, outputsTotal: s.outputs.length, myOutputs: s.outputs.filter((o) => o.def.dept === dept || (o.def.signoff || []).includes(dept)).map((o) => ({ idx: o.idx, t: o.def.t, due: o.due, state: o.state })), dues: dueList(s), released: s.released, deferLabels: s.deferLabels });
    const comingNext = mine.filter((s) => s.state === 'waiting' && s.deps.every((d) => st.get(d).state !== 'waiting'));
    const risks = db.prepare("SELECT * FROM risks WHERE product_id=? AND status='open'").all(id).filter((r) => ['PM', 'BD'].includes(dept) || r.owner_dept === dept || (r.step_no && stepDepts(st.get(r.step_no).def).includes(dept)));
    return {
      product: { id, name: c.product.name },
      overdue: mine.filter((s) => s.overdue).map(lite),
      in_progress: mine.filter((s) => s.state === 'in_progress').map(lite),
      ready: mine.filter((s) => s.state === 'ready').map(lite),
      coming: comingNext.map(lite),
      done: mine.filter((s) => s.state === 'done').length,
      total: mine.length,
      risks,
    };
  });
}
route('GET', '/api/mydept', ({ user, query }) => {
  const dept = (isExec(user) && query.dept) ? query.dept : user.dept;
  return { dept, dept_name: deptName(dept), products: myDept(dept) };
});

// ---- analytics
function monthsBack(month, n) {
  const [y, m] = month.split('-').map(Number); const out = [];
  for (let i = n - 1; i >= 0; i--) { const d = new Date(Date.UTC(y, m - 1 - i, 1)); out.push(d.toISOString().slice(0, 7)); }
  return out;
}
function analytics(month) {
  const months = monthsBack(month, 6);
  const depts = DEPTS().filter((d) => d.code !== 'ADM');
  const blank = () => ({ completed: 0, onTime: 0, products: new Set(), overdue: 0, overdueList: [], waits: [], notStarted: 0, notStartedList: [], outDone: 0, outOnTime: 0 });
  const M = {}; months.forEach((m) => { M[m] = {}; depts.forEach((d) => { M[m][d.code] = blank(); }); });
  const t = today();
  const prods = db.prepare('SELECT id FROM products').all();
  for (const { id } of prods) {
    const c = compute(id);
    for (const s of c.steps.values()) {
      if (s.state === 'na') continue;
      for (const d of s.def.accountable || []) {
        for (const m of months) {
          const b = M[m][d]; if (!b) continue;
          if (s.completed_at && s.completed_at.slice(0, 7) === m) { b.completed++; if (s.onTime) { b.onTime++; b.products.add(id); } }
          const late = s.due && ((s.state === 'done' && s.completed_at.slice(0, 10) > s.due) || (!s.closed && t > s.due));
          if (late && s.due.slice(0, 7) === m) { b.overdue++; b.overdueList.push(`${c.product.name} · step ${s.no}`); }
          if (s.readyDate && s.readyDate.slice(0, 7) === m) {
            b.waits.push(s.waitWD || 0);
            if (s.state === 'ready') { b.notStarted++; b.notStartedList.push(`${c.product.name} · step ${s.no} (${s.waitWD} WD)`); }
          }
        }
      }
      for (const o of s.outputs) {
        if (o.state !== 'done' || !o.at) continue;
        const m = o.at.slice(0, 7); const b = M[m] && M[m][o.def.dept]; if (!b) continue;
        b.outDone++; if (!o.due || o.at.slice(0, 10) <= o.due) b.outOnTime++;
      }
    }
  }
  const evals = new Map(db.prepare('SELECT * FROM evaluations WHERE month=?').all(month).map((e) => [e.dept, e]));
  return {
    month, months,
    depts: depts.map((d) => {
      const b = M[month][d.code];
      const rate = b.completed ? Math.round((b.onTime / b.completed) * 100) : null;
      const avgWait = b.waits.length ? Math.round((b.waits.reduce((a, x) => a + x, 0) / b.waits.length) * 10) / 10 : null;
      let auto = 'No completed steps in this month.';
      if (b.completed) auto = rate >= 90 ? 'Excellent — steps delivered within the SOP timeframe.' : rate >= 75 ? 'Good — most steps delivered on time.' : rate >= 50 ? 'Needs improvement — several steps late.' : 'Critical — majority of steps delivered late.';
      if (b.overdue) auto += ` ${b.overdue} step(s) overdue.`;
      if (avgWait != null && avgWait > 2) auto += ` Slow start: average ${avgWait} WD from ready to start.`;
      const e = evals.get(d.code) || {};
      return {
        code: d.code, name: d.name,
        productsOnTime: b.products.size, completed: b.completed, onTime: b.onTime, rate, overdue: b.overdue, overdueList: b.overdueList,
        avgWait, notStarted: b.notStarted, notStartedList: b.notStartedList, outDone: b.outDone, outOnTime: b.outOnTime, auto,
        positives: e.positives || '', negatives: e.negatives || '', conclusion: e.conclusion || '', updated_by: e.updated_by || null, updated_at: e.updated_at || null,
        trend: months.map((m) => { const x = M[m][d.code]; return { month: m, completed: x.completed, onTime: x.onTime, overdue: x.overdue }; }),
      };
    }),
  };
}
route('GET', '/api/analytics', ({ query, user }) => needDash(user) || analytics(/^\d{4}-\d{2}$/.test(query.month || '') ? query.month : today().slice(0, 7)));
route('POST', '/api/evaluations', ({ user, body }) => {
  if (!isExec(user)) fail(403, 'Only Business Development / Plant Manager (executive role) can enter evaluations');
  if (!/^\d{4}-\d{2}$/.test(body.month || '')) fail(400, 'Month required');
  db.prepare(`INSERT INTO evaluations(dept,month,positives,negatives,conclusion,updated_by,updated_at) VALUES(?,?,?,?,?,?,?)
    ON CONFLICT(dept,month) DO UPDATE SET positives=excluded.positives, negatives=excluded.negatives, conclusion=excluded.conclusion, updated_by=excluded.updated_by, updated_at=excluded.updated_at`)
    .run(str(body.dept, 20), body.month, str(body.positives), str(body.negatives), str(body.conclusion), user.full_name || user.username, now());
  notify([body.dept], { type: 'update', title: `Department evaluation updated — ${body.month}`, body: `${user.full_name || user.username} updated the monthly evaluation of ${deptName(body.dept)}.`, from_user: user.full_name || user.username, from_dept: user.dept });
  broadcast({ t: 'analytics' });
  return { ok: true };
});

// ───────────────────────── admin ─────────────────────────
const adminOnly = (user) => { if (user.role !== 'admin') fail(403, 'Administrator only'); };
route('GET', '/api/admin/users', ({ user }) => { adminOnly(user); return db.prepare('SELECT id,username,full_name,dept,role,active,must_change,created_at,last_login FROM users ORDER BY dept, username').all(); });
route('POST', '/api/admin/users', ({ user, body }) => {
  adminOnly(user);
  const username = str(body.username, 60); if (!/^[\w.\-@]{2,60}$/.test(username)) fail(400, 'Username: 2–60 letters, digits, . - _ @');
  if (!db.prepare('SELECT 1 FROM departments WHERE code=?').get(body.dept)) fail(400, 'Choose a department');
  if (str(body.password).length < 6) fail(400, 'Password must be at least 6 characters');
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) fail(400, 'Username already exists');
  const { hash, salt } = DB.hashPassword(body.password);
  db.prepare('INSERT INTO users(username,full_name,dept,role,pw_hash,pw_salt,must_change,created_at) VALUES(?,?,?,?,?,?,?,?)')
    .run(username, str(body.full_name, 120), body.dept, ['admin', 'executive', 'user'].includes(body.role) ? body.role : 'user', hash, salt, body.must_change ? 1 : 0, now());
  return { ok: true };
});
route('PUT', '/api/admin/users/:id', ({ user, params, body }) => {
  adminOnly(user);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(params.id); if (!u) fail(404, 'User not found');
  const role = ['admin', 'executive', 'user'].includes(body.role) ? body.role : u.role;
  if (u.id === user.id && role !== 'admin') fail(400, 'You cannot remove your own administrator role');
  db.prepare('UPDATE users SET full_name=?, dept=?, role=?, active=? WHERE id=?').run(str(body.full_name ?? u.full_name, 120), body.dept || u.dept, role, body.active === undefined ? u.active : (body.active ? 1 : 0), u.id);
  if (body.password) {
    if (str(body.password).length < 6) fail(400, 'Password must be at least 6 characters');
    const { hash, salt } = DB.hashPassword(body.password);
    db.prepare('UPDATE users SET pw_hash=?, pw_salt=?, must_change=? WHERE id=?').run(hash, salt, body.must_change ? 1 : 0, u.id);
    db.prepare('DELETE FROM sessions WHERE user_id=? AND user_id<>?').run(u.id, user.id);
  }
  if (body.active === false) db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id);
  return { ok: true };
});
route('GET', '/api/admin/perms/:id', ({ user, params }) => {
  adminOnly(user);
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(params.id); if (!u) fail(404, 'Not found');
  const explicit = new Map(db.prepare('SELECT step_no, level FROM perms WHERE user_id=?').all(u.id).map((r) => [r.step_no, r.level]));
  return stepNos().map((n) => ({ no: n, name: curDef(n).name, def: defaultLevel(u.dept, n), level: explicit.get(n) || null }));
});
route('PUT', '/api/admin/perms/:id', ({ user, params, body }) => {
  adminOnly(user);
  const del = db.prepare('DELETE FROM perms WHERE user_id=? AND step_no=?');
  const ins = db.prepare('INSERT OR REPLACE INTO perms(user_id,step_no,level) VALUES(?,?,?)');
  for (const [no, lvl] of Object.entries(body.levels || {})) {
    if (['edit', 'view', 'none'].includes(lvl)) ins.run(Number(params.id), Number(no), lvl); else del.run(Number(params.id), Number(no));
  }
  bump();
  return { ok: true };
});
route('POST', '/api/admin/departments', ({ user, body }) => {
  adminOnly(user);
  const code = str(body.code, 10).toUpperCase(); if (!/^[A-Z0-9_]{2,10}$/.test(code)) fail(400, 'Code: 2–10 letters/digits');
  if (!str(body.name)) fail(400, 'Name required');
  db.prepare('INSERT INTO departments(code,name,sort) VALUES(?,?,(SELECT COALESCE(MAX(sort),0)+1 FROM departments))').run(code, str(body.name, 120));
  return { ok: true };
});
route('PUT', '/api/admin/departments/:code', ({ user, params, body }) => {
  adminOnly(user);
  db.prepare('UPDATE departments SET name=COALESCE(?,name), active=COALESCE(?,active) WHERE code=?').run(body.name ? str(body.name, 120) : null, body.active === undefined ? null : (body.active ? 1 : 0), params.code);
  return { ok: true };
});
route('GET', '/api/admin/holidays', () => db.prepare('SELECT date,name FROM holidays ORDER BY date').all());
route('POST', '/api/admin/holidays', ({ user, body }) => {
  adminOnly(user);
  const list = Array.isArray(body.items) ? body.items : [body];
  const ins = db.prepare('INSERT OR REPLACE INTO holidays(date,name) VALUES(?,?)');
  let n = 0; for (const h of list) if (isDate(h.date)) { ins.run(h.date, str(h.name, 120)); n++; }
  calCache = null; bump(); broadcast({ t: 'all' });
  return { ok: true, added: n };
});
route('DELETE', '/api/admin/holidays/:date', ({ user, params }) => {
  adminOnly(user); db.prepare('DELETE FROM holidays WHERE date=?').run(params.date); calCache = null; bump(); broadcast({ t: 'all' }); return { ok: true };
});
route('PUT', '/api/admin/settings', ({ user, body }) => {
  adminOnly(user);
  if (body.company_name !== undefined) S.set('company_name', str(body.company_name, 120));
  if (Array.isArray(body.weekend)) S.set('weekend', body.weekend.map(Number).filter((x) => x >= 0 && x <= 6));
  if (Array.isArray(body.general_notes)) S.set('general_notes', body.general_notes.filter((x) => x && x.t).map((x) => ({ t: str(x.t, 2000), b: (x.b || []).map((y) => str(y, 1000)).filter(Boolean) })));
  if (body.upload_max_mb) S.set('upload_max_mb', String(Math.max(1, Math.min(1000, Number(body.upload_max_mb)))));
  calCache = null; bump(); broadcast({ t: 'all' });
  return { ok: true };
});
// SOP control
route('GET', '/api/admin/sop/:no', ({ params }) => {
  const no = Number(params.no);
  const gen = defs.general.get(no) || [];
  const prod = [...defs.product.entries()].filter(([k]) => k.endsWith(`:${no}`)).flatMap(([, v]) => v);
  const names = new Map(db.prepare('SELECT id,name FROM products').all().map((p) => [p.id, p.name]));
  return { current: curDef(no), versions: [...gen, ...prod].map((v) => ({ ...v, product: v.product_id ? names.get(v.product_id) : null })).sort((a, b) => (a.effective_from < b.effective_from ? 1 : -1) || b.id - a.id) };
});
route('POST', '/api/admin/sop/:no', ({ user, params, body }) => {
  adminOnly(user);
  const no = Number(params.no);
  const d = body.data; if (!d || !d.name || !Array.isArray(d.outputs)) fail(400, 'Invalid SOP content');
  const eff = isDate(body.effective_from) ? body.effective_from : today();
  if (eff < today()) fail(400, 'Changes cannot be retrospective — the effective date must be today or later');
  d.no = no;
  d.deps = (d.deps || []).map(Number).filter((x) => x > 0 && x < no);
  for (const o of d.outputs) if (o.tf && !/^[\d.]+\s*(WD|CD|W|M)$/i.test(String(o.tf).trim())) fail(400, `Invalid timeframe "${o.tf}" — use e.g. 10 WD, 30 CD, 2 W, 1.5 M`);
  const pid = body.product_id ? Number(body.product_id) : null;
  db.prepare('INSERT INTO step_defs(step_no,product_id,effective_from,data,created_by,created_at,note) VALUES(?,?,?,?,?,?,?)')
    .run(no, pid, eff, JSON.stringify(d), user.username, now(), str(body.note, 500) || null);
  loadDefs(); bump();
  const scope = pid ? `product "${getProduct(pid).name}"` : 'all products';
  notify([...new Set([...stepDepts(d)])], { product_id: pid, step_no: no, type: 'update', title: `SOP updated — step ${no} (${scope})`, body: `Effective from ${eff}. ${str(body.note)}`, from_user: user.full_name || user.username, from_dept: user.dept });
  broadcast({ t: 'all' });
  return { ok: true };
});
route('DELETE', '/api/admin/sop/version/:id', ({ user, params }) => {
  adminOnly(user);
  const v = db.prepare('SELECT * FROM step_defs WHERE id=?').get(params.id); if (!v) fail(404, 'Not found');
  if (v.effective_from <= today()) fail(400, 'Only future (not yet effective) versions can be withdrawn');
  db.prepare('DELETE FROM step_defs WHERE id=?').run(v.id); loadDefs(); bump(); broadcast({ t: 'all' });
  return { ok: true };
});
route('POST', '/api/admin/doctypes', ({ user, body }) => {
  adminOnly(user);
  const steps = (body.steps || []).map(Number).filter(Boolean);
  if (!str(body.name) || !str(body.section)) fail(400, 'Section and name are required');
  const reqStep = body.required_step ? Number(body.required_step) : null;
  const reqOut = reqStep && body.required_output ? Number(body.required_output) : null;
  if (reqStep && reqOut && !(curDef(reqStep).outputs || [])[reqOut - 1]) fail(400, `Step ${reqStep} has no output ${reqOut}`);
  if (body.id) db.prepare('UPDATE doc_types SET section=?, name=?, steps=?, active=?, required_step=?, required_output=? WHERE id=?').run(str(body.section, 100), str(body.name, 500), JSON.stringify(steps), body.active === false ? 0 : 1, reqStep, reqOut, Number(body.id));
  else db.prepare('INSERT INTO doc_types(section,name,steps,sort,required_step,required_output) VALUES(?,?,?,(SELECT COALESCE(MAX(sort),0)+1 FROM doc_types),?,?)').run(str(body.section, 100), str(body.name, 500), JSON.stringify(steps), reqStep, reqOut);
  const secs = S.json('doc_sections', []); if (!secs.includes(str(body.section, 100))) { secs.push(str(body.section, 100)); S.set('doc_sections', secs); }
  bump(); broadcast({ t: 'all' });
  return { ok: true };
});

// ───────────────────────── exports / backup ─────────────────────────
function backupTo(file) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  if (fs.existsSync(file)) fs.unlinkSync(file);
  db.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
  return file;
}
route('GET', '/api/export/db', ({ user, res }) => {
  adminOnly(user);
  const f = path.join(DATA_DIR, 'tmp', `export-${Date.now()}.sqlite`);
  backupTo(f);
  const buf = fs.readFileSync(f); fs.unlinkSync(f);
  res.writeHead(200, { 'Content-Type': 'application/vnd.sqlite3', 'Content-Length': buf.length, 'Content-Disposition': contentDisposition('attachment', `sop-tracker-database-${today()}.sqlite`) });
  res.end(buf); return null;
});
route('POST', '/api/admin/backup', ({ user }) => {
  adminOnly(user);
  const f = backupTo(path.join(DATA_DIR, 'backups', `manual-${now().replace(/[: ]/g, '-')}.sqlite`));
  return { ok: true, file: f };
});
function productJson(pid) {
  const c = compute(pid); const p = c.product;
  return {
    exported_at: now(), product: p, summary: summarize(pid),
    steps: [...c.steps.values()].map((s) => ({
      no: s.no, name: s.def.name, phase: s.def.phase, accountable: accText(s.def), state: s.state, readyDate: s.readyDate, due: s.due, overdueDays: s.overdueDays,
      started_at: s.started_at, started_by: s.started_by, completed_at: s.completed_at, completed_by: s.completed_by, na_reason: s.na_reason, waitWD: s.waitWD, onTime: s.onTime,
      inputs: s.inputs.map((i) => ({ idx: i.idx, text: i.def.t, bullets: i.def.b || [], confirmed: i.confirmed, at: i.at, by: i.by })),
      outputs: s.outputs.map((o) => ({ idx: o.idx, text: o.def.t, bullets: o.def.b || [], timeframe: o.def.tfLabel || tfText(o.tf), due: o.due, state: o.state, at: o.at, by: o.by })),
    })),
    notes: db.prepare('SELECT * FROM notes WHERE product_id=?').all(pid),
    risks: db.prepare('SELECT * FROM risks WHERE product_id=?').all(pid),
    history: db.prepare('SELECT * FROM events WHERE product_id=? ORDER BY id').all(pid),
    documents: db.prepare('SELECT f.id,f.step_no,f.output_idx,d.section,d.name doc_name,f.version,f.kind,f.filename,f.size,f.sha256,f.url,f.dept,f.username,f.uploaded_at FROM files f LEFT JOIN doc_types d ON d.id=f.doc_type_id WHERE product_id=? ORDER BY f.step_no, f.output_idx, f.id').all(pid),
    messages: db.prepare('SELECT id,step_no,output_idx,text,dept,username,full_name,created_at FROM messages WHERE product_id=? ORDER BY step_no, output_idx, id').all(pid),
  };
}
const stepsCsv = (j) => csv([['Step', 'Name', 'Phase', 'Accountable', 'State', 'Ready date', 'Final deadline', 'Output deadlines', 'Overdue days', 'Started', 'Completed', 'On time', 'Ready→start (WD)', 'Not applicable reason'],
  ...j.steps.map((s) => [s.no, s.name, s.phase, s.accountable, s.state, s.readyDate, s.due, s.outputs.map((o) => `O${o.idx}: ${o.due || '—'}${o.state ? ` (${o.state})` : ''}`).join('; '), s.overdueDays, s.started_at, s.completed_at, s.onTime == null ? '' : s.onTime ? 'yes' : 'no', s.waitWD, s.na_reason])]);
const safe = (s) => String(s || '').replace(/[\\/:*?"<>|]+/g, '_').slice(0, 90);
route('GET', '/api/export/product/:id', ({ params, query, res }) => {
  const pid = Number(params.id); if (!getProduct(pid)) fail(404, 'Not found');
  const j = productJson(pid);
  if (query.format === 'json') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Content-Disposition': contentDisposition('attachment', `${safe(j.product.name)}.json`) });
    res.end(JSON.stringify(j, null, 2)); return null;
  }
  const entries = [{ name: 'product.json', data: JSON.stringify(j, null, 2) }, { name: 'steps.csv', data: stepsCsv(j) },
    { name: 'system-upload-messages.csv', data: csv([['Step', 'Output', 'Date', 'Department', 'User', 'Message'], ...j.messages.map((m) => [m.step_no, m.output_idx, m.created_at, deptName(m.dept), m.full_name || m.username, m.text])]) }];
  // documents are read from disk one at a time while the ZIP is streamed to the browser
  const files = db.prepare("SELECT f.id, f.step_no, f.output_idx, f.version, f.filename, f.path, f.doc_type_id, d.section, d.name doc_name FROM files f LEFT JOIN doc_types d ON d.id=f.doc_type_id WHERE f.product_id=? AND f.kind<>'link' ORDER BY f.step_no, f.output_idx, f.id").all(pid);
  for (const f of files) {
    const st = `step-${String(f.step_no).padStart(2, '0')}`;
    const folder = f.doc_type_id ? `documents/${safe(f.section)}/${safe(f.doc_name)}` : `step-uploads/${st}/output-${f.output_idx || 'general'}`;
    if (f.path) entries.push({ name: `${folder}/v${f.version}_${safe(f.filename)}`, file: path.join(DATA_DIR, f.path) });
    else { const b = db.prepare('SELECT data FROM files WHERE id=?').get(f.id); entries.push({ name: `${folder}/v${f.version}_${safe(f.filename)}`, data: toBuf(b && b.data) }); }
  }
  res.writeHead(200, { 'Content-Type': 'application/zip', 'Content-Disposition': contentDisposition('attachment', `${safe(j.product.name)}-${today()}.zip`), 'Cache-Control': 'no-store' });
  streamZip(res, entries).catch((e) => { logErr('zip export', e); res.destroy(); });
  return null;
});
route('GET', '/api/export/csv/:tab', ({ user, params, query, res }) => {
  let rows; const tab = params.tab;
  if (tab === 'dashboard' || tab === 'analytics') needDash(user);
  if (tab === 'dashboard') {
    const list = db.prepare('SELECT id FROM products').all().map((r) => summarize(r.id));
    rows = [['Product', 'API / salt', 'Dosage form & strengths', 'Markets', 'Start', 'Status', 'Progress %', 'Steps completed', 'Cancelled steps', 'Last completed', 'In process', 'Overdue', 'Next deadline', 'Open critical risks', 'Expected license', 'Expected 1st 3 commercial batches'],
      ...list.map((s) => [s.name, s.api, s.dosage, s.markets, s.start_date, s.status, s.progress.pct, `${s.progress.done}/${s.progress.total}`, s.cancelled.map((c) => `${c.no} ${c.name} (${c.reason})`).join('; '), s.lastDone ? `${s.lastDone.no} ${s.lastDone.name}` : '', s.inProc.map((x) => `${x.no} ${x.name}`).join('; '), s.overdue.map((x) => `${x.no} ${x.name} [${x.acc}] ${x.overdueDays}d`).join('; '), s.next ? `${s.next.due} step ${s.next.no} ${s.next.name} [${s.next.acc}]` : '', s.criticalRisks, s.license ? s.license.date : '', s.commercial ? s.commercial.date : ''])];
  } else if (tab === 'flow') {
    rows = null; const j = productJson(Number(query.product));
    res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': contentDisposition('attachment', `${safe(j.product.name)}-steps.csv`) }); res.end(stepsCsv(j)); return null;
  } else if (tab === 'documents') {
    const list = db.prepare('SELECT p.name product,d.section,COALESCE(d.name, f.filename) doc,f.step_no,f.output_idx,f.version,f.kind,f.filename,f.url,f.dept,f.username,f.uploaded_at FROM files f JOIN products p ON p.id=f.product_id LEFT JOIN doc_types d ON d.id=f.doc_type_id ORDER BY f.uploaded_at DESC').all();
    rows = [['Product', 'Section', 'Document', 'Step', 'Output', 'Version', 'Kind', 'File name', 'Link', 'Department', 'User', 'Uploaded'], ...list.map((x) => Object.values(x))];
  } else if (tab === 'mydept') {
    const dept = (isExec(user) && query.dept) ? query.dept : user.dept; const d = myDept(dept);
    rows = [['Product', 'Category', 'Step', 'Name', 'Accountable', 'Ready date', 'Deadline', 'Overdue days', 'Ready→start (WD)']];
    d.forEach((p) => ['overdue', 'in_progress', 'ready', 'coming'].forEach((k) => p[k].forEach((s) => rows.push([p.product.name, k, s.no, s.name, s.acc, s.readyDate || s.fReady, s.due || s.fDue, s.overdueDays, s.waitWD]))));
  } else if (tab === 'analytics') {
    const a = analytics(/^\d{4}-\d{2}$/.test(query.month || '') ? query.month : today().slice(0, 7));
    rows = [['Month', 'Department', 'Products with on-time steps', 'Steps completed', 'Completed within timeframe', 'On-time %', 'Steps overdue', 'Avg ready→start (WD)', 'Ready, not started', 'Positive points', 'Negative points', 'Final conclusion', 'Auto assessment'],
      ...a.depts.map((d) => [a.month, d.name, d.productsOnTime, d.completed, d.onTime, d.rate, d.overdue, d.avgWait, d.notStarted, d.positives, d.negatives, d.conclusion, d.auto])];
  } else if (tab === 'notifications') {
    const list = db.prepare('SELECT n.created_at,n.dept,p.name,n.step_no,n.type,n.title,n.body,n.from_user,n.from_dept FROM notifications n LEFT JOIN products p ON p.id=n.product_id WHERE n.dept=? ORDER BY n.id DESC').all(user.dept);
    rows = [['Date', 'To department', 'Product', 'Step', 'Type', 'Title', 'Message', 'From', 'From department'], ...list.map((x) => Object.values(x))];
  } else fail(404, 'Unknown export');
  res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': contentDisposition('attachment', `${tab}-${today()}.csv`) });
  res.end(csv(rows)); return null;
});

// ───────────────────────── live events (SSE) ─────────────────────────
route('GET', '/api/events', ({ user, req, res }) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
  // 2 KB of padding first: antivirus web-scanners and proxies that hold a stream until they have "enough" data then pass it on
  res.write(`:${' '.repeat(2048)}\nretry: 5000\n\n`);
  res.write(`data: ${JSON.stringify({ t: 'hello', online: clients.size + 1, v: live.v, mv: live.mv })}\n\n`);
  const c = { res, user: { id: user.id, dept: user.dept, name: user.full_name || user.username } };
  clients.add(c);
  broadcast({ t: 'presence', online: [...clients].map((x) => x.user.name) });
  req.on('close', () => { clients.delete(c); broadcast({ t: 'presence', online: [...clients].map((x) => x.user.name) }); });
  return null;
});
setInterval(() => { for (const c of clients) { try { c.res.write(': ping\n\n'); } catch { clients.delete(c); } } }, 25000).unref();
// fallback for browsers whose live connection is blocked: a short request every 20 s instead of a permanent connection
route('GET', '/api/live', ({ user }) => ({ v: live.v, mv: live.mv, unread: publicUser(user).unread, online: [...clients].map((x) => x.user.name) }));
// errors that happen in a browser are written to data/server.log, so problems on a laptop can be traced on the server
const clientLogCount = new Map();
route('POST', '/api/client-log', ({ user, body, req }) => {
  const n = (clientLogCount.get(user.id) || 0) + 1; clientLogCount.set(user.id, n);
  if (n <= 50) logErr(`browser error · ${user.username} (${user.dept}) · ${str(body.where, 80)} · ${str(body.url, 200)} · ${str(body.msg, 500)}\n  ${str(req.headers['user-agent'], 300)}${body.stack ? `\n  ${str(body.stack, 1500).replace(/\n/g, '\n  ')}` : ''}`);
  return { ok: true };
});
setInterval(() => clientLogCount.clear(), 3600e3).unref();
// connection test: open http://SERVER-IP:3000/api/ping on a laptop
route('GET', '/api/ping', () => ({ ok: true, app: APP_NAME, version: APP_VERSION, node: process.versions.node, serverTime: now(), liveConnections: clients.size }), { public: true });

// ───────────────────────── server ─────────────────────────
function currentUser(req) {
  const t = cookies(req).sid; if (!t) return null;
  const s = db.prepare('SELECT * FROM sessions WHERE token=?').get(t);
  if (!s || s.expires < Date.now()) { if (s) db.prepare('DELETE FROM sessions WHERE token=?').run(t); return null; }
  const u = db.prepare('SELECT * FROM users WHERE id=? AND active=1').get(s.user_id);
  if (u && s.expires - Date.now() < (SESSION_HOURS * 3600e3) / 2) db.prepare('UPDATE sessions SET expires=? WHERE token=?').run(Date.now() + SESSION_HOURS * 3600e3, t);
  return u || null;
}

// static files: ETag / 304 so browsers re-use the scripts and styles they already have
function serveStatic(req, res, pathname) {
  const p = pathname === '/' ? '/index.html' : pathname;
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR)) return send(res, 403, 'Forbidden');
  const serve = (f, st) => {
    const etag = `W/"${st.size.toString(16)}-${Math.floor(st.mtimeMs).toString(16)}"`;
    const h = { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache', ETag: etag };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, h); return res.end(); }
    const gz = res._gzip && /\.(js|css|html|svg|json)$/.test(f);
    if (gz) { h['Content-Encoding'] = 'gzip'; h.Vary = 'Accept-Encoding'; }
    res.writeHead(200, h);
    if (gz) pipeline(fs.createReadStream(f), zlib.createGzip({ level: 6 }), res, () => {});
    else pipeline(fs.createReadStream(f), res, () => {});
  };
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) {
      const idx = path.join(PUBLIC_DIR, 'index.html'); // SPA fallback
      return fs.stat(idx, (e, s2) => (e ? send(res, 404, 'Not found') : serve(idx, s2)));
    }
    serve(file, st);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const pathname = decodeURIComponent(url.pathname);
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res._gzip = /\bgzip\b/.test(req.headers['accept-encoding'] || '');
  if (!pathname.startsWith('/api/')) return serveStatic(req, res, pathname);
  if (pathname !== '/api/events' && !pathname.startsWith('/api/export') && !pathname.includes('upload')) {
    const t0 = Date.now();
    res.on('finish', () => { const ms = Date.now() - t0; if (ms > 5000) logErr(`slow request ${ms} ms`, req.method, pathname); });
  }
  const r = routes.find((x) => x.method === req.method && x.re.test(pathname));
  if (!r) return send(res, 404, { error: 'Not found' });
  try {
    const m = pathname.match(r.re); const params = {}; r.keys.forEach((k, i) => { params[k] = m[i + 1]; });
    const query = Object.fromEntries(url.searchParams.entries());
    let user = null;
    if (!r.opts.public) {
      user = currentUser(req);
      if (!user) return send(res, 401, { error: 'Please sign in' });
      if (user.must_change && !r.opts.allowMustChange && req.method !== 'GET') return send(res, 403, { error: 'Please change your password first' });
    }
    if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'sop-tracker') return send(res, 403, { error: 'Bad request origin' });
    let body = {};
    if ((req.method === 'POST' || req.method === 'PUT') && pathname !== '/api/upload' && pathname !== '/api/announcements/upload') {
      const raw = await readBody(req, 5 * 1048576);
      if (raw.length) { try { body = JSON.parse(raw.toString('utf8')); } catch { return send(res, 400, { error: 'Invalid JSON' }); } }
    }
    const out = await r.handler({ req, res, user, params, query, body });
    if (out === null) return;
    const headers = {};
    if (out && out._cookie) { headers['Set-Cookie'] = out._cookie; delete out._cookie; }
    send(res, 200, out, headers);
  } catch (e) {
    if (e instanceof HttpError) return send(res, e.code, { error: e.message });
    logErr(req.method, pathname, e);
    if (!res.headersSent) send(res, 500, { error: 'Server error: ' + e.message });
  }
});

// periodic: overdue detection / readiness by date, daily backup, session cleanup
let lastBackupDay = null;
function housekeeping() {
  try {
    for (const { id } of db.prepare("SELECT id FROM products WHERE status='active'").all()) afterChange(id, null, { noBump: true });
    db.prepare('DELETE FROM sessions WHERE expires<?').run(Date.now());
    db.exec('PRAGMA optimize');
    const d = today();
    if (lastBackupDay !== d && process.env.AUTO_BACKUP !== '0') {
      lastBackupDay = d;
      const dir = path.join(DATA_DIR, 'backups');
      backupTo(path.join(dir, `daily-${d}.sqlite`));
      const keep = Number(process.env.BACKUP_KEEP) || 14;
      fs.readdirSync(dir).filter((f) => f.startsWith('daily-')).sort().reverse().slice(keep).forEach((f) => fs.unlinkSync(path.join(dir, f)));
    }
  } catch (e) { logErr('housekeeping', e); }
}
setInterval(housekeeping, 30 * 60 * 1000).unref();

server.listen(PORT, HOST, () => {
  if (S.get('sync_states') === '1') {
    // first start after the SOP version 3 upgrade: align stored states silently (no burst of hand-off notifications)
    for (const { id } of db.prepare('SELECT id FROM products').all()) afterChange(id, null, { silent: true, noBump: true });
    S.set('sync_states', '0');
  }
  housekeeping();
  const ips = Object.values(os.networkInterfaces()).flat().filter((i) => i && i.family === 'IPv4' && !i.internal).map((i) => i.address);
  console.log(`\n  ${APP_NAME} ${APP_VERSION} is running`);
  console.log(`  Local:    http://localhost:${PORT}`);
  ips.forEach((ip) => console.log(`  Network:  http://${ip}:${PORT}`));
  console.log(`  Data:     ${DATA_DIR}`);
  console.log('  First login: department "System Administration", user "admin", password "admin" (you will be asked to change it)');
  console.log(`  Messages and errors: ${path.join(DATA_DIR, 'server.log')}`);
  if (LOG_TO_FILE && process.platform === 'win32') console.log('  Keep this window open while the system is used. For daily use, run windows-autostart-setup.bat once instead.');
  console.log('');
});
server.on('error', (e) => {
  console.error(e.code === 'EADDRINUSE' ? `\n  Port ${PORT} is already used — the system is probably already running (scheduled task). Open http://localhost:${PORT}\n` : e);
  process.exit(e.code === 'EADDRINUSE' ? 3 : 1);
});
process.on('SIGINT', () => { try { db.close(); } catch { /* ignore */ } process.exit(0); });
process.on('SIGTERM', () => { try { db.close(); } catch { /* ignore */ } process.exit(0); });
