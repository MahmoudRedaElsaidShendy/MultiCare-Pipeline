@echo off
REM ===== Multicare Pipeline Tracker and Management System - start on Windows =====
REM Change the port here if 3000 is already used on the server.
set PORT=3000
set TZ=Africa/Cairo
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install the LTS version from https://nodejs.org and run this file again.
  pause
  exit /b 1
)
echo Starting Multicare Pipeline Tracker and Management System on port %PORT% ...
node --disable-warning=ExperimentalWarning server.js
pause
