# Multicare Pipeline Tracker and Management System — install & use guide

**Multicare Pipeline Platform: one system for management, tracking, coordination, communication — and one database.**

A self-hosted, multi-user intranet web application that mirrors Multicare's **new-product SOP pipeline — SOP version 3
(35 steps, 7 phases)** and replaces e-mail between departments: every output is delivered inside the platform
(**System-Upload** = a file and/or a short message), and it appears automatically in the input of the next step.
It runs on the company server; team members open it in Chrome or Edge — nothing to install on their PCs.

- **No internet needed and no extra packages.** The only requirement is **Node.js 22.13 or newer** (LTS 22.x or 24.x).
- **Central data:** `data/sop-tracker.sqlite` (database) + `data/files/` (uploaded documents, one folder per product).
- **Live collaboration:** every open browser updates within a second when someone changes a step.

---

## 1. Install on the company server (IT team, ~10 minutes)

### Windows Server / Windows PC
1. Install **Node.js LTS** from https://nodejs.org (accept the defaults).
2. Copy the `multicare-pipeline-tracker` folder to the server, e.g. `D:\Apps\multicare-pipeline-tracker`.
3. Right-click **`windows-autostart-setup.bat` → Run as administrator.**
   This opens port 3000 in the Windows firewall and registers a task that starts the system every time the server boots.
   (To try it once without auto-start, double-click `start-windows.bat` instead.)
4. On any PC in the network open **`http://SERVER-IP:3000`** (the start window prints the exact address, e.g. `http://192.168.1.10:3000`).

### Installing a newer package later (keeps all products, users, uploads and history)
1. Copy **everything from the new package except the `data` folder** over the installed folder (replace files when asked).
   Never delete or replace the installed `data` folder — it is your database and documents.
2. Right-click `windows-autostart-setup.bat` → Run as administrator. It stops the running copy and starts the new one.
3. If the new package changes the database, a safety copy is saved first in `data/backups` and the update runs by itself
   (see `data\server.log`).

### Linux server
```bash
sudo cp -r multicare-pipeline-tracker /opt/multicare-pipeline-tracker && sudo useradd -r sop && sudo chown -R sop /opt/multicare-pipeline-tracker
sudo cp /opt/multicare-pipeline-tracker/deploy/multicare-pipeline.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now multicare-pipeline
```
Or just run `./start-linux.sh`. Docker users: `docker compose -f deploy/docker-compose.yml up -d`.

### Options (environment variables)
| Variable | Default | Meaning |
|---|---|---|
| `PORT` | 3000 | Port the app listens on (change in the `.bat` files) |
| `TZ` | Africa/Cairo | Plant time zone used for dates and deadlines |
| `DATA_DIR` | `./data` | Where the database, uploaded documents and backups are stored |
| `AUTO_BACKUP` / `BACKUP_KEEP` | on / 14 | Daily database copy in `data/backups`, number of days kept |
| `START_ALERT_WD` | 2 | Working days a ready step may wait before the start-delay alert |

### Backups
- Ask IT to include the **whole `data` folder** in the normal server backup — the database **and** `data/files` (the documents).
- The app also writes a daily database copy to `data/backups`; an administrator can download the database any time
  (Settings → Database & export), and each product can be exported as a ZIP with all its documents.
- Restore: stop the app, replace `data/sop-tracker.sqlite` with the backup file, delete the `-wal`/`-shm` files next to it,
  restore `data/files` from the same backup date, start again.

### Performance with many documents
Documents are stored as files and streamed (never loaded fully into memory); every upload gets a SHA-256 checksum.
Document lists, notifications and searches are paged and filtered inside the database; responses are compressed and the browser
re-uses cached scripts. Tested with 6,000 documents, 2,000 messages and 30,000 notifications: every screen answers in under 0.1 s.
Product ZIP exports are written file by file. Recommended: keep the `data` folder on a local disk of the server (not a network share).

---

## 2. First sign-in (administrator)
1. Department **System Administration**, username **admin**, password **admin** → you are asked to set a new password.
2. **Settings → Users & access:** create one account per person (department, username, temporary password, role).
   - *Department user* – editor on the steps of the own department, viewer elsewhere. Sees Notifications, Project flow and My department.
   - *Executive* (CEO / Business Development, Plant Manager) – also sees the Dashboard, creates products, changes deadlines,
     re-opens steps and writes the monthly department evaluation.
   - *Administrator* – everything, including deleting uploaded documents.
   - **Step access** button: change editor / viewer / no access per step for any person.
   - Users of the Plant Management and Business Development departments always see the Dashboard.
3. **Holidays & working week:** review the pre-filled 2026 Egyptian holidays (Islamic dates are estimates) and add next year's
   official holidays. Working days are Sunday–Thursday.
4. Executive or administrator: **Dashboard → New product project** to create the first product.

---

## 3. How the team uses it (daily)
| Tab | Who | What it is for |
|---|---|---|
| **Notifications** | everyone | Opens at sign-in: updates, hand-offs, System-Uploads, announcements, notes, reminders, overdue and start-delay alerts and risk findings for your department. Unread ones stay **yellow** until you tick **Read** (opening one does not mark it read; untick to make it unread again). |
| **Dashboard** | Plant Manager, CEO / BD, admin | KPI cards, every product with progress, overdue outputs, next deadline, risk findings, cancelled steps, expected license and 1st commercial batch dates; monthly department analytics; new-product form. |
| **Project flow** | everyone | **Product documents** at the top — all SOP-controlled documents of the product in SOP step order: uploaded ones in green (open, download, versions), not-yet-uploaded ones greyed out (upload / open step); search, filter and sort. Below: the 35 steps in 7 phase lanes (`→` sequential, `‖` parallel, `↻` iterative loop) and the other recommendations. |
| **My department** | everyone | Your department's overdue, in-progress, ready-to-start and coming-next steps and risk findings. |
| **Announcement** | admin, Business Development, Plant Manager | Send a message, with or without attached files, to one, several or all departments, about one product or in general. It appears in their Notifications (filter *Announcements*). |
| **Settings** | admin (executives: exports, upload rules view) | Users, access rights, departments, holidays, SOP content editor, **upload rules**, document list, exports, general settings. |

**System-Upload (replaces e-mail):** each output of a step has a System-Upload box showing the receiving departments.
Deliver the output there — **Upload file** and/or write a **short message** (a link can also be added). The receiving departments
are notified immediately, and the files and messages appear in the **Input** of the next step, where they can be opened and downloaded.
- An output **cannot be checked** until it has its System-Upload.
- **Upload rules** (Settings → Upload rules): the administrator can make a file upload mandatory for any output — the output
  then cannot be checked with a message (or a link) alone. Takes effect immediately for every product.
- Where each department checks its own part (steps 2, 4, 7, 10, 20, 30, 33), each checking department adds its own file or message first.
- **SOP-controlled documents** are part of their output and always mandatory: a message alone is never accepted for them.
  Each upload becomes the next version — nothing is overwritten (only the administrator can delete).

**Working a step:** step becomes *Ready* when the steps it depends on close → **Start step** → tick each **input** after checking
what the previous step delivered → deliver each **output** by System-Upload and tick it → **Complete step** (only when all inputs
and outputs are ticked and every required SOP-controlled document of the step has at least one version).

**Outputs checked by several departments:**
step 2 (R&D, QC, Supply Chain — one output each), step 4 (each output by the department that delivers it: Methodology, QC or R&D),
step 7 (the purchasing request — both R&D and QC), step 10 (R&D, QC, CTD) and step 30 (RA, CTD).
After that, any accountable department can complete the step.

**Planning steps 20 (pilot) and 33 (commercial):** 13 separate outputs in 5 groups —
1 API test results conformance (2 outputs: RA, QC), 2 material list finalization (3: R&D, QC, QA),
3 resources availability (3: Supply Chain, Production, QC), 4 QA document issuing and control (4: QA),
5 planned production date (1: Plant Manager). Each output is filled (message / upload) by the department named in it and then
checked by the **Plant Manager or QA** as final accountability; the Plant Manager and QA can also fill any output.

**Long-running outputs:** step 13 output 5 (trial stability, 3 months), step 24 output 2 (6-month accelerated and long-term
data, 7 months) and step 28 output 3 (third-party BE / comparative study, 4 months). When every other output of the step is
delivered, the next steps become ready (steps 13 and 24). Step 28 is flagged only: step 30 (submission) waits until the BE study
is received and step 28 is completed.
The step card stays flagged (“Needs trial stability data” / “Needs 6-month stability data” / “Needs BE study data”) until the
long-running output is delivered and the step is completed.

**Deadlines:** each output's deadline = ready date + its own SOP timeframe, so a step can show several due dates, and overdue days
are counted per output (WD = Sunday–Thursday working days excluding holidays; calendar-day / week / month timeframes that end on
a non-working day move to the next working day). Overdue outputs notify the accountable departments, the Plant Manager and
Business Development.

**Start delays:** a step that is ready but not started within 2 working days notifies the accountable departments, the Plant
Manager and Business Development.

**Risk findings** are sent to the action owner, the step's departments, the Plant Manager and Business Development (business owner).

**SOP changes:** Settings → SOP control (including the receiving departments, filled-by and checked-by departments of each output). Each save is a new version effective
from today or a later date, for all products or one product. A step keeps the version that was in force on the day it became
ready — changes are never retrospective.

### If a screen stays on "Loading…"
- Every request now stops waiting after 30 seconds and shows the reason with a **Try again** button.
- A browser keeps at most **6 connections** open to one server, and every tab of the system used to keep one live-update
  connection open permanently — with 6 tabs open, steps no longer opened. Since version 3.1.2 only the tab on screen keeps a
  live connection; background tabs show **Paused** and catch up when shown again.
- If the indicator at the top right shows **Auto-refresh** instead of **Live**, antivirus web scanning or a proxy on that PC
  holds the live connection; the screen then refreshes every 20 seconds. For instant updates, exclude `http://SERVER-IP:3000`
  from web scanning and from the proxy (Windows proxy settings: "Don't use the proxy server for local (intranet) addresses").
- Connection test from any PC: `http://SERVER-IP:3000/api/ping` must answer at once with `"ok": true`.
- Browser-side errors and requests slower than 5 seconds are written to `data/server.log`.
- Windows: the scheduled task now has no 3-day time limit (Windows stops tasks after 3 days by default) and restarts the system
  15 seconds after an unexpected stop. When started with `start-windows.bat`, nothing is written to the window after start-up,
  so clicking inside it can no longer pause the server.

---

## 4. Assumptions to review
- Steps **1** and **32** have no timeframe in the SOP – a default of 2 WD and 5 WD is used (marked "default"); edit in SOP control.
- Step **3** "1–2 months" uses 2 months; "1 week" = 7 calendar days; "1.5 month" = 1 month + 15 days.
- Expected license date = forecast of step 30 output 1 (Registration License). Expected 1st 3 commercial batches = step 34 output 1.
- Step 29 depends on steps 23, 24 and 27; its inputs are the RA priority list, the 6-month stability data (24), the CADC
  conformance report (26) and the comparative dissolution report (27). Step 30 depends on steps 23–29 and needs step 28
  completed (BE study received).
- Receiving departments of each output follow the SOP wording ("System-Upload to …"); where the SOP names nobody, the Plant Manager
  and the departments of the next step receive it. Adjustable per output in Settings → SOP control.
- SOP-controlled documents include the **Risk Assessment Report** (step 4, output 8). QA-controlled documents: the 8 R&D /
  Methodology documents are required at step 17 (output 1), the 5 API / reference-standard documents at step 20 (output 10,
  “QA issuing, System-Upload and controlling the documents”).
- The "Other recommendations" are shown under every product's workflow; the administrator edits them in Settings → General.

## 5. Files in this package
```
server.js              application server (no dependencies)
src/                   database + automatic upgrades, SOP content (sop-data.js), dependency & calendar engine, ZIP writer
public/                browser application (logo: public/multicare-logo.png)
start-windows.bat      start manually on Windows
windows-autostart-setup.bat / run-service.bat   auto-start on Windows boot + firewall rule
start-linux.sh, deploy/  Linux service, Dockerfile, docker-compose
data/                  created at first start: database, uploaded documents (files/), backups, log
```
