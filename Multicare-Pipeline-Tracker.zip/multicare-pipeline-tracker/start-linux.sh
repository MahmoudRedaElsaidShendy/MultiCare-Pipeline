#!/usr/bin/env bash
# Multicare Pipeline Tracker and Management System — start on Linux / macOS
cd "$(dirname "$0")"
export PORT="${PORT:-3000}"
export TZ="${TZ:-Africa/Cairo}"
command -v node >/dev/null || { echo "Node.js is not installed (need 22.13 or newer): https://nodejs.org"; exit 1; }
exec node --disable-warning=ExperimentalWarning server.js
