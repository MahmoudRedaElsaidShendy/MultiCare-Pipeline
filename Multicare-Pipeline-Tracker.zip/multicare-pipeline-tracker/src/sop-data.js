'use strict';
/*
 * SOP seed data — "Process management SOPs for new products (pipeline)", SOP version 3
 * (Updated_SOPs_Version_3: steps 4, 5 and 6 merged into step 4 → 35 steps; e-mail replaced by System-Upload).
 * Loaded into the database on first run (or by the one-time upgrade). After that, everything is edited from
 * Control → SOP control (versioned, effective from the change date — never retrospective).
 *
 * Item shape (inputs / tasks / outputs / notes):
 *   t    : main text (one numbered item)
 *   b    : bullets that belong to the same numbered item
 * Inputs:  from : ['6'] whole step, or ['6.1'] = step 6 output #1;  dept : source department when no step
 * Outputs: tf   : timeframe "10 WD" | "30 CD" | "1 W" | "2 M" | "1.5 M"   (WD = working days Sun–Thu)
 *          tfLabel : original SOP wording when it differs, assumed:true when the SOP gives no timeframe
 *          dept : department that delivers the output
 *          rcpt : departments that receive the System-Upload (notified of every file / message on the output)
 *          to   : hand-off step numbers ("input of step …")
 *          signoff : departments that must each check the output (multi-accountable steps)
 *          fin  : true = final output after the iterative loop (steps 12/13)
 *          rel  : output index (1-based) whose completion is the start of this timeframe
 *          defer / deferLabel : long-running output — the next steps may start before it is delivered
 *          releaseTo : with defer — only these next steps may start early (the others wait for completion); [] = none (card flag only)
 *          by       : departments that fill the output (text / upload); default: any editor of the step
 *          checkers : departments that check the output (any one of them); default: any editor
 *          group    : heading shown above a group of outputs (steps 20 and 33)
 */

const DEPARTMENTS = [
  { code: 'BD',   name: 'Business Development / CEO Office' },
  { code: 'PM',   name: 'Plant Management' },
  { code: 'RD',   name: 'R&D – Formulation' },
  { code: 'MET',  name: 'R&D – Methodology' },
  { code: 'QC',   name: 'Quality Control' },
  { code: 'SC',   name: 'Supply Chain' },
  { code: 'RA',   name: 'Regulatory Affairs' },
  { code: 'CTD',  name: 'CTD' },
  { code: 'QA',   name: 'Quality Assurance' },
  { code: 'PROD', name: 'Production' },
  { code: 'STAB', name: 'Stability' },
  { code: 'ADM',  name: 'System Administration' },
];

const PHASES = [
  { no: 1, name: 'Project Feasibility' },
  { no: 2, name: 'Rigorous Desk Research' },
  { no: 3, name: 'Sourcing (API, Brand, Analytical Needs)' },
  { no: 4, name: 'Pilot Batches' },
  { no: 5, name: 'Post-Pilot Batch Production' },
  { no: 6, name: 'CTD File and RA Submission' },
  { no: 7, name: 'Commercial Batches' },
];

// Flow layout: how the steps are drawn on the Project Flow board.
// seq = sequential chain, par = parallel (run at the same time), loop = parallel + iterative loop
const FLOW = [
  { phase: 1, type: 'seq',  steps: [1, 2, 3] },
  { phase: 2, type: 'seq',  steps: [4] },
  { phase: 3, type: 'par',  steps: [5, 6] },
  { phase: 3, type: 'seq',  steps: [7, 8] },
  { phase: 3, type: 'par',  steps: [9, 10] },
  { phase: 3, type: 'seq',  steps: [11] },
  { phase: 3, type: 'loop', steps: [12, 13], label: 'Repeated in loop till reaching the formula of choice' },
  { phase: 3, type: 'seq',  steps: [14, 15] },
  { phase: 3, type: 'par',  steps: [16, 17] },
  { phase: 3, type: 'seq',  steps: [18, 19] },
  { phase: 4, type: 'seq',  steps: [20, 21, 22] },
  { phase: 5, type: 'par',  steps: [23, 24, 25] },
  { phase: 5, type: 'par',  steps: [26, 27, 28], label: 'According to step 25 — step 27 or 28 (or both) will be performed' },
  { phase: 6, type: 'seq',  steps: [29, 30, 31] },
  { phase: 7, type: 'seq',  steps: [32, 33, 34, 35] },
];

const LICENSE_STEP = 30;      // progress denominator & "expected license date"
const LICENSE_OUTPUT = 1;     // step 30 output 1 = Registration License
const COMMERCIAL_STEP = 34;   // "expected 1st 3 commercial batches"
const COMMERCIAL_OUTPUT = 1;  // step 34 output 1 = commercial batches production attended / confirmed

// Official sources referenced by "CLICK HERE" links in the SOP document
const LINK = {
  EDA_NITROSAMINE: 'https://edaegypt.gov.eg/media/1c1guytq/guidance-for-human-pharmaceutical-type-ii-var.pdf',
  EDA_BE_GUIDELINE: 'https://edaegypt.gov.eg/media/emojnonb/egyptian-be-guideline-v-4-pdf-en-up.pdf',
  EDQM_CEP: 'https://extranet.edqm.eu/publications/recherches_CEP.shtml',
  EDA_API_LIST: 'https://edaegypt-my.sharepoint.com/:x:/g/personal/hdr_qualitymodule_edaegypt_gov_eg/IQB6e_fpMrAWRrpxPAdjZudzAWSdbxLZAOWfPe2Ke2B9eKo',
  FDA_DMF: 'https://www.fda.gov/drugs/drug-master-files-dmfs/types-drug-master-files-dmfs',
  EDA_CRM: 'https://edaegypt-my.sharepoint.com/:x:/g/personal/dc_crmlabaccredit_edaegypt_gov_eg/EdGlbnJRfRlHqM1_3v7OPtIB2za54p1WZT5_6SmSucJYwg',
};

// ---------- step 4 guidance notes ----------
const NOTE_ROLES = {
  title: 'Selection of the API quality standards — Methodology recommends, QC decides (*)',
  items: [
    { t: 'The Methodology recommends the API quality standards based on the analytical perspective of the FPP, and System-Uploads the proposal and its technical justification to QC.' },
    { t: 'QC then evaluates the recommendation against both the API and FPP analytical perspectives and makes the final selection of the API quality standards, taking into account analytical capabilities, cost and operational needs.' },
  ],
};
const NOTE_QS = {
  title: 'Step 4 notes on how to select the appropriate API quality standards — Methodology, QC and R&D',
  items: [
    { t: 'Never go for a non-pharmacopeial grade (in-house) API if a pharmacopeial grade API is available.' },
    { t: 'Availability of the analytical instrument at our labs, cost of reference standards and columns. Generally, EDQM/BP reference standards are significantly more economical.' },
    { t: 'Alignment of the API standard with the intended FPP monograph is the safest regulatory path.' },
    { t: 'Availability of an FPP monograph.' },
    { t: 'Physical attributes and polymorphism: pharmacopeial monographs occasionally differ in their requirements for solid state (crystal habit – polymorphism), hydration state, bulk density, or particle size distribution. For BCS Class II and IV drugs (low solubility), these physical differences directly impact dissolution profiles and bioequivalence (BE) studies. You must select the grade whose physical parameters best match the API used in the Reference Product to prevent bioequivalence failure.' },
    { t: 'If one pharmacopoeia permits a tighter water content (Loss on Drying) or lower initial degradation impurity limit on the API than the other, procuring the tighter grade gives your FPP a larger "stability cushion" over a 24- or 36-month shelf life.' },
  ],
};
const NOTE_AN_QC = {
  title: 'Step 4 notes to consider when requesting the analytical needs (column, reference standards) — QC',
  items: [
    { t: 'Consider requesting a quantity sufficient for the API and FPP analysis in (Methodology, QC and CADC analysis).' },
    { t: `Always check the EDA published list for high-risk APIs that can form nitrosamine impurities (${LINK.EDA_NITROSAMINE}), so consider requesting the nitrosamine impurity reference standard.` },
    { t: 'Always check the API chirality and enantiomeric impurities analysis need in API and FPP, so consider requesting the enantiomeric impurity reference standard.' },
  ],
};
const NOTE_FPS = {
  title: 'Step 4 notes to consider when proposing the initial finished product specification',
  items: [
    { t: `Always check the EDA published list for high-risk APIs that can form nitrosamine impurities (${LINK.EDA_NITROSAMINE}), so consider the test and request the nitrosamine impurity reference standard.` },
    { t: 'Always check the API chirality and enantiomeric impurities analysis need in API and FPP, so consider the test and request the enantiomeric impurity reference standard.' },
    { t: 'For listing of the related impurities profile, consider the following cascade. Pre-cascade gate — scope:', b: [
      'FPS related impurities = degradation products only + impurities generated by the product itself (excipient / container interaction).',
      'Drug-substance process impurities are excluded unless proven to increase on stability.',
      'Mutagenic / nitrosamine, residual solvent and elemental impurities belong to separate sections (M7 / Q3C / Q3D) — cross-reference, don’t merge.',
      'Declare one standard: Egyptian Pharmacopoeia first (national), then USP / BP / EP / JP / Ph.Int. Nomenclature, RRT and impurity designation must follow the adopted monograph. Adopt one monograph in full — no cherry-picking across pharmacopoeias.',
    ] },
    { t: 'Decision cascade (stop at the first applicable step):', b: [
      '1) FPP monograph in the same pharmacopoeia as the declared API standard → adopt the impurity profile.',
      '2) FPP monograph in another EDA-recognized pharmacopoeia → adopt in full; confirm same dosage form, strength range and release profile; where recognized monographs differ, justify or default to the stricter.',
      '3) FPP monograph of the same API in a different / relevant dosage form → transpose only degradants relevant to the proposed form; rescale limits to the maximum daily dose according to ICH Q3B.',
      '4) DMF 3.2.S.3.2 / API monograph impurity list → carry over only those demonstrated to be degradants by checking impurities characterization (3.2.S.3.2), forced degradation + accelerated / long-term stability (3.2.S.4.3 and 3.2.S.7).',
      '5) SRA public assessment reports & innovator.',
      '6) No source available → in-house specification with limits set by ICH Q3B thresholds against the maximum daily dose.',
    ] },
  ],
};
const NOTE_S5 = {
  title: 'Step 5 notes for Supply Chain — screening and initial assessment of API suppliers',
  items: [
    { t: 'Preferred and highly recommended — certification and listing status verification. Supply Chain shall check and record the supplier’s status in the following official sources:', b: [
      `EDQM Certification Database (CEP): confirm that the CEP is valid (not expired, suspended or withdrawn) and that the holder, site, monograph and latest revision match the material offered. Even if CEP grade API is not applicable due to the cost challenge, EP grade API from a CEP holder supplier is preferable. ${LINK.EDQM_CEP}`,
      `EDA list of APIs: confirm that the API and its manufacturer are listed. Confirm the DMF version number (Applicant & Restricted part) and listing validity. ${LINK.EDA_API_LIST}`,
      `FDA List of Type II DMFs Available for Reference: listing shows a completed completeness assessment only. ${LINK.FDA_DMF}`,
    ] },
    { t: 'A positive result in any source makes the supplier a preferred supplier. The absence of a positive result does not exclude the supplier if the mandatory requirements (GMP status and DMF verification) are fully met.' },
    { t: 'Mandatory requirement — GMP status verification: every selected supplier shall provide current evidence of GMP compliance for the manufacturing site. The GMP certificate shall be checked for validity, and its site and scope shall match the material offered.' },
    { t: 'Mandatory requirement — DMF verification: every selected supplier shall hold a DMF for the API with detailed “minimum requirements documents” made by the CTD department. As a summary, sufficient discussion on the following is mandatory:', b: [
      'Full comprehensive characterization 3.2.S.3.1 including as a minimum 5 methods: Elemental Analysis, Infrared, ¹H NMR, ¹³C NMR and Mass spectroscopy.',
      'Full comprehensive discussion on impurities covering all of the following: organic impurities, nitrosamine risk assessment, genotoxic impurity, elemental impurities risk assessment, residual solvents risk assessment.',
      'Recent stability data covering the claimed shelf-life.',
    ] },
    { t: 'Outcome: record the results on the Supplier Initial Assessment Form.' },
  ],
};
const NOTE_S6 = {
  title: 'Step 6 notes for Supply Chain — procurement of the confirmed analytical needs (column, reference standards & brand)',
  items: [
    { t: 'Supply chain shall confirm the EDA acceptable reference standards:', b: [
      'Group 1: official compendial standards (e.g. USP, EDQM) are accepted and exempted from any evaluation or verification procedure.',
      `Group 2 (2A and 2B): listed in the EDA CRM White List — check the list for the supplier name, reference material name, Cat. No. / identification code and certification due date. ${LINK.EDA_CRM}`,
      'CRM (Certified Reference Materials): reference materials supplied by an ISO 17034-accredited supplier within its accreditation scope — and not listed in the EDA CRM White List — considering that Multicare or the supplier will undergo the EDA listing under Group 2A.',
    ] },
  ],
};
// "Other recommendations" shown under every product's workflow (editable in Settings → Settings)
const GENERAL_NOTES = [
  { t: 'Excipients should be fully tested in accordance with the claimed pharmacopeial reference standard:', b: ['In-house supplier verification tests', 'Nitrite and nitrate control for high-risk excipients (nitrosamine control)'] },
  { t: 'Supplier COA for packaging material (original supplier, not Multicare) should be made available.' },
  { t: 'There should be an on-going stability study plan for each product, tracked and followed up by the QA.' },
  { t: 'When preparing a CTD file for a legacy product, aligning with the requirements may take a huge time and resources (site inspection issue).' },
  { t: 'Print-out for the Karl Fischer is a must.' },
];
const NOTE_FORMULA = {
  title: 'Notes on choosing the formula of choice — R&D should keep in mind the following when choosing formula, manufacturing process and pack',
  items: [
    { t: 'Full and intensive desk research started in step 4 is the product safety portal.' },
    { t: 'Brand similarity — if present — is the safest regulatory and scientific path.' },
    { t: 'Adding surfactants in the formula is strongly discouraged; only add it if the brand or RLD contains it.' },
    { t: 'Adding multiple flavours, colorants and antioxidants is strongly discouraged due to many issues:', b: [
      'Safety concern due to the medically unnecessary high load on the patient',
      'Regulatory resistance',
      'Analytical challenge and interference make even the pharmacopeial test method not specific',
    ] },
    { t: `Consider the EDA published list for high-risk APIs that can form nitrosamine impurities (${LINK.EDA_NITROSAMINE}) to choose the formula excipients and manufacturing process conditions that do not trigger nitrosamine formation, and favour the API with the least nitrosamine test results (test results < 10% of the limit).` },
    { t: 'Consider the PSD published in patents and literature, confirmed by trials and testing.' },
    { t: 'Water content limit for solid dosage forms (ODF among them) should be less than 7% in worst scenarios.' },
    { t: 'Consider selecting the manufacturing process that best fits the API nature (heat, moisture and light lability and hygroscopic API) and, if applicable, the brand or RLD manufacturing process.' },
    { t: 'Choice of pack that is brand-similar and suitable according to the API nature (heat, moisture and light lability and hygroscopic API).' },
    { t: 'When establishing the finished product specification you must consider the following:', b: [
      'Description test should be one row containing the full acceptance criteria',
      'Column for reference MUST be divided into 2 columns, one for acceptance criteria and another for the test method',
      'The need for a nitrosamine test by checking the EDA published list for high-risk APIs that can form nitrosamine impurities',
      'The degradation impurities of the API listed in the DMF MUST be considered when listing the impurity profile of the finished product',
      'For dissolution, FDA database or pharmacopeial dissolution conditions must be followed',
      'Water content limit for solid dosage forms (ODF among them) should be less than 7% in worst scenarios',
    ] },
    { t: 'Consider establishing a controlled R&D formulator/product logbook to document R&D trials (formula, process and testing) to support audit and CTD documentation and to confirm full testing and compliance.' },
  ],
};
const NOTE_MET = {
  title: 'Notes for Methodology',
  items: [
    { t: 'Test method MUST be fully described with tips and tricks so that it can be followed with no error.' },
    { t: 'Trials MUST be tested in full (physical, chemical and microbiological) including water content by KF, residual solvents by GC and organic impurities, …etc., according to the properly established proposed finished product specifications.' },
    { t: 'Test method MUST be optimized (TEMPLATE MADE) to specify retention time (RT), column brand and representative chromatograms.' },
    { t: 'For the related impurities test method, check a USP, BP, JP or Int.Ph test method, or a proper forced degradation study and test development must be made.' },
    { t: 'Validation of test method MUST be complete (TEMPLATE MADE).' },
    { t: 'Consider establishing a controlled R&D formulator/product logbook to document R&D trials (formula, process and testing) to support audit and CTD documentation and to confirm full testing and compliance.' },
  ],
};

const PR_API_BULLETS = [
  'Chosen API quality standard (USP/BP)',
  'API criticality points (PSD, nitrosamine results consideration, polymorph and chirality) to guide the supply chain in sourcing the required API specification',
  'Initial chosen API supplier',
];
const PR15_BULLETS = [
  'API Quality standard (USP, BP, …etc.)',
  'Final decision for the API supplier',
  'API criticality points consideration (PSD, etc.)',
  'DMF recommendations',
  'Any other recommendations to be considered in API procurement from the chosen supplier',
];
const RD_TO_QA = [
  'Composition (3.2.P.1)',
  'Manufacturing Formula / batch Formula (3.2.P.3.2)',
  'Manufacturing process (3.2.P.3.3)',
  'Finished product specification (3.2.P.5.1)',
  'Characterization of impurities (3.2.P.5.5)',
  'Justification of specification (3.2.P.5.6)',
];
const MET_TO_QA = ['Test method (3.2.P.5.2)', 'Validation of test method (3.2.P.5.3)'];
const API_DATA = [
  'API Test method (3.2.S.4.2)',
  'API Validation of test method (3.2.S.4.3)',
  'API Batch Analysis (COA) (3.2.S.4.4)',
  'API reference standard data (3.2.S.5)',
  'FPP reference standard data – standardization data (3.2.P.6) (primary reference standard certificate, source API batch COA, working standard certificate, IR spectra) — TEMPLATE MADE in CTD',
];
const QA_REQ_NOTE = 'Note: the QA request shall clarify the purpose of studies, type of studies, duration of studies, API supplier and batch No. of both API and FPP';
const RISK_ASSESSMENT = [
  'QTPPs, CQAs, CMAs, CPPs, excipients and container closure system',
  'RLD qualitative / quantitative composition',
  'BCS class, PSD, polymorphism, chirality / enantiomeric impurities, genotoxic and nitrosamine impurities',
  'API nature properties (hydrolysis, solvent interaction, thermolability, photolability and oxidation liability)',
];
const FINAL_DECISION_API = 'Final decision to API Quality standards and API criticality points to be considered (BP / USP standard, PSD, nitrosamine proposed results – NMT 10% of the limit –, polymorph, chirality) to guide Supply Chain sourcing & QC testing';

// Planning of pilot (step 20) and commercial (step 33) batches — every lettered item of the SOP is a separate output:
// filled (text / upload) by the department named in it, then checked by the Plant Manager or QA (final accountability).
function planningOutputs(kind) {
  const pilot = kind === 'pilot';
  const next = pilot ? [21, 22] : [34];
  const batch = pilot ? 'pilot' : 'commercial';
  const G1 = '1. API Test results conformance';
  const G2 = '2. Material list finalization';
  const G3 = '3. Resources availability';
  const G4 = '4. QA issuing and controlling the documents to the interested departments';
  const G5 = '5. Planned production date';
  const o = (group, t, by, rcpt, extra = {}) => ({ group, t, tf: '7 WD', dept: by, by: [by], checkers: ['PM', 'QA'], rcpt, to: [], ...extra });
  return [
    o(G1, 'RA got CADC approval for API', 'RA', ['PM', 'QA']),
    o(G1, `QC System-Upload contains conformance of the API consignment test results and should contain both: API test results COAs & final statement of conformance or non-conformance (R&D, Supply chain-planning and QA)${pilot ? ' (step 18 outputs)' : ''}`, 'QC', ['PM', 'QA', 'RD', 'SC']),
    o(G2, 'R&D System-Upload material list for QC reviewing API calculation and QA approval', 'RD', ['QC', 'QA', 'PM']),
    o(G2, 'QC System-Upload the reviewed and signed calculation of quantity of API in the material list to the QA', 'QC', ['QA', 'PM']),
    o(G2, 'QA approved and System-Upload material list to the supply chain', 'QA', ['SC', 'PM']),
    o(G3, `Supply chain confirmation of availability of raw materials for the ${batch} batch production`, 'SC', ['PM', 'QA']),
    o(G3, 'Production managers confirmation to plant manager with the manufacturing facility readiness for production of 100,000 unit recommended batch size', 'PROD', ['PM', 'QA']),
    o(G3, `QC conformance of the availability of the ${pilot ? 'pilot' : 'production'} batches analytical testing resources`, 'QC', ['PM', 'QA']),
    o(G4, `QA has approved and System-Upload the master batch record before ${pilot ? 'pilot' : 'production batches'} manufacturing`, 'QA', ['PM', 'PROD']),
    o(G4, 'QA issuing, System-Upload and controlling the documents', 'QA', ['PM', 'PROD', 'RD', 'QC', 'SC']),
    o(G4, 'Confirm the interested departments have only the controlled documents', 'QA', ['PM']),
    o(G4, 'Make shared digital access to the controlled issued documents', 'QA', ['PM', 'PROD', 'RD', 'QC', 'SC']),
    o(G5, `Finally, Plant manager System-Upload to the interested departments (Supply chain, Production, R&D, RA, QA) with the planned ${batch} batch production date`, 'PM', ['SC', 'PROD', 'RD', 'RA', 'QA'], { to: next }),
  ];
}
const PLAN_FINAL = 13; // index of the "planned production date" output in steps 20 and 33

const STEPS = [
  // ───────────── PHASE 1 ─────────────
  { no: 1, phase: 1, name: 'Product Sanction',
    accountable: ['BD'], responsible: [], accText: 'CEO / CEO representative / Business development head',
    deps: [],
    inputs: [{ t: 'Market analysis by business development head', dept: 'BD' }],
    tasks: [{ t: 'Official directives to register a new product' }],
    outputs: [
      { t: 'CEO / CEO representative / business development head System-Upload to R&D: make the desk research and figure out the technical (Formulation, Manufacturing Facility) feasibility of the product', tf: '2 WD', assumed: true, dept: 'BD', rcpt: ['RD'], to: [2] },
      { t: 'CEO / CEO representative / business development head System-Upload to QC: make the desk research and figure out the testing feasibility of the product', tf: '2 WD', assumed: true, dept: 'BD', rcpt: ['QC'], to: [2] },
      { t: 'CEO / CEO representative / business development head System-Upload to Supply chain: make the desk research and figure out the profitability and sourcing feasibility of the product (cost, expected selling price, API raw material availability)', tf: '2 WD', assumed: true, dept: 'BD', rcpt: ['SC'], to: [2] },
    ],
    notes: [] },

  { no: 2, phase: 1, name: 'Technical, Profitability and Sourcing Feasibility',
    accountable: ['RD', 'QC', 'SC'], responsible: [], accText: 'R&D manager & QC Manager & Supply chain manager',
    deps: [1],
    inputs: [
      { t: 'CEO / CEO representative / business development head System-Upload to R&D: make the desk research and figure out the technical (Formulation, Manufacturing Facility) feasibility of the product', from: ['1.1'] },
      { t: 'CEO / CEO representative / business development head System-Upload to QC: make the desk research and figure out the testing feasibility of the product', from: ['1.2'] },
      { t: 'CEO / CEO representative / business development head System-Upload to Supply chain: make the desk research and figure out the profitability and sourcing feasibility of the product (cost, expected selling price, API raw material availability)', from: ['1.3'] },
    ],
    tasks: [
      { t: 'R&D: make the desk research and figure out the technical (Formulation, Manufacturing Facility) feasibility of the product' },
      { t: 'QC: make the desk research and figure out the testing feasibility of the product' },
      { t: 'Supply chain: make the desk research and figure out the profitability and sourcing feasibility of the product (cost, expected selling price, API raw material availability)' },
    ],
    outputs: [
      { t: 'R&D System-Upload to the CEO / CEO representative / Business development head with the conclusion of technical feasibility and statement for:', b: ['API salt', 'Available strengths', 'Dosage form', 'Brand name', 'Reference countries'], tf: '10 WD', dept: 'RD', signoff: ['RD'], rcpt: ['BD'], to: [3] },
      { t: 'QC Manager System-Upload to the CEO / CEO representative / Business development head with the conclusion of testing feasibility', tf: '10 WD', dept: 'QC', signoff: ['QC'], rcpt: ['BD'], to: [3] },
      { t: 'Supply chain manager System-Upload to the CEO / CEO representative / Business development head with the conclusion of profitability and sourcing feasibility', tf: '10 WD', dept: 'SC', signoff: ['SC'], rcpt: ['BD'], to: [3] },
    ],
    notes: [] },

  { no: 3, phase: 1, name: 'Regulatory Feasibility',
    accountable: ['RA'], responsible: [], accText: 'Regulatory Affairs Manager',
    deps: [2],
    inputs: [
      { t: 'R&D System-Upload to the CEO / CEO representative / Business development head with the conclusion of technical feasibility and statement for:', b: ['API salt', 'Available strengths', 'Dosage form', 'Brand name', 'Reference countries'], from: ['2.1'] },
      { t: 'QC Manager System-Upload to the CEO / CEO representative / Business development head with the conclusion of testing feasibility', from: ['2.2'] },
      { t: 'Supply chain manager System-Upload to the CEO / CEO representative / Business development head with the conclusion of profitability and sourcing feasibility', from: ['2.3'] },
    ],
    tasks: [{ t: 'Check eligibility and applicability of registering the product according to the authority regulations.' }],
    outputs: [
      { t: 'RA System-Upload to CEO / CEO representative, Plant Manager, Methodology, QC and R&D Managers containing the Box-approval, which states the approved API salt, dosage form and strength', tf: '2 M', tfLabel: '1–2 months', dept: 'RA', rcpt: ['BD', 'PM', 'MET', 'QC', 'RD'], to: [4] },
    ],
    notes: [] },

  // ───────────── PHASE 2 ─────────────
  { no: 4, phase: 2, name: 'Rigorous Desk Research by R&D formulation, Methodology and QC',
    accountable: ['RD', 'MET', 'QC'], responsible: ['RD', 'MET', 'QC'], accText: 'R&D Manager, Methodology Head and QC Manager',
    deps: [3],
    inputs: [{ t: 'RA System-Upload to Methodology, QC and R&D Managers containing the Box-approval, which states the approved API salt, dosage form and strength', from: ['3.1'] }],
    tasks: [
      { t: 'R&D formulation:', b: [
        'a) Desk research on brand, RLD (public assessment reports, SmPC, leaflet, reviews from stringent authorities), pharmacopoeial monographs (USP, BP, EP, JP, Ph.Int), patents and literature.',
        `b) Prepare the Risk Assessment Report to design composition, manufacturing process, container closure system and propose the initial finished product specification based on the desk research that covers the criticality points of the API and FPP: ${RISK_ASSESSMENT.join('; ')}.`,
        `c) R&D System-Upload to supply chain & QC & Methodology: ${FINAL_DECISION_API}.`,
        'd) Prepare the initial proposed FPS according to the confirmed chosen API quality.',
        `e) Request the RLD (Brand) considering the EDA guidelines for RLD selection ${LINK.EDA_BE_GUIDELINE}`,
      ] },
      { t: 'Methodology:', b: [
        'Recommend API Quality standards according to analytical capabilities, costs and needs at the factory',
        'Recommend analytical needs (columns, reference standards) for FPP',
        'Recommend (after QC and R&D confirmation of the API Quality standards) the proposed organic impurity profile to be listed in the proposed FPS',
      ] },
      { t: 'QC:', b: [
        'Confirm the API Quality standards according to analytical capabilities, costs and needs',
        'Final request of the analytical needs (columns, reference standards) for API and FPP whole lifecycle quantities',
      ] },
    ],
    outputs: [
      { t: 'Methodology Head System-Upload:', b: ['Recommended API Quality standards according to analytical capabilities, costs', 'Recommended analytical needs (*)'], tf: '10 WD', dept: 'MET', signoff: ['MET'], rcpt: ['QC', 'RD'], to: [] },
      { t: 'QC System-Upload the confirmation of the API Quality standards according to analytical capabilities, costs and needs (*)', tf: '10 WD', dept: 'QC', signoff: ['QC'], rcpt: ['RD', 'MET'], to: [] },
      { t: `R&D System-Upload to supply chain & QC & Methodology: ${FINAL_DECISION_API}`, tf: '10 WD', dept: 'RD', signoff: ['RD'], rcpt: ['SC', 'QC', 'MET'], to: [5, 9] },
      { t: 'Methodology recommends the proposed organic impurity profile to be listed in the initial proposed FPS', tf: '10 WD', dept: 'MET', signoff: ['MET'], rcpt: ['RD', 'QC'], to: [] },
      { t: 'R&D System-Upload to QC & Methodology: initial proposed FPS according to the confirmed chosen API quality standards and the organic impurity profile proposed by Methodology, considering the other impurity profile (nitrosamines, enantiomeric impurities, residual solvents) to guide the QC in determining all analytical needs', tf: '10 WD', dept: 'RD', signoff: ['RD'], rcpt: ['QC', 'MET'], to: [] },
      { t: 'QC System-Upload the purchasing request to supply chain listing the analytical needs (Column and Reference standards), considering the quantity for the whole cycle (Methodology, QC and CADC analysis)', tf: '10 WD', dept: 'QC', signoff: ['QC'], rcpt: ['SC'], to: [6] },
      { t: `R&D System-Upload the purchasing request to supply chain listing the RLD (brand) considering the EDA guidelines for RLD selection ${LINK.EDA_BE_GUIDELINE}`, tf: '10 WD', dept: 'RD', signoff: ['RD'], rcpt: ['SC'], to: [6] },
      { t: 'R&D System-Upload the Risk Assessment Report to design composition, manufacturing process and container closure system based on the desk research that covers the criticality points of the API and FPP:', b: RISK_ASSESSMENT, tf: '10 WD', dept: 'RD', signoff: ['RD'], rcpt: ['PM', 'MET', 'QC'], to: [] },
    ],
    notes: [NOTE_ROLES, NOTE_QS, NOTE_AN_QC, NOTE_FPS] },

  // ───────────── PHASE 3 ─────────────
  { no: 5, phase: 3, name: 'API Suppliers Screening and initial Assessment',
    accountable: ['SC'], responsible: [], accText: 'Supply chain manager',
    deps: [4],
    inputs: [{ t: 'R&D System-Upload to supply chain requesting API sourcing, containing statement for:', b: PR_API_BULLETS.slice(0, 2), from: ['4.3'] }],
    tasks: [
      { t: 'Screening and initial assessment of API suppliers (see the step 5 notes):', b: [
        'R&D recommendation for API criticality points (PSD, nitrosamine results consideration, polymorph and chirality)',
        'Check the EDQM for CEP holder suppliers, as CEP grade APIs or EP grade API from a CEP holder supplier are the best',
        'Check the EDA Whitelist for API suppliers',
        'Check the FDA completeness-assessed suppliers for API suppliers',
        'GMP status verification (must be checked)',
        'DMF verification (must be checked)',
      ] },
      { t: 'For each compliant supplier, supply chain should provide API specifications and COA.' },
    ],
    outputs: [
      { t: 'Supply chain System-Upload containing API Specifications and COAs of the screened suppliers sent to R&D and QC for reviewing', tf: '5 WD', dept: 'SC', rcpt: ['RD', 'QC'], to: [7] },
    ],
    notes: [NOTE_S5] },

  { no: 6, phase: 3, name: 'Procurement of the confirmed analytical needs (Column & Reference standards & Brand)',
    accountable: ['SC'], responsible: [], accText: 'Supply chain manager',
    deps: [4],
    inputs: [
      { t: 'QC purchasing request for the analytical needs (Column and Reference standards), considering the quantity for the whole cycle (Methodology, QC and CADC analysis)', from: ['4.6'] },
      { t: `R&D System-Upload the purchasing request to supply chain listing the RLD (brand) considering the EDA guidelines for RLD selection ${LINK.EDA_BE_GUIDELINE}`, from: ['4.7'] },
    ],
    tasks: [
      { t: 'Procurement of the analytical needs (Column and Reference standards) as soon as possible' },
      { t: 'Procurement of the Brand as soon as possible' },
    ],
    outputs: [
      { t: 'Procurement and hand-off to the QC:', b: ['Column', 'Reference standards'], tf: '30 CD', dept: 'SC', rcpt: ['QC'], to: [9] },
      { t: 'Procurement and hand-off to the R&D:', b: ['Brand'], tf: '30 CD', dept: 'SC', rcpt: ['RD', 'MET'], to: [13] },
    ],
    notes: [NOTE_S6] },

  { no: 7, phase: 3, name: 'Initial Evaluation of the Screened API suppliers (API COA and specifications)',
    accountable: ['RD', 'QC'], responsible: [], accText: 'R&D manager & QC Manager',
    deps: [5],
    inputs: [{ t: 'Supply chain System-Upload containing Specifications and COA for the API of different suppliers', from: ['5.1'] }],
    tasks: [{ t: 'Reviewing API Specifications and COAs of the screened suppliers' }],
    outputs: [
      { t: 'Purchasing request signed by both R&D manager & QC Manager, stating:', b: PR_API_BULLETS, tf: '3 WD', dept: 'RD', signoff: ['RD', 'QC'], rcpt: ['SC'], to: [8] },
    ],
    notes: [] },

  { no: 8, phase: 3, name: 'API pre-shipment, DMF and (supplier in-house impurities as enantiomeric impurity – if applicable)',
    accountable: ['SC'], responsible: [], accText: 'Supply chain manager',
    deps: [7],
    inputs: [{ t: 'PR signed by both R&D manager & QC Manager stating:', b: PR_API_BULLETS, from: ['7.1'] }],
    tasks: [{ t: 'Make the following available for the chosen suppliers:', b: ['Pre-shipment', 'DMF (stated checklist)', 'Supplier in-house impurities as enantiomeric impurity (if applicable)'] }],
    outputs: [
      { t: 'Supply chain System-Upload containing the DMF (or download path) to the R&D, QC and CTD for reviewing', tf: '1 W', dept: 'SC', rcpt: ['RD', 'QC', 'CTD'], to: [10] },
      { t: 'Hand-off of the pre-shipment and analytical needs (if any) to the QC with hand-off confirmation', tf: '2 W', dept: 'SC', rcpt: ['QC'], to: [9] },
    ],
    notes: [] },

  { no: 9, phase: 3, name: 'Pre-shipments full testing according to reviewed specification & R&D consideration',
    accountable: ['QC'], responsible: [], accText: 'QC Manager',
    deps: [8, 6],
    inputs: [
      { t: 'Supply chain pre-shipment and analytical needs (if any) hand-off to the QC with hand-off confirmation', from: ['8.2'] },
      { t: 'R&D System-Upload to supply chain & QC: API Quality standards and consideration points (BP / USP standard, PSD, nitrosamine proposed results, polymorph, chirality) to guide Supply Chain sourcing and QC testing', from: ['4.3'] },
      { t: 'Procurement and hand-off to the QC:', b: ['Column', 'Reference standards'], from: ['6.1'] },
    ],
    tasks: [{ t: 'Full testing of the API pre-shipment considering:', b: [
      'Chosen quality standard (USP, BP, …etc.)',
      'Reviewed specification & COA',
      'API criticality consideration points sent from the R&D (PSD, nitrosamine proposed results, polymorph, chirality, …etc.)',
    ] }],
    outputs: [
      { t: 'QC System-Upload to plant manager & R&D manager with statement:', b: ['Ranking of the suppliers according to test results (if more than one)', 'Pre-shipment full test results (COAs) to proceed with final supplier selection'], tf: '5 WD', dept: 'QC', rcpt: ['PM', 'RD'], to: [11, 12] },
    ],
    notes: [] },

  { no: 10, phase: 3, name: 'DMFs reviewing',
    accountable: ['CTD', 'QC', 'RD'], responsible: [], accText: 'CTD Manager, QC Manager, R&D Manager',
    deps: [8],
    inputs: [{ t: 'Supply chain System-Upload containing the DMF (or download path) to the R&D, QC and CTD for reviewing', from: ['8.1'] }],
    tasks: [{ t: 'Initial screening of DMFs, each department scope:', b: [
      'R&D: API criticality points (PSD, nitrosamine results consideration, polymorph and chirality)',
      'QC Manager: API test method check',
      'CTD: Regulatory Authority compliance',
    ] }],
    outputs: [
      { t: 'R&D System-Upload to plant manager containing ranking of the DMFs compliance and content to proceed with final supplier selection', tf: '3 WD', dept: 'RD', signoff: ['RD'], rcpt: ['PM'], to: [11] },
      { t: 'QC System-Upload to plant manager containing ranking of the DMFs compliance and content to proceed with final supplier selection', tf: '3 WD', dept: 'QC', signoff: ['QC'], rcpt: ['PM'], to: [11] },
      { t: 'CTD System-Upload to plant manager containing ranking of the DMFs compliance and content to proceed with final supplier selection', tf: '3 WD', dept: 'CTD', signoff: ['CTD'], rcpt: ['PM'], to: [11] },
    ],
    notes: [] },

  { no: 11, phase: 3, name: 'Ranking and selection of the API suppliers according to the input (pre-shipment test result and DMF screening)',
    accountable: ['PM'], responsible: [], accText: 'Plant manager',
    deps: [9, 10],
    inputs: [
      { t: 'Step 9 output: QC pre-shipment full test results (COAs) and ranking of the suppliers', from: ['9.1'] },
      { t: 'Step 10 outputs: R&D, QC and CTD System-Uploads with ranking of the DMFs compliance and content', from: ['10.1', '10.2', '10.3'] },
    ],
    tasks: [{ t: 'Final selection of the API supplier according to the input (pre-shipment test result and DMF screening) after consultation with the interested departments' }],
    outputs: [
      { t: 'Plant manager System-Upload sent to R&D manager to proceed with the R&D trials and testing, with ranking of the API pre-shipments', tf: '3 WD', dept: 'PM', rcpt: ['RD'], to: [12] },
    ],
    notes: [] },

  { no: 12, phase: 3, name: 'R&D Trials to reach the Formula of choice', loop: true,
    accountable: ['RD'], responsible: [], accText: 'R&D Manager',
    deps: [11],
    inputs: [
      { t: 'Plant manager System-Upload sent to R&D manager to proceed with the R&D trials and testing, with ranking of the API pre-shipments', from: ['11.1'] },
      { t: 'QC System-Upload sent to plant manager & R&D manager with statement:', b: ['Ranking of the suppliers according to test results (if more than one)', 'Pre-shipment full test results (COAs) to proceed with final supplier selection'], from: ['9.1'] },
    ],
    tasks: [
      { t: 'Performing trials targeting:', b: ['Brand similarity and/or reference-based formulation', 'Pre-defined proposed finished product specifications and critical quality attributes'] },
      { t: 'Consider the API criticality points to choose the formula, manufacturing process and pack' },
      { t: 'Consider the notes on choosing the formula of choice (see SOP notes)' },
    ],
    outputs: [
      { t: 'R&D trials hand-off to Methodology, confirming by System-Upload the following:', b: [
        'R&D trial samples (with internal coding)',
        'Updated placebo',
        'Updated composition',
        'Updated proposed finished product specification including all tests (functional excipient if added)',
        'Documented composition and summary manufacturing process for each trial with identifier/code in an analyst logbook, product logbook, …etc.',
      ], tf: '25 WD', dept: 'RD', rcpt: ['MET'], to: [13] },
      { t: 'Steps 12 & 13 are repeated in loop till reaching the formula of choice, then the final documents shall be System-Upload to both plant manager and CTD:', b: ['Final Composition (3.2.P.1)', 'Final Finished product specification (3.2.P.5.1)', 'Manufacturing process (3.2.P.3.3)'], tf: '25 WD', tfLabel: 'same 25 working days', dept: 'RD', rcpt: ['PM', 'CTD'], to: [14], fin: true },
      { t: 'Analyst logbook, product logbook containing trials details', tf: '25 WD', tfLabel: 'same 25 working days', dept: 'RD', rcpt: ['PM', 'CTD'], to: [14], fin: true },
    ],
    notes: [NOTE_FORMULA] },

  { no: 13, phase: 3, name: 'R&D Trials Testing & Stability Testing', loop: true,
    accountable: ['MET'], responsible: [], accText: 'Methodology Head',
    deps: [6, 11],
    inputs: [
      { t: 'Step 6 output: procurement and hand-off of the analytical needs (column & reference standards) and the brand', from: ['6.1', '6.2'] },
      { t: 'Step 12 output: R&D trials hand-off (trial samples, placebo, composition, proposed FPS, documented trials)', from: ['12.1'] },
    ],
    tasks: [
      { t: 'Performing full physical and chemical testing (including most importantly: physical description, water content/LOD, assay, residual solvents by GC, organic impurities, comparative dissolution, etc.) of the trial samples against the received proposed finished product specification till reaching the compliant trial, then proceed to microbiological testing (if applicable)' },
      { t: 'For the compliant formula, stability cabinet entry at accelerated conditions (40°C / 75%) for 3 months with testing at 1, 2 and 3 months' },
      { t: 'Consider the notes for Methodology (see SOP notes)' },
    ],
    outputs: [
      { t: 'System-Upload sent to R&D with the:', b: ['COA for trial', 'COA for each stability point (1, 2 and 3 months)'], tf: '25 WD', dept: 'MET', rcpt: ['RD'], to: [12] },
      { t: 'Documented results of the trials for each trial with unique identifier code in an analyst logbook, product logbook, …etc.', tf: '25 WD', dept: 'MET', rcpt: ['RD'], to: [12] },
      { t: 'Steps 12 & 13 are repeated in loop till reaching the formula of choice, then the final documents shall be System-Upload to both plant manager and CTD:', b: ['COA results for the formula of choice', 'Test method', 'Validation of test method'], tf: '30 WD', tfLabel: '30 working days including above', dept: 'MET', rcpt: ['PM', 'CTD'], to: [14, 15], fin: true },
      { t: 'Analyst logbook, product logbook containing trials details', tf: '30 WD', tfLabel: '30 working days including above', dept: 'MET', rcpt: ['PM', 'CTD'], to: [14, 15], fin: true },
      { t: 'The final documents shall be sent to both plant manager and CTD:', b: ['Stability result tables for 0, 1, 2 and 3 months for the formula of choice'], tf: '3 M', tfLabel: '3 months including above', dept: 'MET', rcpt: ['PM', 'CTD'], to: [14, 15], fin: true, defer: true, deferLabel: 'Needs trial stability data' },
    ],
    notes: [NOTE_MET] },

  { no: 14, phase: 3, name: 'CTD review',
    accountable: ['CTD'], responsible: [], accText: 'CTD Manager',
    deps: [12, 13],
    inputs: [
      { t: 'Outputs of step 12: final composition, finished product specification, manufacturing process and logbooks', from: ['12.2', '12.3'] },
      { t: 'Outputs of step 13: COA of the formula of choice, test method, validation, stability tables and logbooks', from: ['13.3', '13.4', '13.5'] },
    ],
    tasks: [{ t: 'Reviewing the output of step 12 and 13' }],
    outputs: [
      { t: 'System-Upload to plant manager with recommendation for discussion (next step)', tf: '5 WD', dept: 'CTD', rcpt: ['PM'], to: [15] },
    ],
    notes: [] },

  { no: 15, phase: 3, name: 'Plant manager confirmation',
    accountable: ['PM'], responsible: ['SC', 'RD', 'QC', 'MET'], accText: 'Plant manager',
    deps: [14],
    inputs: [
      { t: 'Outputs of step 12 (R&D final documents)', from: ['12.2', '12.3'] },
      { t: 'Outputs of step 13 (Methodology final documents)', from: ['13.3', '13.4', '13.5'] },
      { t: 'Output of step 14 (CTD review recommendation)', from: ['14.1'] },
    ],
    tasks: [{ t: 'Final confirmation of API supplier, composition, FPS, trial COA and stability results, test method and validation of test method after consultation with the interested departments' }],
    outputs: [
      { t: 'Plant manager shall finally confirm the previous steps outputs (12, 13 and 14) were based on sound scientific basis considering CTD review recommendations:', b: ['API quality standards (USP/BP)', 'Selected supplier', 'Composition, FPS, trial COA and stability results', 'Test method and validation of test method'], tf: '3 WD', dept: 'PM', rcpt: ['SC', 'RD', 'QC', 'MET', 'CTD'], to: [16] },
      { t: 'PR request signed by R&D, QC and plant manager (copy shall be sent to QC and R&D) stating the following:', b: [...PR15_BULLETS, 'Attached the approved supplier API specifications and COA'], tf: '3 WD', dept: 'PM', rcpt: ['SC', 'QC', 'RD'], to: [16] },
      { t: 'R&D sent the following to the QA:', b: RD_TO_QA, tf: '3 WD', dept: 'RD', rcpt: ['QA'], to: [17] },
      { t: 'Methodology sent the following to the QA:', b: MET_TO_QA, tf: '3 WD', dept: 'MET', rcpt: ['QA'], to: [17] },
      { t: 'QA shall verify that R&D Formulation and Methodology document the trials details in the analyst logbook, product logbook', tf: '3 WD', dept: 'QA', rcpt: ['PM'], to: [] },
    ],
    notes: [] },

  { no: 16, phase: 3, name: 'API consignment procurement',
    accountable: ['SC'], responsible: [], accText: 'Supply chain manager',
    deps: [15],
    inputs: [{ t: 'Step 15 output: PR request signed by R&D, QC and plant manager', b: PR15_BULLETS, from: ['15.2'] }],
    tasks: [{ t: 'API procurement from the chosen supplier considering the received considerations and recommendations in the PR, and procurement of API with different lots.' }],
    outputs: [
      { t: 'Supply chain System-Upload to RA, QC and plant manager confirming the delivery of the API consignment to proceed with:', b: ['QC testing of the API consignment', 'Regulatory procedures'], tf: '1.5 M', dept: 'SC', rcpt: ['RA', 'QC', 'PM'], to: [18, 19] },
    ],
    notes: [] },

  { no: 17, phase: 3, name: 'QA document issuing and control',
    accountable: ['QA'], responsible: [], accText: 'QA Manager',
    deps: [15],
    inputs: [
      { t: 'Step 15 output — R&D sent the following to the QA:', b: RD_TO_QA, from: ['15.3'] },
      { t: 'Step 15 output — Methodology sent the following to the QA:', b: MET_TO_QA, from: ['15.4'] },
    ],
    tasks: [
      { t: 'Issuing and controlling the documents concerned' },
      { t: 'Confirm the departments have only the controlled documents' },
      { t: 'Make shared digital access to the controlled issued documents' },
    ],
    outputs: [
      { t: 'Issuing and controlling the documents:', b: [...RD_TO_QA, ...MET_TO_QA], tf: '5 WD', dept: 'QA', rcpt: ['RD', 'MET', 'QC', 'PROD', 'PM'], to: [20] },
      { t: 'Confirm the interested departments have only the controlled documents', tf: '5 WD', dept: 'QA', rcpt: ['PM'], to: [20] },
      { t: 'Make shared digital access to the controlled issued documents', tf: '5 WD', dept: 'QA', rcpt: ['RD', 'MET', 'QC', 'PROD', 'PM'], to: [20] },
      { t: 'QA shall verify that R&D Formulation and Methodology document the trials details in the analyst logbook, product logbook', tf: '5 WD', dept: 'QA', rcpt: ['PM', 'RD', 'MET'], to: [20] },
    ],
    notes: [] },

  { no: 18, phase: 3, name: 'API consignment testing',
    accountable: ['QC'], responsible: [], accText: 'QC Manager',
    deps: [16],
    inputs: [{ t: 'Step 16 output: Supply chain System-Upload sent to RA, QC and plant manager confirming the delivery of the API consignment, to proceed with:', b: ['QC testing of the API consignment', 'Regulatory procedures'], from: ['16.1'] }],
    tasks: [
      { t: 'Full testing of the API consignment considering the previous considerations officially listed in the PR from step 15:', b: [...PR15_BULLETS, 'Consider the PSD (if applicable)'] },
      { t: 'Documentation of the Multicare API testing data:', b: API_DATA },
      { t: 'On-time testing and results sharing with the interested departments are highly important' },
      { t: 'Review and sign the calculation of API quantity in the material list' },
    ],
    outputs: [
      { t: 'QC System-Upload containing conformance of the API consignment test results — should contain both the API test results COAs & final statement of conformance or non-conformance. To:', b: ['RA to proceed with regulatory measures for API release and CADC samples', 'R&D, Supply chain-planning, Plant Manager and QA to proceed with planning pilot batch production'], tf: '5 WD', dept: 'QC', rcpt: ['RA', 'RD', 'SC', 'PM', 'QA'], to: [19, 20] },
      { t: 'Send the document of Multicare API testing data to the QA for issuing:', b: API_DATA, tf: '15 WD', dept: 'QC', rcpt: ['QA'], to: [20] },
    ],
    notes: [] },

  { no: 19, phase: 3, name: 'RA procedures for API (EDA inspector consignment release and CADC samples)',
    accountable: ['RA'], responsible: [], accText: 'RA Manager',
    deps: [18],
    inputs: [
      { t: 'Step 16 output: Supply chain System-Upload to RA, QC and plant manager confirming the delivery of the API consignment, to proceed with:', b: ['Regulatory procedures', 'QC testing of the API consignment'], from: ['16.1'] },
      { t: 'Step 18 output: QC System-Upload to the RA, R&D and plant manager containing full testing results of the API consignment containing both:', b: ['API test results COAs', 'Final statement of conformance or non-conformance'], from: ['18.1'] },
    ],
    tasks: [{ t: 'Proceed with EDA regulations regarding coordination with the EDA inspector to open the API consignment and draw samples for analysis at CADC' }],
    outputs: [
      { t: 'RA manager System-Upload confirmation to plant manager with finishing the EDA inspection procedures for API consignment opening', tf: '3 WD', dept: 'RA', rcpt: ['PM'], to: [20] },
      { t: 'Samples sent to CADC', tf: '1 M', dept: 'RA', rcpt: ['PM', 'QC'], to: [] },
      { t: 'CADC Approval', tf: '2 M', dept: 'RA', rcpt: ['PM', 'QC', 'QA'], to: [20] },
    ],
    notes: [] },

  // ───────────── PHASE 4 ─────────────
  { no: 20, phase: 4, name: 'Planning the Pilot batch production',
    accountable: ['PM', 'QA'], responsible: ['SC', 'PROD', 'RD', 'RA', 'QA'], accText: 'Plant manager, QA',
    deps: [17, 19],
    inputs: [
      { t: 'RA manager System-Upload confirmation to plant manager with finishing the EDA inspection procedures for API consignment opening (output of step 19)', from: ['19.1'] },
    ],
    tasks: [{ t: 'Plant manager co-ordinates with the interested departments (Supply chain, Production, R&D, RA, QA) the planned pilot batch production date' }],
    outputs: planningOutputs('pilot'),
    notes: [] },

  { no: 21, phase: 4, name: 'RA procedure for pilot batch production',
    accountable: ['RA'], responsible: [], accText: 'RA manager',
    deps: [20],
    inputs: [{ t: 'Step 20 output: Plant manager System-Upload to the interested departments (Supply chain, Production, R&D, RA, QA) with the planned pilot batch production date', from: [`20.${PLAN_FINAL}`] }],
    tasks: [{ t: 'RA proceeds with EDA regulatory procedures for pilot batch production and inspector attendance' }],
    outputs: [
      { t: 'RA manager sends confirmation System-Upload to plant manager and QA with the completeness of EDA regulatory procedures on the planned production date', tf: '1 W', dept: 'RA', rcpt: ['PM', 'QA'], to: [22] },
    ],
    notes: [] },

  { no: 22, phase: 4, name: 'Pilot batch production',
    accountable: ['PM', 'QA'], responsible: ['SC', 'PROD', 'RD', 'QA'], accText: 'Plant manager, QA',
    deps: [21],
    inputs: [
      { t: 'Step 20 output: planned pilot batch production date', from: [`20.${PLAN_FINAL}`] },
      { t: 'Step 21 output: RA confirmation of completeness of EDA regulatory procedures', from: ['21.1'] },
    ],
    tasks: [
      { t: 'R&D: Technology transfer R&D → Production transfer protocol and report.' },
      { t: 'QA: Follow the completeness of the pilot batch production' },
    ],
    outputs: [
      { t: 'QA System-Upload to EDA inspector report for attending pilot batches production', tf: '1 WD', dept: 'QA', rcpt: ['PM'], to: [] },
      { t: 'QA System-Upload informing the QC & Methodology departments to proceed with pilot batch testing and method transfer (both teams shall attend the pilot batch testing)', tf: '1 WD', dept: 'QA', rcpt: ['QC', 'MET'], to: [23] },
      { t: 'QA System-Upload informing RA to proceed with EDA inspector procedures for CADC samples withdrawal, clarifying the following note: “pilot batch testing COAs conformance is a must before proceeding with CADC samples hand-off”', tf: '1 WD', dept: 'QA', rcpt: ['RA'], to: [26] },
      { t: 'QA System-Upload informing RA to proceed with clarification of the BE / comparative required study type and site from the authority', tf: '1 WD', dept: 'QA', rcpt: ['RA'], to: [25] },
      { t: 'QA action for retained samples storage', tf: '1 WD', dept: 'QA', rcpt: ['PM'], to: [] },
      { t: 'QA System-Upload & samples hand-off to Stability requesting to proceed with stability study cabinet entry', b: [QA_REQ_NOTE], tf: '5 WD', dept: 'QA', rcpt: ['STAB'], to: [24] },
      { t: 'QA preparation of batch records and reviewing the alignment with the previously issued documents (composition, manufacturing formula, manufacturing process, …etc.)', tf: '10 WD', dept: 'QA', rcpt: ['PM'], to: [] },
    ],
    notes: [] },

  // ───────────── PHASE 5 ─────────────
  { no: 23, phase: 5, name: 'Pilot Batch testing & Method Transfer',
    accountable: ['QA', 'QC'], responsible: ['QC', 'MET', 'QA'], accText: 'QA Manager & QC Manager',
    deps: [22],
    inputs: [{ t: 'QA System-Upload informing the QC & Methodology departments to proceed with pilot batch testing and method transfer (both teams shall attend the pilot batch testing)', from: ['22.2'] }],
    tasks: [{ t: 'Key tasks:', b: [
      'Method transfer',
      'Pilot batch full testing (physical, chemical and microbiological) according to the issued finished product specification and test method',
      'Make the CTD relevant documents',
    ] }],
    outputs: [
      { t: 'QC System-Upload the testing COAs of the pilot batches to QA, stability and plant manager', tf: '5 WD', dept: 'QC', rcpt: ['QA', 'STAB', 'PM'], to: [24] },
      { t: 'QA System-Upload to the RA to state the pilot batch conformance and ask to proceed with CADC samples withdrawal and analysis', tf: '2 WD', dept: 'QA', rcpt: ['RA'], to: [26] },
    ],
    notes: [] },

  { no: 24, phase: 5, name: 'Initiate the stability studies',
    accountable: ['QA'], responsible: ['STAB', 'QA'], accText: 'QA',
    deps: [22],
    inputs: [
      { t: 'QA samples hand-off and request to the stability department to proceed with stability study cabinet entry (output of step 22)', b: [QA_REQ_NOTE], from: ['22.6'] },
      { t: 'QC System-Upload the testing COAs of the pilot batches to QA, stability and plant manager (output of step 23)', from: ['23.1'] },
    ],
    tasks: [{ t: 'Key tasks:', b: [
      'Stability study cabinet entry',
      'Confirm the receipt of pilot batches testing COAs',
      'Performing the stability studies according to the QA request referring to the established CTD documentation',
      'Authority template is a MUST',
    ] }],
    outputs: [
      { t: 'Stability System-Upload confirmation to the QA:', b: ['Confirm the stability samples entry in the cabinet', 'Confirm the receipt of pilot batches testing COAs'], tf: '1 W', dept: 'STAB', rcpt: ['QA'], to: [] },
      { t: '6 months accelerated and long-term stability data', tf: '7 M', dept: 'STAB', rcpt: ['CTD', 'QA', 'PM'], to: [29], defer: true, deferLabel: 'Needs 6-month stability data' },
    ],
    notes: [] },

  { no: 25, phase: 5, name: 'Clarification of the required study type (BE / comparative) from the authority',
    accountable: ['RA'], responsible: ['RA'], accText: 'RA Manager',
    deps: [22],
    inputs: [{ t: 'QA System-Upload informing RA to proceed with clarification of the BE / comparative required study type and site from the authority (output of step 22)', from: ['22.4'] }],
    tasks: [{ t: 'Proceed with the regulatory procedures to clarify the required study type and site' }],
    outputs: [
      { t: 'RA System-Upload to Methodology, QA and plant manager containing the authority clarification for the required study type and site (input of step 27 or 28)', tf: '1 M', dept: 'RA', rcpt: ['MET', 'QA', 'PM'], to: [27, 28] },
    ],
    notes: [] },

  { no: 26, phase: 5, name: 'CADC analysis',
    accountable: ['RA'], responsible: ['RA'], accText: 'RA manager',
    deps: [23],
    inputs: [
      { t: 'QA System-Upload informing the RA to proceed with EDA inspector procedures for CADC samples withdrawal, clarifying the note: pilot batch testing COAs conformance is a must before proceeding with CADC samples hand-off (output of step 22)', from: ['22.3'] },
      { t: 'QA System-Upload to the RA stating the pilot batch conformance and asking to proceed with CADC samples withdrawal and analysis (output of step 23)', from: ['23.2'] },
      { t: 'QC hand-off to RA of the CADC analytical needs (column and reference standards)', dept: 'QC' },
    ],
    tasks: [{ t: 'Proceed with the regulatory procedures for the CADC analysis' }],
    outputs: [
      { t: 'CADC conformance report sent to QA and CTD', tf: '3 M', dept: 'RA', rcpt: ['QA', 'CTD'], to: [29] },
    ],
    notes: [] },

  { no: 27, phase: 5, name: 'Comparative study in the factory for additional strength biowaivers', conditional: 'According to step 25 — performed only if required by the authority',
    accountable: ['QA', 'MET'], responsible: ['MET', 'QA'], accText: 'QA Manager and Methodology Manager',
    deps: [25],
    inputs: [{ t: 'RA System-Upload to Methodology, QA and plant manager containing the authority clarification for the required study type and site (output of step 25)', from: ['25.1'] }],
    tasks: [{ t: 'Comparative dissolution using the RLD / Brand according to the authority request' }],
    outputs: [
      { t: 'Comparative dissolution study report according to the authority guidelines and template sent to the RA & R&D & CTD', tf: '1 W', dept: 'MET', rcpt: ['RA', 'RD', 'CTD'], to: [29] },
    ],
    notes: [] },

  { no: 28, phase: 5, name: 'BE / comparative study (Third party)', conditional: 'According to step 25 — performed only if required by the authority',
    accountable: ['QA'], responsible: ['QA', 'RA'], accText: 'QA',
    deps: [25],
    inputs: [{ t: 'RA System-Upload to Methodology, QA and plant manager containing the authority clarification for the required study type and site (output of step 25)', from: ['25.1'] }],
    tasks: [
      { t: 'Consider checking the following to choose the proper BE centre after confirmation with the plant manager:', b: ['Cost of GCC vs non-GCC BE study', 'Product opportunity for export'] },
      { t: 'Proceed with the third-party procedures, contract, sampling handling and follow-up' },
    ],
    outputs: [
      { t: 'QA System-Upload decision of GCC or non-GCC BE centre and study design', tf: '1 W', dept: 'QA', rcpt: ['PM', 'BD'], to: [] },
      { t: 'QA System-Upload to RA and plant manager stating finalizing procedures and samples handling and the expected date for receiving the study report', tf: '2 W', dept: 'QA', rcpt: ['RA', 'PM'], to: [] },
      { t: 'Receiving the third-party BE / comparative study', tf: '4 M', dept: 'QA', rcpt: ['PM', 'RA', 'CTD'], to: [30], defer: true, deferLabel: 'Needs BE study data', releaseTo: [] }, // flag only: step 30 waits for completion
    ],
    notes: [] },

  // ───────────── PHASE 6 ─────────────
  { no: 29, phase: 6, name: 'CTD File preparation',
    accountable: ['CTD'], responsible: [], accText: 'CTD manager',
    deps: [23, 24, 27],
    inputs: [
      { t: 'RA priority list, which is based on submission deadlines, market need, …etc.', dept: 'RA' },
      { t: 'Step 24 output: 6 months accelerated and long-term stability data', from: ['24.2'] },
      { t: 'Step 26 output: CADC conformance report', from: ['26.1'] },
      { t: 'Step 27 output: comparative dissolution study report (if required by the authority)', from: ['27.1'] },
    ],
    tasks: [
      { t: 'Compiling and reviewing the relevant CTD sections from all interested departments according to the responsibilities stated in the CTD SOPs (see annex I)' },
      { t: 'Confirm that the departments follow the CTD SOPs (standardized templates) for preparing the CTD file documents' },
      { t: 'Technical guidance and consultation' },
    ],
    outputs: [
      { t: 'CTD file ready for submission after departments deliver their documents according to the responsibilities listed in annex I', tf: '20 WD', dept: 'CTD', rcpt: ['RA', 'PM'], to: [30] },
    ],
    notes: [] },

  { no: 30, phase: 6, name: 'Regulatory submission (One submission)',
    accountable: ['RA', 'CTD'], responsible: [], accText: 'RA and CTD manager',
    deps: [23, 24, 25, 26, 27, 28, 29],
    inputs: [
      { t: 'Step 29 output: CTD file ready for submission', from: ['29.1'] },
    ],
    tasks: [{ t: 'Regulatory file submission (one submission)' }],
    outputs: [
      { t: 'RA System-Upload to QA and plant manager containing the Registration License', tf: '3 M', dept: 'RA', signoff: ['RA'], rcpt: ['QA', 'PM', 'BD'], to: [] },
      { t: 'CTD System-Upload to QA, containing the final CTD file to make a controlled QA version', tf: '5 WD', tfLabel: '5 working days after license', rel: 1, dept: 'CTD', signoff: ['CTD'], rcpt: ['QA'], to: [31] },
    ],
    notes: [] },

  { no: 31, phase: 6, name: 'QA controlled CTD File',
    accountable: ['QA'], responsible: [], accText: 'QA manager',
    deps: [30],
    inputs: [{ t: 'CTD System-Upload to QA, containing the final CTD file (or its share path) to make a controlled QA version (output of step 30)', from: ['30.2'] }],
    tasks: [{ t: 'Issuing a QA controlled CTD file considering reviewing the previously issued documents, making new versions and document control across all departments' }],
    outputs: [
      { t: 'Reviewing the previously issued documents and making new versions and document control across all departments', tf: '15 WD', dept: 'QA', rcpt: ['RD', 'MET', 'QC', 'PROD', 'SC', 'RA', 'CTD', 'PM'], to: [] },
      { t: 'System-Upload the final QA-controlled CTD file', tf: '15 WD', dept: 'QA', rcpt: ['CTD', 'RA', 'PM'], to: [] },
    ],
    notes: [] },

  // ───────────── PHASE 7 ─────────────
  { no: 32, phase: 7, name: 'Decision of initiating the commercial batches',
    accountable: ['BD'], responsible: [], accText: 'CEO / CEO representative',
    deps: [31],
    inputs: [{ t: 'Market need', dept: 'BD' }],
    tasks: [{ t: 'Give the directive to initiate the production of the commercial batches' }],
    outputs: [
      { t: 'CEO representative System-Upload to the plant manager to proceed with commercial batches production', tf: '5 WD', assumed: true, dept: 'BD', rcpt: ['PM'], to: [33] },
    ],
    notes: [] },

  { no: 33, phase: 7, name: 'Planning the commercial batches production',
    accountable: ['PM', 'QA'], responsible: ['SC', 'PROD', 'RA', 'QA'], accText: 'Plant manager, QA',
    deps: [32],
    inputs: [
      { t: 'CEO representative System-Upload to the plant manager to proceed with commercial batches production', from: ['32.1'] },
      { t: 'RA manager System-Upload confirmation to plant manager with finishing the EDA inspection procedures for API consignment opening (if applicable)', dept: 'RA' },
      { t: 'Supply chain manager System-Upload confirmation to plant manager with the availability of raw materials for the production of commercial batches', dept: 'SC' },
      { t: 'Production managers System-Upload confirmation to plant manager with the manufacturing facility readiness for production of 100,000 units recommended batch size', dept: 'PROD' },
      { t: 'QC shall send the reviewed and signed calculation of quantity of API in the material list to the supply chain', dept: 'QC' },
    ],
    tasks: [{ t: 'Plant manager co-ordinates and plans with the interested departments (Supply chain, Production, RA, QA) the commercial batch production date' }],
    outputs: planningOutputs('commercial'),
    notes: [] },

  { no: 34, phase: 7, name: 'Production of the 1st 3 commercial batches',
    accountable: ['PM', 'QA'], responsible: ['SC', 'PROD', 'QA'], accText: 'Plant manager, QA',
    deps: [33],
    inputs: [{ t: 'Plant manager / QA System-Upload to the interested departments (Supply chain, Production, RA, QA) with the planned commercial batch production date (output of step 33)', from: [`33.${PLAN_FINAL}`] }],
    tasks: [{ t: 'Follow the completeness of the commercial batches production' }],
    outputs: [
      { t: 'QA System-Upload to EDA inspector report for attending commercial batches production', tf: '1 WD', dept: 'QA', rcpt: ['PM'], to: [] },
      { t: 'QA System-Upload informing the QC to proceed with commercial batch testing', tf: '1 WD', dept: 'QA', rcpt: ['QC'], to: [] },
      { t: 'QA System-Upload informing RA to proceed with EDA inspector procedures for CADC samples withdrawal, clarifying the following note: “commercial batch testing COAs conformance is a must before proceeding with CADC samples hand-off”', tf: '1 WD', dept: 'QA', rcpt: ['RA'], to: [] },
      { t: 'QA action for retained samples storage', tf: '1 WD', dept: 'QA', rcpt: ['PM'], to: [] },
      { t: 'QA System-Upload & samples hand-off to QC for process validation of the first 3 commercial batches under an approved PV protocol and report', tf: '5 WD', dept: 'QA', rcpt: ['QC'], to: [35] },
      { t: 'QA System-Upload & samples hand-off to Stability requesting to proceed with stability study cabinet entry', b: [QA_REQ_NOTE], tf: '5 WD', dept: 'QA', rcpt: ['STAB'], to: [35] },
      { t: 'QA preparation of batch records and reviewing the alignment with the previously issued documents (composition, manufacturing formula, manufacturing process, …etc.)', tf: '10 WD', dept: 'QA', rcpt: ['PM'], to: [] },
    ],
    notes: [] },

  { no: 35, phase: 7, name: 'Initiate the stability studies & Process Validation for the 1st 3 production batches',
    accountable: ['QA'], responsible: ['STAB', 'QC', 'QA'], accText: 'QA',
    deps: [34],
    inputs: [
      { t: 'QA System-Upload & samples hand-off to QC for process validation of the first 3 commercial batches under an approved PV protocol and report (output of step 34)', from: ['34.5'] },
      { t: 'QA System-Upload & samples hand-off to Stability requesting to proceed with stability study cabinet entry (output of step 34)', b: [QA_REQ_NOTE], from: ['34.6'] },
    ],
    tasks: [
      { t: 'Stability and QA:', b: [
        'Stability study cabinet entry',
        'Confirm the receipt of commercial batches testing COAs',
        'Performing the stability studies according to the QA request referring to the established CTD documentation',
      ] },
      { t: 'QC and QA:', b: ['Process validation: run the first 3 commercial batches under an approved PV protocol and report'] },
    ],
    outputs: [
      { t: 'Stability System-Upload confirmation to the QA:', b: ['Confirm the stability samples entry in the cabinet', 'Confirm the receipt of commercial batches testing COAs'], tf: '1 M', tfLabel: '1 month for initialization of stability studies and preparing the PV report', dept: 'STAB', rcpt: ['QA'], to: [] },
      { t: 'QA System-Upload the process validation report for the first 3 commercial batches', tf: '1 M', tfLabel: '1 month for initialization of stability studies and preparing the PV report', dept: 'QA', rcpt: ['PM', 'QC', 'BD'], to: [] },
    ],
    notes: [] },
];

// ---------- Constant list of SOP-controlled documents ----------
// steps: where a version can be uploaded · required: the step that cannot be completed without it · out: the output it belongs to
const QA_DOCS = [
  'Composition (3.2.P.1)',
  'Manufacturing Formula / batch Formula (3.2.P.3.2)',
  'Manufacturing process (3.2.P.3.3)',
  'Finished product specification (3.2.P.5.1)',
  'Characterization of impurities (3.2.P.5.5)',
  'Justification of specification (3.2.P.5.6)',
  'Test method (3.2.P.5.2)',
  'Validation of test method (3.2.P.5.3)',
  'API Test method (3.2.S.4.2)',
  'API Validation of test method (3.2.S.4.3)',
  'API Batch Analysis (COA) (3.2.S.4.4)',
  'API reference standard data (3.2.S.5)',
  'FPP reference standard data – standardization data (3.2.P.6) (primary RS certificate, source API batch COA, working standard certificate, IR spectra)',
];

const DOC_SECTIONS = ['R&D – Formulation', 'R&D – Methodology', 'QC', 'Stability', 'QA – Controlled documents', 'RA'];

const DOC_TYPES = [
  { section: 'R&D – Formulation', name: 'Risk Assessment Report (composition, manufacturing process, container closure system — API & FPP criticality points)', steps: [4], out: 8 },
  { section: 'R&D – Formulation', name: 'Initial proposed FPS according to the confirmed chosen API quality standards and the proposed organic impurity profile', steps: [4], out: 5 },
  { section: 'R&D – Formulation', name: 'Purchasing request listing the RLD (brand) considering the EDA guidelines for RLD selection', steps: [4], out: 7 },
  { section: 'R&D – Formulation', name: 'Purchasing request signed by R&D & QC Managers: chosen API quality standard (USP/BP), API criticality points (PSD, nitrosamine, polymorph, chirality), initial chosen API supplier', steps: [7], out: 1, alsoIn: ['QC'] },
  { section: 'R&D – Formulation', name: 'Final Composition (3.2.P.1)', steps: [12], out: 2 },
  { section: 'R&D – Formulation', name: 'Final Finished product specification (3.2.P.5.1)', steps: [12], out: 2 },
  { section: 'R&D – Formulation', name: 'Manufacturing process (3.2.P.3.3)', steps: [12], out: 2 },
  { section: 'R&D – Methodology', name: 'COA results for the formula of choice', steps: [13], out: 3 },
  { section: 'R&D – Methodology', name: 'Test method', steps: [13], out: 3 },
  { section: 'R&D – Methodology', name: 'Validation of test method', steps: [13], out: 3 },
  { section: 'R&D – Methodology', name: 'Stability result tables for 0, 1, 2 and 3 months for the formula of choice', steps: [13], out: 5 },
  { section: 'QC', name: 'Purchasing request to supply chain for the analytical needs (Column and Reference standards) — quantity for the whole cycle (Methodology, QC and CADC analysis)', steps: [4], out: 6 },
  { section: 'QC', name: 'Pre-shipment full test results (COAs)', steps: [9], out: 1 },
  { section: 'QC', name: 'API consignment test results COAs', steps: [18], out: 1 },
  { section: 'QC', name: '3 pilot batches testing COAs', steps: [23], out: 1 },
  { section: 'Stability', name: '3.2.P.8.3 Stability data of primary batches', steps: [24], out: 2 },
  ...QA_DOCS.map((n, i) => ({ section: 'QA – Controlled documents', name: n, steps: [17, 20], required: i < 8 ? 17 : 20, out: i < 8 ? 1 : 10 })),
  { section: 'RA', name: 'Box Approval / preliminary registration approval', steps: [3], out: 1 },
  { section: 'RA', name: 'API CADC Approval', steps: [19], out: 3 },
  { section: 'RA', name: 'FPP CADC Approval', steps: [26], out: 1 },
  { section: 'RA', name: 'Clarification of the required study type (BE / comparative) from the authority', steps: [25], out: 1 },
];

// Egypt official holidays 2026 (indicative — the admin must review/adjust in Control → Holidays)
const HOLIDAYS_SEED = [
  ['2026-01-07', 'Coptic Christmas'],
  ['2026-01-25', 'Revolution Day / Police Day'],
  ['2026-03-19', 'Eid al-Fitr (est.)'], ['2026-03-20', 'Eid al-Fitr (est.)'], ['2026-03-22', 'Eid al-Fitr (est.)'],
  ['2026-04-12', 'Coptic Easter'], ['2026-04-13', 'Sham El-Nessim'],
  ['2026-04-25', 'Sinai Liberation Day'],
  ['2026-05-01', 'Labour Day'],
  ['2026-05-26', 'Arafat Day (est.)'], ['2026-05-27', 'Eid al-Adha (est.)'], ['2026-05-28', 'Eid al-Adha (est.)'], ['2026-05-31', 'Eid al-Adha (est.)'],
  ['2026-06-16', 'Islamic New Year (est.)'],
  ['2026-06-30', 'June 30 Revolution'],
  ['2026-07-23', 'July 23 Revolution'],
  ['2026-08-25', 'Prophet\'s Birthday (est.)'],
  ['2026-10-06', 'Armed Forces Day'],
];

const SOP_REVISION = 5; // bump when the seeded SOP content changes (see migrations in db.js)

module.exports = {
  PLAN_FINAL, SOP_REVISION, GENERAL_NOTES, LINK,
  DEPARTMENTS, PHASES, FLOW, STEPS, DOC_TYPES, DOC_SECTIONS, HOLIDAYS_SEED,
  LICENSE_STEP, LICENSE_OUTPUT, COMMERCIAL_STEP, COMMERCIAL_OUTPUT,
};
