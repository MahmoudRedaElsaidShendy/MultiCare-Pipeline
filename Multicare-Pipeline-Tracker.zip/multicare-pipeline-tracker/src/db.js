'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');
const SOP = require('./sop-data');

function now() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
function today() { return now().slice(0, 10); }

function hashPassword(pw, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(pw), salt, 64).toString('hex');
  return { hash, salt };
}
function checkPassword(pw, salt, hash) {
  const h = crypto.scryptSync(String(pw), salt, 64);
  const b = Buffer.from(hash, 'hex');
  return b.length === h.length && crypto.timingSafeEqual(h, b);
}

// uploaded documents live on disk (data/files/<product>/…), the database keeps their metadata
const safeName = (s) => String(s || 'file').replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').slice(-120);
function newFilePath(dataDir, pid, filename) {
  const ext = (path.extname(filename || '') || '').slice(0, 12).replace(/[^.\w-]/g, '');
  const rel = path.join('files', String(pid), `${crypto.randomUUID()}${ext}`);
  fs.mkdirSync(path.join(dataDir, 'files', String(pid)), { recursive: true });
  return rel;
}

function open(dataDir) {
  fs.mkdirSync(dataDir, { recursive: true });
  const file = path.join(dataDir, 'sop-tracker.sqlite');
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000; PRAGMA synchronous = NORMAL; PRAGMA temp_store = MEMORY; PRAGMA cache_size = -32000; PRAGMA mmap_size = 134217728;');
  db.exec(`
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
  CREATE TABLE IF NOT EXISTS departments (code TEXT PRIMARY KEY, name TEXT NOT NULL, active INTEGER DEFAULT 1, sort INTEGER DEFAULT 0);
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE COLLATE NOCASE, full_name TEXT,
    dept TEXT NOT NULL REFERENCES departments(code), role TEXT NOT NULL DEFAULT 'user',
    pw_hash TEXT NOT NULL, pw_salt TEXT NOT NULL, active INTEGER DEFAULT 1, must_change INTEGER DEFAULT 0,
    created_at TEXT, last_login TEXT);
  CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at TEXT, expires INTEGER);
  CREATE TABLE IF NOT EXISTS perms (user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, step_no INTEGER NOT NULL, level TEXT NOT NULL, PRIMARY KEY (user_id, step_no));
  CREATE TABLE IF NOT EXISTS holidays (date TEXT PRIMARY KEY, name TEXT);
  CREATE TABLE IF NOT EXISTS step_defs (
    id INTEGER PRIMARY KEY AUTOINCREMENT, step_no INTEGER NOT NULL, product_id INTEGER, effective_from TEXT NOT NULL,
    data TEXT NOT NULL, created_by TEXT, created_at TEXT, note TEXT);
  CREATE INDEX IF NOT EXISTS ix_stepdefs ON step_defs(step_no, product_id, effective_from);
  CREATE TABLE IF NOT EXISTS doc_types (id INTEGER PRIMARY KEY AUTOINCREMENT, section TEXT NOT NULL, name TEXT NOT NULL, steps TEXT NOT NULL, also_in TEXT, sort INTEGER DEFAULT 0, active INTEGER DEFAULT 1);
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, api TEXT, dosage TEXT, markets TEXT,
    start_date TEXT NOT NULL, status TEXT DEFAULT 'active', created_by TEXT, created_at TEXT, notes TEXT);
  CREATE TABLE IF NOT EXISTS psteps (
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE, step_no INTEGER NOT NULL,
    started_at TEXT, started_by TEXT, completed_at TEXT, completed_by TEXT,
    na_at TEXT, na_by TEXT, na_reason TEXT, due_override TEXT, due_override_reason TEXT,
    iterations INTEGER DEFAULT 0, last_state TEXT, overdue_notified INTEGER DEFAULT 0,
    PRIMARY KEY (product_id, step_no));
  CREATE TABLE IF NOT EXISTS poutputs (
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE, step_no INTEGER NOT NULL, idx INTEGER NOT NULL,
    state TEXT NOT NULL, at TEXT, by TEXT, reason TEXT, PRIMARY KEY (product_id, step_no, idx));
  CREATE TABLE IF NOT EXISTS pinputs (
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE, step_no INTEGER NOT NULL, idx INTEGER NOT NULL,
    at TEXT, by TEXT, PRIMARY KEY (product_id, step_no, idx));
  CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    step_no INTEGER, output_idx INTEGER, doc_type_id INTEGER, version INTEGER NOT NULL DEFAULT 1,
    kind TEXT NOT NULL, filename TEXT, mime TEXT, size INTEGER, url TEXT, label TEXT, data BLOB,
    dept TEXT, username TEXT, full_name TEXT, uploaded_at TEXT, comment TEXT);
  CREATE INDEX IF NOT EXISTS ix_files_prod ON files(product_id, doc_type_id, step_no);
  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE, step_no INTEGER NOT NULL,
    text TEXT NOT NULL, dept TEXT, username TEXT, full_name TEXT, created_at TEXT, to_depts TEXT, to_steps TEXT);
  CREATE TABLE IF NOT EXISTS risks (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE, step_no INTEGER,
    severity TEXT NOT NULL DEFAULT 'Critical', title TEXT NOT NULL, action TEXT, owner_dept TEXT, status TEXT DEFAULT 'open',
    raised_by TEXT, raised_dept TEXT, raised_at TEXT, closed_at TEXT, closed_by TEXT, close_note TEXT);
  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, dept TEXT NOT NULL, product_id INTEGER, step_no INTEGER,
    type TEXT, title TEXT, body TEXT, from_user TEXT, from_dept TEXT);
  CREATE INDEX IF NOT EXISTS ix_notif_dept ON notifications(dept, id);
  CREATE TABLE IF NOT EXISTS notif_reads (user_id INTEGER NOT NULL, notif_id INTEGER NOT NULL, PRIMARY KEY (user_id, notif_id));
  CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER, step_no INTEGER, at TEXT, username TEXT, dept TEXT, action TEXT, detail TEXT);
  CREATE INDEX IF NOT EXISTS ix_events ON events(product_id, step_no);
  CREATE TABLE IF NOT EXISTS evaluations (
    dept TEXT NOT NULL, month TEXT NOT NULL, positives TEXT, negatives TEXT, conclusion TEXT, updated_by TEXT, updated_at TEXT,
    PRIMARY KEY (dept, month));
  CREATE TABLE IF NOT EXISTS poutput_signs (
    product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE, step_no INTEGER NOT NULL, idx INTEGER NOT NULL,
    dept TEXT NOT NULL, at TEXT, by TEXT, PRIMARY KEY (product_id, step_no, idx, dept));
  -- System-Upload short messages attached to an output (replace e-mail between departments)
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    step_no INTEGER NOT NULL, output_idx INTEGER, text TEXT NOT NULL, dept TEXT, username TEXT, full_name TEXT, created_at TEXT);
  `);
  db.exec(`
  -- per-output rule set in Settings: a file upload is mandatory (a message alone is not enough)
  CREATE TABLE IF NOT EXISTS output_rules (step_no INTEGER NOT NULL, output_idx INTEGER NOT NULL, file_required INTEGER NOT NULL DEFAULT 0, updated_by TEXT, updated_at TEXT, PRIMARY KEY (step_no, output_idx));
  -- announcements sent by the administrator, Business Development or the Plant Manager
  CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER REFERENCES products(id) ON DELETE SET NULL, depts TEXT NOT NULL,
    subject TEXT, text TEXT NOT NULL, dept TEXT, username TEXT, full_name TEXT, created_at TEXT);
  CREATE TABLE IF NOT EXISTS ann_files (
    id INTEGER PRIMARY KEY AUTOINCREMENT, announcement_id INTEGER REFERENCES announcements(id) ON DELETE CASCADE,
    filename TEXT, mime TEXT, size INTEGER, path TEXT, sha256 TEXT, username TEXT, uploaded_at TEXT);
  `);
  // ---- schema additions (safe on existing databases) ----
  const cols = (t) => db.prepare(`PRAGMA table_info(${t})`).all().map((c) => c.name);
  if (!cols('doc_types').includes('required_step')) db.exec('ALTER TABLE doc_types ADD COLUMN required_step INTEGER');
  if (!cols('doc_types').includes('required_output')) db.exec('ALTER TABLE doc_types ADD COLUMN required_output INTEGER');
  if (!cols('psteps').includes('start_alert')) db.exec('ALTER TABLE psteps ADD COLUMN start_alert INTEGER DEFAULT 0');
  if (!cols('files').includes('path')) db.exec('ALTER TABLE files ADD COLUMN path TEXT');
  if (!cols('files').includes('sha256')) db.exec('ALTER TABLE files ADD COLUMN sha256 TEXT');
  if (!cols('notifications').includes('ann_id')) db.exec('ALTER TABLE notifications ADD COLUMN ann_id INTEGER');
  db.exec(`
  CREATE INDEX IF NOT EXISTS ix_files_step ON files(product_id, step_no, output_idx);
  CREATE INDEX IF NOT EXISTS ix_files_type ON files(doc_type_id, version);
  CREATE INDEX IF NOT EXISTS ix_files_date ON files(product_id, uploaded_at);
  CREATE INDEX IF NOT EXISTS ix_msgs ON messages(product_id, step_no, output_idx);
  CREATE INDEX IF NOT EXISTS ix_notes ON notes(product_id, step_no);
  CREATE INDEX IF NOT EXISTS ix_risks ON risks(product_id, status);
  CREATE INDEX IF NOT EXISTS ix_notif_prod ON notifications(product_id);
  CREATE INDEX IF NOT EXISTS ix_annfiles ON ann_files(announcement_id);
  `);

  const get = (k) => { const r = db.prepare('SELECT value FROM settings WHERE key=?').get(k); return r ? r.value : null; };
  if (!get('seeded')) seed(db);
  const rev = Number(get('sop_rev') || 1);
  if (rev < 3) throw new Error('This database was created by an early test version that is not supported. Move the data folder away and start again.');
  if (rev < SOP.SOP_REVISION) {
    const bdir = path.join(dataDir, 'backups'); fs.mkdirSync(bdir, { recursive: true });
    const bfile = path.join(bdir, `before-update-rev${SOP.SOP_REVISION}-${now().replace(/[: ]/g, '-')}.sqlite`);
    db.exec(`VACUUM INTO '${bfile.replace(/'/g, "''")}'`);
    if (rev < 4) migrateV4(db);
    // the seeded SOP content (baseline) follows the package; versions saved by the administrator are kept
    const upd = db.prepare("UPDATE step_defs SET data=? WHERE step_no=? AND product_id IS NULL AND effective_from='2000-01-01' AND created_by='system'");
    SOP.STEPS.forEach((s) => upd.run(JSON.stringify(s), s.no));
    db.prepare("INSERT OR REPLACE INTO settings(key,value) VALUES('sop_rev',?)").run(String(SOP.SOP_REVISION));
    console.log(`  Database updated to SOP revision ${SOP.SOP_REVISION} — safety copy: ${bfile}`);
  }
  return db;
}

// ───────────── update of SOP revision 3 databases (first release of the 35-step version) → revision 4 ─────────────
// steps 20 and 33: the 5 numbered outputs become 13 separate outputs (one per lettered item); step 28 output 3 long-running;
// step 29 depends on step 28; "Other recommendations" restored.
const PLAN_MAP = { 1: [1, 2], 2: [3, 4, 5], 3: [6, 7, 8], 4: [9, 10, 11, 12], 5: [13] };
function migrateV4(db) {
  const t = now();
  const byNo = new Map(SOP.STEPS.map((s) => [s.no, s]));
  db.exec('BEGIN');
  try {
    // SOP baseline content → current seed (versions saved later by the administrator are kept)
    const upd = db.prepare("UPDATE step_defs SET data=?, note=? WHERE step_no=? AND product_id IS NULL AND effective_from='2000-01-01' AND created_by='system'");
    SOP.STEPS.forEach((s) => upd.run(JSON.stringify(s), 'SOP version 3 baseline (revision 4)', s.no));

    // progress of steps 20 and 33: map the 5 old outputs to the 13 new ones
    const pickFor = (no, oldIdx, dept) => {
      const cand = PLAN_MAP[oldIdx] || [];
      const outs = byNo.get(no).outputs;
      return cand.find((i) => outs[i - 1] && (outs[i - 1].by || []).includes(dept)) || cand[0] || null;
    };
    for (const no of [20, 33]) {
      const rows = db.prepare('SELECT * FROM poutputs WHERE step_no=?').all(no);
      db.prepare('DELETE FROM poutputs WHERE step_no=?').run(no);
      db.prepare('DELETE FROM poutput_signs WHERE step_no=?').run(no);
      const ins = db.prepare('INSERT OR IGNORE INTO poutputs(product_id,step_no,idx,state,at,by,reason) VALUES(?,?,?,?,?,?,?)');
      for (const r of rows) for (const ni of PLAN_MAP[r.idx] || []) ins.run(r.product_id, no, ni, r.state, r.at, r.by, r.reason);
      const uf = db.prepare('UPDATE files SET output_idx=? WHERE id=?');
      for (const f of db.prepare('SELECT id, output_idx, dept FROM files WHERE step_no=? AND output_idx IS NOT NULL').all(no)) uf.run(pickFor(no, f.output_idx, f.dept), f.id);
      const um = db.prepare('UPDATE messages SET output_idx=? WHERE id=?');
      for (const m of db.prepare('SELECT id, output_idx, dept FROM messages WHERE step_no=? AND output_idx IS NOT NULL').all(no)) um.run(pickFor(no, m.output_idx, m.dept), m.id);
    }
    db.prepare('UPDATE doc_types SET required_output=10 WHERE required_step=20 AND required_output=4').run();

    const setS = db.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)');
    const gn = db.prepare("SELECT value FROM settings WHERE key='general_notes'").get();
    if (!gn || gn.value === '[]') setS.run('general_notes', JSON.stringify(SOP.GENERAL_NOTES));
    setS.run('sop_rev', '4');
    setS.run('sync_states', '1');
    db.prepare('INSERT INTO events(product_id,step_no,at,username,dept,action,detail) VALUES(NULL,NULL,?,?,?,?,?)').run(t, 'system', 'ADM', 'sop.update', 'Steps 20 and 33 split into 13 separate outputs; step 28 output 3 long-running (step 29 may start); step 29 depends on step 28');
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}

function seed(db) {
  const t = now();
  db.exec('BEGIN');
  try {
    const setS = db.prepare('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)');
    setS.run('company_name', 'Multicare');
    setS.run('general_notes', JSON.stringify(SOP.GENERAL_NOTES));
    setS.run('sop_rev', String(SOP.SOP_REVISION));
    setS.run('weekend', JSON.stringify([5, 6]));
    setS.run('upload_max_mb', '200');
    setS.run('phases', JSON.stringify(SOP.PHASES));
    setS.run('flow', JSON.stringify(SOP.FLOW));
    setS.run('license_step', String(SOP.LICENSE_STEP));
    setS.run('license_output', String(SOP.LICENSE_OUTPUT));
    setS.run('commercial_step', String(SOP.COMMERCIAL_STEP));
    setS.run('commercial_output', String(SOP.COMMERCIAL_OUTPUT));
    setS.run('doc_sections', JSON.stringify(SOP.DOC_SECTIONS));

    const insD = db.prepare('INSERT OR IGNORE INTO departments(code,name,sort) VALUES(?,?,?)');
    SOP.DEPARTMENTS.forEach((d, i) => insD.run(d.code, d.name, i));

    const { hash, salt } = hashPassword('admin');
    db.prepare(`INSERT OR IGNORE INTO users(username,full_name,dept,role,pw_hash,pw_salt,must_change,created_at)
      VALUES('admin','System Administrator','ADM','admin',?,?,1,?)`).run(hash, salt, t);

    const insDef = db.prepare('INSERT INTO step_defs(step_no,product_id,effective_from,data,created_by,created_at,note) VALUES(?,?,?,?,?,?,?)');
    SOP.STEPS.forEach((s) => insDef.run(s.no, null, '2000-01-01', JSON.stringify(s), 'system', t, 'SOP version 3 baseline (revision 4)'));

    const insT = db.prepare('INSERT INTO doc_types(section,name,steps,also_in,sort,required_step,required_output) VALUES(?,?,?,?,?,?,?)');
    SOP.DOC_TYPES.forEach((d, i) => insT.run(d.section, d.name, JSON.stringify(d.steps), JSON.stringify(d.alsoIn || []), i, d.required || d.steps[0] || null, d.out || null));

    const insH = db.prepare('INSERT OR IGNORE INTO holidays(date,name) VALUES(?,?)');
    SOP.HOLIDAYS_SEED.forEach(([d, n]) => insH.run(d, n));

    setS.run('seeded', t);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
}

module.exports = { open, now, today, hashPassword, checkPassword, newFilePath, safeName };
