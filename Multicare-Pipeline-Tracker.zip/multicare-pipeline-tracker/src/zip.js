'use strict';
// Minimal ZIP writer — no external dependencies.
// buildZip: small in-memory archives.  streamZip: writes entries one by one to a stream, so a product with
// many large documents is exported without holding them all in memory.
const fs = require('fs');
const zlib = require('zlib');

function dosTime(d) {
  const time = (d.getHours() << 11) | (d.getMinutes() << 5) | (Math.floor(d.getSeconds() / 2));
  const date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
  return { time, date };
}
const toBuf = (data) => (Buffer.isBuffer(data) ? data : data instanceof Uint8Array ? Buffer.from(data.buffer, data.byteOffset, data.byteLength) : Buffer.from(String(data ?? ''), 'utf8'));
// already-compressed formats are stored as they are (deflating them only costs CPU)
const STORE_EXT = /\.(pdf|zip|7z|rar|gz|png|jpe?g|gif|webp|docx|xlsx|pptx|mp4|mov)$/i;

function entryParts(e, offset, time, date) {
  const name = Buffer.from(e.name.replace(/\\/g, '/'), 'utf8');
  const raw = e.file ? fs.readFileSync(e.file) : toBuf(e.data);
  const store = raw.length > 8 * 1048576 || STORE_EXT.test(e.name);
  const comp = store ? raw : zlib.deflateRawSync(raw);
  const method = store ? 0 : 8;
  const crc = zlib.crc32(raw) >>> 0;
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x0800, 6);
  local.writeUInt16LE(method, 8); local.writeUInt16LE(time, 10); local.writeUInt16LE(date, 12);
  local.writeUInt32LE(crc, 14); local.writeUInt32LE(comp.length, 18); local.writeUInt32LE(raw.length, 22);
  local.writeUInt16LE(name.length, 26); local.writeUInt16LE(0, 28);
  const c = Buffer.alloc(46);
  c.writeUInt32LE(0x02014b50, 0); c.writeUInt16LE(20, 4); c.writeUInt16LE(20, 6); c.writeUInt16LE(0x0800, 8);
  c.writeUInt16LE(method, 10); c.writeUInt16LE(time, 12); c.writeUInt16LE(date, 14);
  c.writeUInt32LE(crc, 16); c.writeUInt32LE(comp.length, 20); c.writeUInt32LE(raw.length, 24);
  c.writeUInt16LE(name.length, 28); c.writeUInt16LE(0, 30); c.writeUInt16LE(0, 32); c.writeUInt16LE(0, 34);
  c.writeUInt16LE(0, 36); c.writeUInt32LE(0, 38); c.writeUInt32LE(offset, 42);
  return { head: [local, name], body: comp, central: Buffer.concat([c, name]), size: local.length + name.length + comp.length };
}
function endRecord(count, cdLen, offset) {
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(0, 4); end.writeUInt16LE(0, 6);
  end.writeUInt16LE(count, 8); end.writeUInt16LE(count, 10);
  end.writeUInt32LE(cdLen, 12); end.writeUInt32LE(offset, 16); end.writeUInt16LE(0, 20);
  return end;
}

function buildZip(entries) {
  const { time, date } = dosTime(new Date());
  const chunks = []; const central = []; let offset = 0;
  for (const e of entries) {
    const p = entryParts(e, offset, time, date);
    chunks.push(...p.head, p.body); central.push(p.central); offset += p.size;
  }
  const cd = Buffer.concat(central);
  return Buffer.concat([...chunks, cd, endRecord(entries.length, cd.length, offset)]);
}

// entries: [{ name, data } | { name, file }] — written sequentially with back-pressure
async function streamZip(out, entries) {
  const { time, date } = dosTime(new Date());
  const write = (b) => new Promise((resolve) => { if (out.write(b)) resolve(); else out.once('drain', resolve); });
  const central = []; let offset = 0; let count = 0;
  for (const e of entries) {
    let p;
    try { p = entryParts(e, offset, time, date); } catch { continue; } // missing file on disk: skip it
    for (const b of p.head) await write(b);
    await write(p.body);
    central.push(p.central); offset += p.size; count++;
  }
  const cd = Buffer.concat(central);
  await write(cd);
  out.end(endRecord(count, cd.length, offset));
}

module.exports = { buildZip, streamZip };
