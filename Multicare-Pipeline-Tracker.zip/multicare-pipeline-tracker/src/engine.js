'use strict';
/*
 * Calendar + dependency engine.
 * All dates are 'YYYY-MM-DD' strings (plant local date). Timestamps are 'YYYY-MM-DD HH:MM:SS'.
 */

// ---------- calendar ----------
function parse(d) { const [y, m, dd] = d.slice(0, 10).split('-').map(Number); return Date.UTC(y, m - 1, dd); }
function fmt(ms) { return new Date(ms).toISOString().slice(0, 10); }
function addDays(d, n) { return fmt(parse(d) + n * 86400000); }
function dow(d) { return new Date(parse(d)).getUTCDay(); } // 0=Sun … 6=Sat
function diffDays(a, b) { return Math.round((parse(b) - parse(a)) / 86400000); } // b - a
function maxDate(...ds) { const v = ds.filter(Boolean); return v.length ? v.reduce((a, b) => (a > b ? a : b)) : null; }
function minDate(...ds) { const v = ds.filter(Boolean); return v.length ? v.reduce((a, b) => (a < b ? a : b)) : null; }

class Calendar {
  constructor({ weekend = [5, 6], holidays = [] } = {}) {
    this.weekend = new Set(weekend);
    this.holidays = new Set(holidays);
  }
  isWorkday(d) { return !this.weekend.has(dow(d)) && !this.holidays.has(d); }
  nextWorkday(d) { let x = d; let guard = 0; while (!this.isWorkday(x) && guard++ < 400) x = addDays(x, 1); return x; }
  addWorkdays(d, n) {
    let x = d; let left = Math.max(0, Math.round(n)); let guard = 0;
    while (left > 0 && guard++ < 5000) { x = addDays(x, 1); if (this.isWorkday(x)) left--; }
    return x;
  }
  // working days strictly after a, up to and including b (0 if b <= a)
  workdaysBetween(a, b) {
    if (!a || !b || b <= a) return 0;
    let n = 0; let x = a; let guard = 0;
    while (x < b && guard++ < 5000) { x = addDays(x, 1); if (this.isWorkday(x)) n++; }
    return n;
  }
  addMonths(d, m) {
    const whole = Math.floor(m); const frac = m - whole;
    const dt = new Date(parse(d));
    const day = dt.getUTCDate();
    dt.setUTCDate(1);
    dt.setUTCMonth(dt.getUTCMonth() + whole);
    const last = new Date(Date.UTC(dt.getUTCFullYear(), dt.getUTCMonth() + 1, 0)).getUTCDate();
    dt.setUTCDate(Math.min(day, last));
    let out = fmt(dt.getTime());
    if (frac > 0) out = addDays(out, Math.round(frac * 30));
    return out;
  }
  // timeframe → due date. Calendar-based results that land on a weekend/holiday roll to the next working day.
  due(start, tf) {
    if (!start || !tf) return start || null;
    const { n, u } = tf;
    if (u === 'WD') return this.addWorkdays(start, n);
    if (u === 'CD') return this.nextWorkday(addDays(start, Math.round(n)));
    if (u === 'W') return this.nextWorkday(addDays(start, Math.round(n * 7)));
    if (u === 'M') return this.nextWorkday(this.addMonths(start, n));
    return start;
  }
}

function parseTf(s) {
  if (!s) return null;
  if (typeof s === 'object') return s;
  const m = String(s).trim().match(/^([\d.]+)\s*(WD|CD|W|M)$/i);
  if (!m) return null;
  return { n: parseFloat(m[1]), u: m[2].toUpperCase() };
}
const UNIT_LABEL = { WD: 'working days', CD: 'calendar days', W: 'week(s)', M: 'month(s)' };
function tfText(tf) {
  const t = parseTf(tf); if (!t) return '—';
  if (t.u === 'WD') return `${t.n} WD`;
  if (t.u === 'CD') return `${t.n} calendar days`;
  if (t.u === 'W') return `${t.n} ${t.n === 1 ? 'week' : 'weeks'}`;
  return `${t.n} ${t.n === 1 ? 'month' : 'months'}`;
}

/*
 * computeProduct — the dependency engine.
 *  product  : { id, start_date }
 *  stepNos  : sorted list of step numbers
 *  getDef   : (no, refDate) => step definition (version in force at refDate)
 *  rows     : Map no -> { started_at, completed_at, na_at, na_reason, due_override, iterations }
 *  outs     : Map 'no.idx' -> { state:'done'|'na', at }
 *  ins      : Map 'no.idx' -> { at }
 *  cal      : Calendar
 *  today    : 'YYYY-MM-DD'
 */
function computeProduct({ product, stepNos, getDef, rows, outs, ins, signs, cal, today }) {
  const res = new Map();
  for (const no of stepNos) {
    const r = rows.get(no) || {};
    const structDef = getDef(no, today);
    const deps = (structDef.deps || []).filter((d) => d < no && stepNos.includes(d));
    const depRes = deps.map((d) => res.get(d)).filter(Boolean);

    const isNA = !!r.na_at;
    const isDone = !isNA && !!r.completed_at;
    // a dependency is satisfied when the step is closed, or "released" towards this step (only long-running outputs still pending)
    const opensFor = (d) => d.closed || (d.released && (!d.releaseTo || d.releaseTo.includes(no)));
    const gateDateFor = (d) => (d.closed ? d.closedDate : d.releaseDate);
    const fGateFor = (d) => (!d.releaseTo || d.releaseTo.includes(no) ? d.fGate : d.fClose);
    const allOpen = depRes.every(opensFor);
    let readyDate = null;
    if (deps.length === 0) readyDate = product.start_date;
    else if (allOpen) readyDate = maxDate(product.start_date, ...depRes.map(gateDateFor));

    const def = getDef(no, readyDate || today);

    // forecast ready
    const fReady = readyDate || maxDate(product.start_date, ...depRes.map(fGateFor)) || product.start_date;

    const outputs = (def.outputs || []).map((o, i) => {
      const k = `${no}.${i + 1}`;
      const st = outs.get(k);
      return { idx: i + 1, def: o, tf: parseTf(o.tf), state: st ? st.state : null, at: st ? st.at : null, by: st ? st.by : null, reason: st ? st.reason : null, signs: (signs && signs.get(k)) || [] };
    });
    // due dates per output (actual & forecast)
    const calcDues = (base, key) => {
      outputs.forEach((o) => {
        let start = base;
        if (o.def.rel) {
          const ref = outputs[o.def.rel - 1];
          if (ref) start = ref.at ? ref.at.slice(0, 10) : ref[key];
        }
        o[key] = start ? cal.due(start, o.tf) : null;
        if (r.due_override && key === 'due' && !o.state) o[key] = r.due_override;
      });
    };
    if (readyDate) calcDues(readyDate, 'due');
    calcDues(fReady, 'fDue');
    if (r.due_override) outputs.forEach((o) => { if (!o.state) o.fDue = r.due_override; });

    let due = null;
    if (readyDate) due = r.due_override || maxDate(...outputs.map((o) => o.due)) || readyDate;
    const fDue = r.due_override || maxDate(...outputs.map((o) => o.fDue)) || fReady;

    let state;
    if (isNA) state = 'na';
    else if (isDone) state = 'done';
    else if (!readyDate) state = r.started_at ? 'in_progress' : 'waiting';
    else if (r.started_at) state = 'in_progress';
    else state = 'ready';

    const closed = isNA || isDone;
    const closedDate = isNA ? r.na_at.slice(0, 10) : isDone ? r.completed_at.slice(0, 10) : null;

    // overdue — counted per output (each output has its own SOP timeframe and due date)
    let overdueDays = 0;
    const overdueOutputs = [];
    if (!closed && readyDate) {
      outputs.forEach((o) => {
        o.overdueDays = 0;
        if (!o.state && o.due && today > o.due) {
          o.overdueDays = diffDays(o.due, today);
          overdueOutputs.push(o.idx);
          overdueDays = Math.max(overdueDays, o.overdueDays);
        }
      });
      if (due && today > due) overdueDays = Math.max(overdueDays, diffDays(due, today));
    }
    const overdue = overdueDays > 0;

    // ready-to-start waiting time (working days)
    let waitWD = null;
    if (readyDate && !isNA) {
      const startD = r.started_at ? r.started_at.slice(0, 10) : (isDone ? r.completed_at.slice(0, 10) : today);
      waitWD = cal.workdaysBetween(readyDate, startD);
    }
    const lateDays = isDone && due ? Math.max(0, diffDays(due, closedDate)) : 0;
    const onTime = isDone ? (due ? closedDate <= due : true) : null;

    // forecast close
    const fClose = closed ? closedDate : maxDate(fDue, today);

    // inputs
    const inputs = (def.inputs || []).map((inp, i) => {
      const k = `${no}.${i + 1}`;
      const st = ins.get(k);
      const srcs = (inp.from || []).map((f) => {
        const [s, oi] = String(f).split('.').map(Number);
        const sr = res.get(s);
        let ok = false;
        if (sr) {
          if (sr.state === 'na') ok = true;
          else if (oi) { const o = sr.outputs[oi - 1]; ok = !!(o && o.state) || sr.state === 'done'; }
          else ok = sr.state === 'done' || sr.released;
        }
        return { ref: String(f), step: s, out: oi || null, ok };
      });
      return { idx: i + 1, def: inp, confirmed: !!st, at: st ? st.at : null, by: st ? st.by : null, sources: srcs, available: srcs.length ? srcs.every((x) => x.ok) : null };
    });

    // long-running outputs: the next steps may start once every other output is delivered
    const deferred = outputs.filter((o) => o.def.defer);
    const blocking = outputs.filter((o) => !o.def.defer);
    const deferPending = !closed ? deferred.filter((o) => !o.state) : [];
    let released = false; let releaseDate = null;
    // once released, a step stays released until it is completed (even after the long-running output is ticked)
    if (state === 'in_progress' && deferred.length && blocking.every((o) => o.state) && inputs.every((x) => x.confirmed)) {
      released = true;
      releaseDate = maxDate(r.started_at.slice(0, 10), ...blocking.map((o) => o.at.slice(0, 10)), ...inputs.map((x) => (x.at || '').slice(0, 10)));
    }
    // releaseTo: the long-running output lets only these next steps start early (others wait for completion)
    const releaseTo = deferred.length && deferred.every((o) => Array.isArray(o.def.releaseTo)) ? [...new Set(deferred.flatMap((o) => o.def.releaseTo.map(Number)))] : null; // [] = releases no step
    const gateOpen = closed || released;
    const gateDate = closed ? closedDate : releaseDate;
    let fGate = fClose;
    if (!closed && released) fGate = releaseDate;
    else if (!closed && deferred.length && blocking.length) fGate = maxDate(...blocking.map((o) => (o.state ? o.at.slice(0, 10) : o.fDue)), today);

    const outputsDone = outputs.filter((o) => o.state).length;
    const inputsDone = inputs.filter((x) => x.confirmed).length;

    res.set(no, {
      no, def, deps, state, closed, closedDate, readyDate, due, fReady, fDue, fClose,
      overdue, overdueDays, overdueOutputs, waitWD, lateDays, onTime,
      released, releaseDate, releaseTo, gateOpen, gateDate, fGate,
      deferLabels: (state === 'done' || state === 'na') ? [] : deferPending.map((o) => o.def.deferLabel || 'Long-running output pending'),
      started_at: r.started_at || null, started_by: r.started_by || null,
      completed_at: r.completed_at || null, completed_by: r.completed_by || null,
      na_at: r.na_at || null, na_by: r.na_by || null, na_reason: r.na_reason || null,
      due_override: r.due_override || null, iterations: r.iterations || 0,
      outputs, inputs, outputsDone, inputsDone,
      canComplete: state === 'in_progress' && inputs.every((x) => x.confirmed) && outputs.every((o) => o.state),
    });
  }
  return res;
}

module.exports = { Calendar, parseTf, tfText, UNIT_LABEL, computeProduct, addDays, diffDays, maxDate, minDate, parse, fmt };
