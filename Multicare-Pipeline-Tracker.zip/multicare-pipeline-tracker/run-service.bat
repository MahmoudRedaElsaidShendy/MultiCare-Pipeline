@echo off
REM Used by the scheduled task created by windows-autostart-setup.bat (runs without a window).
REM Keep PORT the same as in windows-autostart-setup.bat.
set PORT=3000
set TZ=Africa/Cairo
cd /d "%~dp0"
if not exist "%~dp0data" mkdir "%~dp0data"
:run
node --disable-warning=ExperimentalWarning server.js >> "%~dp0data\server.log" 2>&1
REM exit code 3 = the port is already used by a running copy: do not start a second one
if %errorlevel% EQU 3 exit /b 3
REM if the system ever stops unexpectedly, start it again after 15 seconds
echo %date% %time% The system stopped (exit code %errorlevel%) - restarting in 15 seconds >> "%~dp0data\server.log"
ping -n 16 127.0.0.1 >nul
goto run
